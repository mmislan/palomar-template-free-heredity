# Supplement S1: complete proof records, fixed data and reproducibility

Accompanies Michael Mislan, Chemical heredity without genetic templates, 20 October 2026. Appendices A-D give the conventional proofs. These source records preserve supporting inputs as this article's own supplement; they are not external prior literature or priority claims.

## S1.1 / retained manuscript citation ref9

Complete catalytic-population proof source and operating-comparison support: source_records/companion_inputs/support/P161_CANONICAL_MANUSCRIPT.md, its retained inputs/checkers, and source_records/comparison_support/. All 59 retained support files match their earlier selected release-candidate editions. The P161 source is a previously reviewed path/navigation edition, not a byte-identical copy of the private original. SOURCE_EDITION_PROVENANCE.json records both identities: original 731042cd...; supplied edition 50406702.... The two navigation edits do not change its mathematics. The compiled central beta4m source is separately public at the fixed commit below; other operating points retain their conventional/historical scope.

## S1.2 / retained manuscript citation ref10

Complete majority-restoration proof source: source_records/companion_inputs/support/P118_main.tex, byte-identical to its original (SHA256 e2532ee3...). The article incorporates the complete conventional proof as Appendix D; a separate publication of that source manuscript is not required. Original illustrative includes are source history, not a standalone build promise. The central population formalization does not imply full formalization of this distinct copying protocol.

## Portable direct reset certificate

Read data/recovery_profile_upper.json and run verify/verify_direct_reset.py with Python 3 from any directory. Only the standard library and this supplied table are needed; no predecessor directory or private code is imported. An optional argument names the JSON result file. The supplied result records an exact-arithmetic PASS for 496 low pairs, 4066 count/fuel rows, 992 deficient rows and 2035153 binomial summands. It checks high-tail enclosure, grid integrality and both printed residual endpoints. This verifies the finite reset certificate, not a new replay of the whole Lean mission.

## Formalization and archived support

Immutable public source: https://github.com/mmislan/palomar-template-free-heredity/tree/eb72f72f2c27da1e351e51ae2bdad4604c34cf3c
Main declaration: P161Formal.template_free_heredity_finite_stock. Its scientific proof sources and accepted receipts are unchanged by this editorial revision.

source_records/ retains selected mathematical proof/checking editions and third-party notices. Some historical programs retain old provenance-path conventions; only the new direct-reset verifier is advertised as standalone. All paths and hashes are in SOURCE_RECORDS.json and MANIFEST.json. Private discovery/optimization engines, internal legal Q&A and missing-directory search narratives are excluded. Original proof/code is Apache-2.0; original prose/data CC-BY-4.0; embedded third-party terms prevail. Retained licence texts are under source_records/licensing/ and comparison_support/. No companion DOI, independent human peer review or external companion publication is asserted.
