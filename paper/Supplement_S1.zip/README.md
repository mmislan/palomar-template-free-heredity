# Supplement S1 — chemical heredity without genetic templates

This is the complete supplement candidate for the accompanying conventional synthesis. Start with the manuscript's A-C proof and AppendixD, then use the following map. Historical calculations are identified as historical; none was rerun in preparing this edition.

| Claim | Inspectable support |
|---|---|
| Literal direct reset C.3.1-C.3.3 | [Complete table](companion_inputs/inputs/planning/reciprocal_beta_recovery/base_beta8m_profile_upper.json), [finite obligations](DIRECT_RESET_FINITE_OBLIGATIONS.md), [archival checking source](direct_reset_support/source_evidence/full_review/independent_full_mission_check.py), [saved result](direct_reset_support/source_evidence/full_review/independent_full_mission_results.json) and [stdout](direct_reset_support/source_evidence/full_review/independent_full_mission_stdout.txt) |
| Full mission, acquisition/service/stock and comparison arguments | [P161 complete source edition](companion_inputs/support/P161_CANONICAL_MANUSCRIPT.md), original profile/constructor/reset sources, reciprocal family sources and saved endpoint outputs in companion_inputs |
| Original beta8m branching support | [Cert](comparison_support/proofs/FunctionalCapacity/Cert.lean), [Defs](comparison_support/proofs/FunctionalCapacity/Defs.lean), pinned toolchain/lock and nine unchanged dependency notices under comparison_support |
| P118 conventional result | The accompanying AppendixD and [complete main source](companion_inputs/support/P118_main.tex); this is not a complete compilable TeX or Lean project |

## Checking instructions and evidence scope

Inspect the displayed rational definitions and domains, then the archival kernel at lines109-170 of independent_full_mission_check.py: the full high-tail enclosure, low comparisons, grid integrality, every paired-floor binomial term and both residual maxima. Compare its saved endpoints with manuscriptC11-C11a. The mathematical kernel is inspectable and independently reimplementable from the supplied table and formulas. A bare hash or PASS label is not a replacement for these comparisons.

The whole historical source includes broad provenance reads and result writes. Its original host-location strings are replaced by ARCHIVE_PATH tokens; it is an archival source edition, not a minimal portable executable. No instruction to run it unchanged is a validated reproduction route. The earlier path-adapted sources are also not newly run or accepted. Missing former-cloud provenance trees do not become assumptions of the new conventional reset derivation. Fresh reruns and a new standalone Lean build are not claimed or required by the stated conventional evidence framing.

PUBLIC_SOURCE_MAP.json gives original and edition hashes; all mathematical expressions and numerical output values are retained. The raw originals remain in the private archive, and the private edition log maps every location substitution. PROOF_NAVIGATION.md identifies omitted administrative records, illustrative graphics and historical links. No essential proof is delegated to a private path. Cert/Defs are retained for the comparison; no optional-build argument is used to discard a proof dependency.

## Rights and credit

RIGHTS_INDEX.json classifies each file under the existing project Apache-2.0 code/proof policy or CC-BY-4.0 prose/data policy, within rights held by the licensors; it preserves all dependency notices and exact source identities. The policy and full texts are under licensing. Archived source-author fields remain as recorded. This edition credits Michael Mislan as the sole human contributor. In response to the question about the six imported-original groups, he reported no known exceptions to the existing policy. The [credit and policy record](CREDIT_AND_POLICY_RECORD.md) preserves his exact statement and its limited interpretation. The historical prose identifying earlier bounded licence searches is a dated observation, not a claim that an umbrella policy is absent. No independent legal warranty or new licence grant is asserted, and no submission or publication is authorized by this record.
