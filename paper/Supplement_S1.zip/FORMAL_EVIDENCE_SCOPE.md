# Scope of the existing central formalization

Public immutable snapshot: https://github.com/mmislan/palomar-template-free-heredity/tree/eb72f72f2c27da1e351e51ae2bdad4604c34cf3c

Main declaration: P161Formal.template_free_heredity_finite_stock. This is the full beta = 4,000,000 switched finite-stock theorem represented by Theorem 1, with failure bound 4517975690072193 / 10^18. The prepared old-founder condition, arbitrary allowed candidate counts and fuel, seed withdrawal at time 30, service through 60, actual complementary daughters, first current-population recoveries/strictly later actual divisions and all seven stock ceilings belong to that simultaneous event. Auxiliary driving history is not an additional physical molecule; observations read the absorbing stopped stock trace. Failure mass is not conditioned away.

The inherited evidence includes strict Lean checking, independently specified exact statement/substantive-definition comparison, separate Lean replay, NanoDa and con-ron passes. The ordinary accepted axioms are propext, Classical.choice and Quot.sound. This editorial revision ran no Lean proof compilation and created no new verification receipt. It preserves the scientific sources and accepted evidence; the public snapshot's own instructions govern formal reproduction.

The restoration result in Theorem 2 / Appendix D has a complete conventional proof. The full central population formalization does not newly formalize that distinct protocol, all operating points, the contextual random-division converse, an arbitrary lineage, food-only initiation or autonomous successive evolution. The standalone exact verifier in this supplement reproduces the fixed direct-reset certificate and is separate from full Lean verification.
