#!/usr/bin/env python3
"""Exact additive seed-free recovery certificate at beta4m; frozen inputs read only."""
from fractions import Fraction as F
from pathlib import Path
from math import factorial
import hashlib,json
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parents[1] / 'inputs' / 'planning'
PROFILE=SOURCE/'reciprocal_beta_recovery/base_beta8m_profile_upper.json'
assert hashlib.sha256(PROFILE.read_bytes()).hexdigest()=='1cbf7592037531b0c61ca9c5c01f40e418bf5932b291c25273490e535fb12542'
N=2048; BETA=4000000; RHO=F(150); EPS=F(1,4700); GRID=10**18
HU=[[F(v) for v in row] for row in json.loads(PROFILE.read_text())]
H=[row.copy() for row in HU]
assert all(row==[0,0] for row in H[:16])
def f(a):
    if a<=768: return F((980-a)*(981-a)*(982-a),(a-10)*(a-9)*(a-8))
    return f(768)*F(10,11)**(a-768)
for a in range(512,N+2):
    k=(6*(1-F(a,N))*(f(a+1)/f(a)-1)+a*(f(a-1)/f(a)-1) if a<768 else F(5647*a,56320)-F(6,11))
    gap=(258+k)/8000000
    assert 0<=gap<F(1,10000)
    H[a]=[f(a)/f(512),f(a)*(1-gap)/f(512)]
A=[row[0] for row in H]; D=[u-v for u,v in H]
HB=[[a,a-F(11,8)*d] for a,d in zip(A,D)]
L,U=F(9997,10000),F(10000,9999)
for a in range(16,N+1):
    assert HB[a][0]>=HB[a][1]>0
    if a<512: assert min(HB[a])>=1
    for fuel in (0,1):
        lower=H[a][fuel]-(F(1,GRID) if a<512 else 0)
        assert L*H[a][fuel]<=HB[a][fuel]<=U*lower
M=F(338971453059,125000); C=F(478); COLD=F(95467565097,200000000)
assert 12*max(max(row) for row in HB[16:N+1])<=M
assert U*COLD<L*C

def generator(a,r,seed):
    v=HB[a][r]
    events=[('seed',seed*(1-F(a,N)),a+1,r),('passive',F(a),a-1,r)]
    if r==0: events += [('recharge',F(BETA),a,1)]
    else: events += [('birth',800*a*(1-F(a,N)),a+1,0),('active_death',F(400*a),a-1,0),('reference_fuel_loss',BETA*(3+F(a,N))+800*N,a,0)]
    return sum(rate*(HB[k][fuel]-v) for _,rate,k,fuel in events)
mins={0:None,1:None}; failures=[]; rows=0; nonmonotone=[]
for a in range(16,N+1):
    source=0 if a<512 else EPS
    for r in (0,1):
        g0=generator(a,r,F(0)); g6=generator(a,r,F(6)); v=HB[a][r]
        seedterm=6*(1-F(a,N))*(HB[a+1][r]-v)
        assert g0==g6-seedterm
        assert g6+RHO*v<=source
        rate=(source-g0)/v
        if mins[r] is None or rate<mins[r][0]: mins[r]=(rate,a)
        if g0+RHO*v>source: failures.append([a,r,str(g0+RHO*v-source)])
        if seedterm>0 and len(nonmonotone)<8: nonmonotone.append([a,r,str(seedterm)])
        rows+=1

def ceilq(x,den=GRID):return F(-((-x.numerator*den)//x.denominator),den)
def floorq(x,den=GRID):return F((x.numerator*den)//x.denominator,den)
def el(x,n=200):
    t=s=F(1)
    for k in range(1,n+1):t*=x/k;s+=t
    return s

def eu(x,n=200):
    assert 0<=x<n+2
    t=F(1)
    for k in range(1,n+1):t*=x/k
    return el(x,n)+t*x/(n+1)/(1-x/(n+2))
GAMMA=RHO+4-12*EPS; T=F(1,2); K=14; DELTA=F(1,100); THETA=F(1,640)
kappa=F(3,5*BETA+1200*N); clock_a=4+4*BETA*kappa; V=20*BETA+5400*N+64
EXP=THETA*(DELTA/kappa-4)-V*T*THETA**2/(2*(1-2*THETA/3))
assert DELTA>4*kappa; assert EXP>=F(9141301,460320)
mu=F(321,100); assert clock_a*T+DELTA<=mu
word=M*sum((C*T)**k/factorial(k) for k in range(K))/el(GAMMA*T)
poisson=1-sum(mu**k/factorial(k) for k in range(K))/eu(mu)
clock=1/el(F(9141301,460320))
q=ceilq(word+poisson+clock)
result={'status':'PASS' if not failures else 'FAIL','beta':BETA,'seed_after30':0,'profile_sha256':hashlib.sha256(PROFILE.read_bytes()).hexdigest(),'checked_rows':rows,'failure_count':len(failures),'failures_first10':failures[:10],'minimum_seed_free_decay_by_fuel':{str(r):{'count':a,'rate_lower':str(floorq(rate))} for r,(rate,a) in mins.items()},'positive_seed_generator_examples':nonmonotone,'gamma':str(GAMMA),'reset_C':str(C),'initial_M':str(M),'clock_exponent_beta4m':str(EXP),'clock_compensator_mean_beta4m':str(clock_a*T+DELTA),'word_upper':str(ceilq(word)),'poisson_upper':str(ceilq(poisson)),'clock_upper':str(ceilq(clock)),'q_upper':str(q),'q_lt_1e-5':q<F(1,100000)}
(ROOT/'recovery_seed_free_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert not failures
assert q==F(8622092430140,GRID)<F(1,100000)
