#!/usr/bin/env python3
"""Exact analytical check of beta4m postacquisition seed withdrawal.
Independent literal operator assembly; no imports of previous checkers.
Only new files beside this script are written. No compiler or simulation.
"""
from fractions import Fraction as Q
from functools import lru_cache
from math import comb, factorial, prod
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[2] / 'inputs' / 'planning'
N, BETA, ALPHA, K = 2048, 4_000_000, 800, 16
B0, THETA = Q(13,10**7), Q(1,2)
D = Q(1860480)
HMAX = 1843200

def h(a):
    return Q(1,prod(range(a+1,a+6)))
C = D*h(12)/Q(3,4)**12
@lru_cache(None)
def A(a):
    return C*Q(3,4)**a if a <= 12 else D*h(a)
@lru_cache(None)
def gap(a):
    return A(a)*(Q(-1,2) if a == 0 else min(6*a,70))
@lru_cache(None)
def W(a,fuel):
    return A(a) if fuel else A(a)+gap(a)/BETA
@lru_cache(None)
def daughters(a):
    # Exact beta-integral transform E[h(Bin(a,1/2))], then finite corrections.
    raw = 32*h(a)-Q(4,3)*sum((Q((-1)**r*comb(4,r),(a+r+1)*2**(a+r+1)) for r in range(5)),Q(0))
    ea = D*raw+sum((comb(a,k)*(A(k)-D*h(k)) for k in range(min(a,12)+1)),Q(0))/2**a
    eg = 70*ea+sum((comb(a,k)*(gap(k)-70*A(k)) for k in range(min(a,11)+1)),Q(0))/2**a
    return ea,ea+eg/BETA

def literal_terms(a,fuel,U,v,seed):
    u=Q(a,N)
    prev=max(a-1,0)
    w=W(a,fuel)
    et,ef=daughters(a)
    Hf=BETA*U+v
    terms={'seed':seed*(1-u)*(W(a+1,fuel)-w),
           'passive_death':a*(W(prev,fuel)-w)}
    if fuel:
        terms.update({
            'active_birth':ALPHA*a*(1-u)*(W(a+1,False)-w),
            'active_death':Q(ALPHA,2)*a*(W(prev,False)-w),
            'fuel_loss':(BETA*(1+u)+Hf)*(W(a,False)-w),
            'basal_daughters':et+ef-2*w,
            'triggered_daughters':(u+U)*(2*ef-w)})
    else:
        terms.update({'recharge':BETA*(W(a,True)-w),
                      'basal_daughters':2*ef-2*w})
    return terms

def out(x,digits=18):
    unit=10**digits
    lo=x.numerator*unit//x.denominator
    hi=-((-x.numerator*unit)//x.denominator)
    def fmt(n):
        sign='-' if n<0 else ''
        n=abs(n)
        return f'{sign}{n//unit}.{n%unit:0{digits}d}'
    return [fmt(lo),fmt(hi)]
def record(x):
    return {'exact':str(x),'outward':out(x)}
def pack(t,seed):
    val,a,fuel,U,v=t
    return {'a':a,'fuel':fuel,'Uf':U,'foreign_excess':v,'Hf':BETA*U+v,
            'value':record(val),'slack_to_b0':record(B0-val),'W':record(W(a,fuel)),
            'literal_operator_terms':{k:record(z) for k,z in literal_terms(a,fuel,U,v,seed).items()}}

def exp_lower(x,n):
    return sum((x**k/factorial(k) for k in range(n+1)),Q(0))

# All-natural positivity, upper bound, floor barrier and prepared region are
# proved by monotonic ratios in the companion proof; these test every seam.
assert C == Q(1275068416,16120377) and 0<C<80
assert A(12) == D*h(12)
for a in range(13):
    for fuel in (False,True):
        assert 0<W(a+1,fuel)<W(a,fuel)
assert W(0,False)<W(0,True)
barrier=min((W(a,f),a,f) for a in range(K) for f in (False,True))
assert barrier == (Q(1),15,True)
prepared=max(W(512,False),W(512,True))
assert prepared<Q(6,10**8)

live_rows=0
pre_rows=0
corner_records=[]
max_drift=None
max_contract=None
max_pre=None
for fuel in (False,True):
    for U in (0,2):
        for v in (0,HMAX):
            top0=None
            topc=None
            for a in range(N+1):
                onterms=literal_terms(a,fuel,U,v,6)
                on=sum(onterms.values(),Q(0))+THETA*W(a,fuel)
                assert on<=B0,('pre-switch SiteCert failed',a,fuel,U,v)
                pre_rows+=1
                pre=(on,a,fuel,U,v)
                if max_pre is None or on>max_pre[0]:max_pre=pre
                if a<K:continue
                offterms=literal_terms(a,fuel,U,v,0)
                off=sum(offterms.values(),Q(0))
                contract=off+THETA*W(a,fuel)
                assert off==on-THETA*W(a,fuel)-onterms['seed']
                assert offterms['seed']==0
                assert off<=B0,('seed-free RetCert failed',a,fuel,U,v)
                assert contract<=B0,('seed-free live contraction failed',a,fuel,U,v)
                live_rows+=1
                plain=(off,a,fuel,U,v)
                contracted=(contract,a,fuel,U,v)
                if top0 is None or off>top0[0]:top0=plain
                if topc is None or contract>topc[0]:topc=contracted
                if max_drift is None or off>max_drift[0]:max_drift=plain
                if max_contract is None or contract>max_contract[0]:max_contract=contracted
            corner_records.append({'drift':pack(top0,0),'drift_plus_half_W':pack(topc,0)})
assert pre_rows==16392 and live_rows==16264

# Closed transforms independently cross-checked against complete binomial sums.
spots=sorted({0,1,11,12,13,15,16,17,511,512,868,951,979,2048,
              max_drift[1],max_contract[1],max_pre[1]} |
              {entry[key]['a'] for entry in corner_records for key in ('drift','drift_plus_half_W')})
for a in spots:
    et,ef=daughters(a)
    assert et==sum((Q(comb(a,k))*W(k,True) for k in range(a+1)),Q(0))/2**a
    assert ef==sum((Q(comb(a,k))*W(k,False) for k in range(a+1)),Q(0))/2**a

# Explicit rejection of the false claim that this is an all-count seed-free
# acquisition certificate. The retention theorem deliberately starts at K16.
zero_drift=sum(literal_terms(0,False,0,0,0).values(),Q(0))
zero_residual=zero_drift+THETA*W(0,False)
assert zero_drift==C/2 and zero_drift>B0 and zero_residual>B0

# Common uniformization: old seed-on envelope remains valid after withdrawal.
Lambda=4*(3*(6+800*N+400*N+N+BETA)+BETA+4)
assert Lambda==93515864
z=Q(3,4);rho=Q(79967,80000);theta_s=Q(1650)
Hs=Q(800*3*N*9,16)+3*BETA+8
assert Hs==14764808 and 0<z<=rho<=1
assert theta_s==BETA*(1-rho) and theta_s<Lambda
srv=BETA*Q(16,N)*(z-rho)+Hs*(1-rho)+theta_s*rho
assert srv == -Q(598067,10000)
service_rows=0
for a in range(K,N+1):
    assert -BETA*(1-rho)+theta_s==0
    assert BETA*Q(a,N)*(z-rho)+Hs*(1-rho)+theta_s*rho<=srv<0
    service_rows+=2
service_bound=12/rho/z**500/exp_lower(Q(165),200)
service_ceiling=Q(1948303823,250000000000000000)
assert service_bound<service_ceiling<Q(1,10**8)
assert exp_lower(Q(15),100)>2900000
assert exp_lower(Q(25),100)>10**10
old_coeff=8*60
cand_coeff=Q(4,1)/THETA+4*30
assert old_coeff+cand_coeff==608
old_initial=Q(48,10**8)
acquisition=Q(320,2900000)
service=600*Q(1,10**8)
divisions=Q(5184,10**10)
direct=old_initial+acquisition+608*B0+service+divisions
conservative=old_initial+acquisition+720*B0+service+divisions
assert direct==Q(8226423,9062500000)
assert conservative==Q(9545923,9062500000)
assert conservative-direct==112*B0
assert direct<conservative<Q(1,500)
assert 300*4*2+300*4*3==6000
assert 6000*500==3000000
assert 4*6**4==5184 and (1-Q(1,6))*30==25

source_names=[
 'EXACT_SERVICE_AND_BRANCHING_SOURCE_20261013.md',
 'FULLER_ORIGINAL_G60_SOURCE_RETRIEVAL_20261013.md',
 'GENERIC_MISSION_AND_COMPOSITION_SOURCE_20261013.md',
 'beta1m_branching/BETA1M_BRANCHING_CERTIFICATE_20261013.md',
 'beta1m_branching/fixed_beta1m_branching_check.py',
 'beta1m_branching/reciprocal_beta_extension_check.py',
 'general_credit_tilt_review/GENERAL_CREDIT_TILT_INDEPENDENT_REVIEW_20261013.md',
 'general_credit_tilt_review/independent_general_tilt_check.py']
source_pins={name:hashlib.sha256((SOURCE/name).read_bytes()).hexdigest() for name in source_names}
result={
 'status':'PASS: seed-free live RetCert and complete switched-law G60 analytical bound',
 'scope':'Exact rational/analytical verification only; not a Lean/compiler receipt, canonical adoption, recovery proof or full finite-stock mission.',
 'parameters':{'M':4,'c':3,'N':N,'alpha':ALPHA,'beta':BETA,'seed_pre30':6,'seed_post30':0,'K':K,'theta':str(THETA),'b0':str(B0)},
 'branching':{'pre_switch_full_rows':pre_rows,'seed_free_live_rows':live_rows,
              'seed_free_live_count_range':[K,N],'corners_per_count_fuel':4,
              'seed_free_contraction_status':'siteOp <= -W/2+b0 on every live row and load rectangle',
              'maximum_seed_free_drift':pack(max_drift,0),
              'maximum_seed_free_drift_plus_half_W':pack(max_contract,0),
              'maximum_pre_switch_drift_plus_half_W':pack(max_pre,6),
              'corner_maxima':corner_records,'direct_binomial_check_counts':spots,
              'barrier_minimum':record(barrier[0]),'global_W_maximum':record(C),
              'prepared_region_maximum':record(prepared),
              'seed_free_a0_false_drift':record(zero_drift),
              'seed_free_a0_false_drift_plus_half_W':record(zero_residual)},
 'service':{'z':str(z),'rho':str(rho),'theta':str(theta_s),'Hs':str(Hs),'common_uniformization_rate':Lambda,
            'fueled_residual':str(srv),'live_envelope_rows':service_rows,
            'per_block_ceiling':str(service_ceiling),'used_per_block_allowance':'1/100000000',
            'blocks':600,'coordinate_quotas':6000,'total_credits':3000000},
 'g60':{'old_retention_b0_coefficient':old_coeff,'candidate_acquisition_b0_coefficient':8,
        'candidate_post30_retention_b0_coefficient':120,'total_direct_b0_coefficient':608,
        'old_prepared':str(old_initial),'candidate_initial_decay_upper':str(acquisition),
        'service_union_upper':str(service),'division_deficit_upper':str(divisions),
        'direct_complete_upper':record(direct),'unchanged_conservative_complete_upper':record(conservative),
        'conservative_minus_direct':str(112*B0)},
 'source_sha256':source_pins}
(HERE/'seed_free_retention_results.json').write_text(json.dumps(result,indent=2)+'\n')
(HERE/'SOURCE_DEPENDENCIES_SHA256.json').write_text(json.dumps(source_pins,indent=2)+'\n')
print('PASS seed-free RetCert with stronger live contraction; exact rows:',live_rows)
print('PASS seed-on full SiteCert; exact rows:',pre_rows)
for label,t in [('seed-free drift',max_drift),('seed-free drift + W/2',max_contract),('seed-on drift + W/2',max_pre)]:
    print(label,': maximum at',t[1:],'value',out(t[0]),'slack to b0',out(B0-t[0]))
print('All-count seed-free certificate intentionally FAILS at a=0,false: drift',str(zero_drift))
print('Direct binomial count checks:',spots)
print('Direct complete switched-law G60 upper:',str(direct),out(direct))
print('Unchanged conservative complete G60 upper:',str(conservative),out(conservative))
print('Conservative allowance slack:',str(conservative-direct))
