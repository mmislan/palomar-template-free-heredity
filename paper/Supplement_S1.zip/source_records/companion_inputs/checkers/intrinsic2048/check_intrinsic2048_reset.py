#!/usr/bin/env python3
"""Actual-network joint Ready-absorbed no-division drift, with band profiles.
The positive high-count tail handles returns below512; no individual
first-hit event is substituted for the joint Ready boundary.
"""
from fractions import Fraction as Q
from math import factorial
from time import monotonic
from band_exit_certificate import N,BETA,consuming,ceil_q
from band_profile_core import build_low_profile

STAGES=((Q(1,50),2048,258),(Q(1,50),1600,285),
        (Q(3,100),1504,291),(Q(3,100),1408,298))
EPS=Q(1,4700)

def f_tail(a):
    if a<=768:return Q((980-a)*(981-a)*(982-a),(a-10)*(a-9)*(a-8))
    return f_tail(768)*Q(10,11)**(a-768)
f=[Q(0)]*(N+2)
for a in range(510,N+2):f[a]=f_tail(a)
NORMALIZER=f[512]

def build_profile(kappa,cap):
    H,g=build_low_profile(kappa,cap)
    H.extend([[Q(0),Q(0)] for _ in range(N+2-len(H))])
    for a in range(512,N+2):
        if a<768:
            k=6*(1-Q(a,N))*(f[a+1]/f[a]-1)+a*(f[a-1]/f[a]-1)
        else:k=Q(5647*a,56320)-Q(6,11)
        delta=(Q(kappa)+k)/BETA
        assert 0<=delta<Q(1,10000)
        H[a]=[f[a]/NORMALIZER,f[a]*(1-delta)/NORMALIZER]
    return H,g


# Existing h generators are reused by their identical accepted constructor.
# New work: actual cap-dependent positive division reset bound at each stage.
from pathlib import Path
from math import comb
import json
ROOT=Path(__file__).parent;GRID=10**18

# NEW PRIVATE PORTABLE ENTRY. UNEXECUTED. Only intrinsic cap 2048 is required.
# Exact constructor code above is copied verbatim from the archived source.
import hashlib
DATA=Path(__file__).resolve().parents[2]/'inputs/planning/reciprocal_beta_recovery/base_beta8m_profile_upper.json'
assert hashlib.sha256(DATA.read_bytes()).hexdigest()=='1cbf7592037531b0c61ca9c5c01f40e418bf5932b291c25273490e535fb12542'
print('construct intrinsic2048 exact profile; no later cap stages',flush=True)
H,_=build_profile(258,2048)
exported=[[Q(x) for x in row] for row in json.loads(DATA.read_text())]
assert len(exported)>=512 and all(len(row)==2 for row in exported)
assert all(exported[a][r]==ceil_q(H[a][r],GRID) for a in range(512) for r in range(2))
assert all(H[a][0]>=H[a][1]>0 for a in range(16,N+1))
assert all(H[a][r]>=1 for a in range(16,512) for r in range(2))
# Old beta8m chemical/max input also supports the retained operating comparison.
for a in range(16,N+1):
    s=6*(1-Q(a,N));m=Q(a);b=800*a*(1-Q(a,N));death=400*a
    off=BETA*(3+Q(a,N))+800*N
    for r in range(2):
        w=H[a][r]
        drift=s*(H[a+1][r]-w)+m*(H[a-1][r]-w)
        if r:
            drift+=b*(H[a+1][0]-w)+death*(H[a-1][0]-w)+off*(H[a][0]-w)
        else:drift+=BETA*(H[a][1]-w)
        assert drift+258*w<=EPS
assert max(H[a][r] for a in range(16,N+1) for r in range(2))<=Q(112990484353,500000)
Hu=[[ceil_q(x,GRID) for x in row] for row in H]
M=[Q(0)]*(N+1)
hs=[int(row[0]*GRID) for row in Hu]
for a in range(32,N+1):
    choose=comb(a,16);total=0
    for k in range(16,a-15):
        total+=choose*hs[k];choose=choose*(a-k)//(k+1)
    M[a]=Q(total,GRID*(1<<a))
rows=[]
d=Q(93867565097,200000000)
for a in range(16,N+1):
    for r in range(2):
        x=max(Q(0),Hu[a][r]-Q(1,GRID))
        y=2*(1+Q(r)*(2*N+a)/N)*M[a]
        rows.append((y-d*x,a,r))
lo=max((row for row in rows if row[1]<=511),key=lambda row:row[0])
allmax=max(rows,key=lambda row:row[0])
assert lo[1]<=511 and lo[0]+11*allmax[0]<=0
assert 8+d==Q(95467565097,200000000)
report={'status':'PASS only if this new entry has actually been run',
        'cap':N,'profile_binding_below512':'exact upper-grid equality',
        'grid':GRID,'d':str(d),'C_old':str(8+d),
        'low_max':[str(x) for x in lo],'all_max':[str(x) for x in allmax],
        'residual':str(lo[0]+11*allmax[0]),'rows':len(rows),
        'profileSHA256':hashlib.sha256(DATA.read_bytes()).hexdigest(),
        'sourceSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ROOT/'intrinsic2048_reset_results.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS intrinsic2048 reset and literal profile binding',flush=True)
