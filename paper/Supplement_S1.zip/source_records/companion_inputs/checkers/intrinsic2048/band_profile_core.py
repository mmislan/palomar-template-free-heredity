"""Pure constructors for direction-resolved robust band-renewal profiles."""
from fractions import Fraction as Q
from band_exit_certificate import solve_band,N
BANDS=((16,31),(32,63),(64,127),(128,255),(256,511))
GRID=10**12

def up(x):return Q((x.numerator*GRID+x.denominator-1)//x.denominator,GRID)
def down(x):return Q((x.numerator*GRID)//x.denominator,GRID)
def solve(A,b):
    n=len(b);A=[list(row)+[b[i]] for i,row in enumerate(A)]
    for k in range(n):
        p=next(i for i in range(k,n) if A[i][k]);A[k],A[p]=A[p],A[k]
        d=A[k][k];A[k]=[x/d for x in A[k]]
        for i in range(n):
            if i!=k and A[i][k]:
                c=A[i][k];A[i]=[x-c*y for x,y in zip(A[i],A[k])]
    return [A[i][-1] for i in range(n)]

def build_low_profile(kappa,cap):
    local=[solve_band(L,U,kappa,cap,require_easy_condition=False,exit_fuel_resolved=False)
           for L,U in BANDS]
    K=[[Q(0)]*10 for _ in range(10)];b=[Q(0)]*10
    for j,(L,U) in enumerate(BANDS):
        for edge in range(2):
            ix=2*j+edge
            row=local[j][0 if edge==0 else U-L][0]
            if j:K[ix][2*(j-1)+1]=up(row[0])
            if j<4:K[ix][2*(j+1)]=up(row[1])
            else:b[ix]=up(row[1])
    A=[[Q(int(i==j))-K[i][j] for j in range(10)] for i in range(10)]
    g=solve(A,b);v=solve(A,[Q(1)]*10)
    assert all(x>0 for x in g) and all(x>=1 for x in v)
    for i in range(10):
        assert g[i]==b[i]+sum(K[i][j]*g[j] for j in range(10))
        assert sum(K[i][j]*v[j] for j in range(10))==v[i]-1
    H=[[Q(0),Q(0)] for _ in range(512)]
    for j,(L,U) in enumerate(BANDS):
        endpoint=[g[2*(j-1)+1] if j else Q(0),g[2*(j+1)] if j<4 else Q(1)]
        for a in range(L,U+1):
            for r in range(2):
                row=local[j][a-L][r]
                H[a][r]=sum(row[z]*endpoint[z] for z in range(2))
                assert sum(down(row[z])*endpoint[z] for z in range(2))>=1
            assert H[a][0]>=H[a][1]
    return H,g
