#!/usr/bin/env python3
"""Exact two-fuel count-band exit supersolutions for the original rates.
No simulation, compiler, external package, or multidimensional enumeration.
"""
from fractions import Fraction as Q
from time import monotonic

N=2048
BETA=Q(8000000)

def add(A,B):return [[a+b for a,b in zip(x,y)] for x,y in zip(A,B)]
def sub(A,B):return [[a-b for a,b in zip(x,y)] for x,y in zip(A,B)]
def mul(A,B):return [[sum(A[i][k]*B[k][j] for k in range(len(B)))
                     for j in range(len(B[0]))] for i in range(len(A))]
def inv2(A):
    d=A[0][0]*A[1][1]-A[0][1]*A[1][0]
    assert d
    return [[A[1][1]/d,-A[0][1]/d],[-A[1][0]/d,A[0][0]/d]]
def zero(cols=2):return [[Q(0)]*cols for _ in range(2)]
def consuming(a):return 800*a*(1-Q(a,N))+400*a+BETA*Q(a,N)
def ceil_q(x,den=10**6):return Q((x.numerator*den+x.denominator-1)//x.denominator,den)

def blocks(a,kappa,cap):
    seed=6*(1-Q(a,N)); passive=Q(a)
    birth=800*a*(1-Q(a,N)); death=Q(400*a)
    off=BETA+BETA*Q(a,N)+2*consuming(cap)
    lower=[[-passive,Q(0)],[-death,-passive]]
    upper=[[-seed,Q(0)],[-birth,-seed]]
    diagonal=[[seed+passive+BETA-kappa,-BETA],
              [-off,seed+passive+birth+death+off-kappa]]
    return lower,diagonal,upper

def solve_band(L,U,kappa,cap,require_easy_condition=True,exit_fuel_resolved=True):
    assert 16<=L<=U<=N and U<=cap<=N
    kappa=Q(kappa)
    if require_easy_condition:
        assert all(kappa>=a+6*(1-Q(a,N)) for a in range(L,U+1))
    labels=4 if exit_fuel_resolved else 2
    data=[];inverse=[];right=[]
    for a in range(L,U+1):
        lower,D,upper=blocks(a,kappa,cap)
        rhs=zero(labels)
        if a==L:
            for i in range(2):
                if exit_fuel_resolved:
                    for r in range(2):rhs[i][r]=-lower[i][r]
                else:rhs[i][0]=-sum(lower[i])
        if a==U:
            for i in range(2):
                if exit_fuel_resolved:
                    for r in range(2):rhs[i][2+r]=-upper[i][r]
                else:rhs[i][1]=-sum(upper[i])
        data.append((lower,D,upper,rhs))
        if a>L:
            factor=mul(lower,inverse[-1])
            D=sub(D,mul(factor,data[-2][2]))
            rhs=sub(rhs,mul(factor,right[-1]))
        inverse.append(inv2(D));right.append(rhs)
    answer=[None]*(U-L+1)
    for j in range(U-L,-1,-1):
        rhs=right[j]
        if j<U-L:rhs=sub(rhs,mul(data[j][2],answer[j+1]))
        answer[j]=mul(inverse[j],rhs)
    # Independent exact verification of the original, uneliminated equations.
    for j,(lower,D,upper,rhs) in enumerate(data):
        residual=mul(D,answer[j])
        if j:residual=add(residual,mul(lower,answer[j-1]))
        if j<U-L:residual=add(residual,mul(upper,answer[j+1]))
        assert residual==rhs,(L,U,kappa,'equation',j)
        assert all(x>=0 for row in answer[j] for x in row),(L,U,kappa,'positivity',j)
        assert all(answer[j][0][z]>=answer[j][1][z] for z in range(labels)),('fuel order',L+j,tuple(z for z in range(labels) if answer[j][0][z]<answer[j][1][z]))
        assert all(sum(row)>=1 for row in answer[j]),('residence barrier',j)
    return answer

if __name__=='__main__':
    # Fixed, analytically motivated bands and tilts; not a parameter search.
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--all-bands',action='store_true')
    args=parser.parse_args()
    cases=((16,31,258),(32,63,500),(64,127,900),(128,255,1500),(256,511,2000))
    if not args.all_bands:cases=cases[:2]
    for L,U,kappa in cases:
        start=monotonic()
        h=solve_band(L,U,kappa,N)
        print('PASS band',L,U,'tilt',kappa,'cap',N,'count rows',U-L+1,flush=True)
        for a,j in ((L,0),(U,U-L)):
            for r in range(2):
                row=h[j][r]
                print('entry',a,'fuel',r,'label bounds',*[str(ceil_q(x)) for x in row],
                      'total<=',ceil_q(sum(row)),flush=True)
        print('elapsed seconds (diagnostic only)',round(monotonic()-start,3),flush=True)
