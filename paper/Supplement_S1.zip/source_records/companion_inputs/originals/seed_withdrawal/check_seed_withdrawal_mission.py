#!/usr/bin/env python3
"""Exact global arithmetic and source pins for deterministic time30 seed withdrawal.

This is additive cloud-only mathematical checking. It does not edit, import, or
execute frozen source checkers. Local row and generator arguments are separate
proof obligations, documented in SEED_WITHDRAWAL_HEREDITY_COROLLARY_20261013.md.
"""
from fractions import Fraction as F
from pathlib import Path
from math import factorial
import hashlib,json
ROOT=Path(__file__).resolve().parent
SRC=Path('ARCHIVE_PATH_003')
B=4000000; N=2048; b=F(13,10**7)

def lowerexp(x,n=200):
    v=t=F(1)
    for k in range(1,n+1): t*=x/k; v+=t
    return v

def ceiling(x,scale=10**18):return F(-((-x.numerator*scale)//x.denominator),scale)

G=F(48,10**8)+F(320,2900000)+600*(F(6,5)*b+F(1,10**8))+F(5184,10**10)
Gdirect=F(48,10**8)+F(320,2900000)+608*b+F(600,10**8)+F(5184,10**10)
assert G==F(9545923,9062500000)
assert G-Gdirect==112*b>0
assert lowerexp(F(15))>2900000
assert lowerexp(F(25))>10**10
bound=ceiling(G+F(11,100000)+10/lowerexp(F(8))+3/lowerexp(F(20)))
assert bound==F(4517975690072193,10**18)
assert 30+11*F(1,2)+10*2==F(111,2)<60
assert 300*4*2*500+300*4*3*500==3000000
common_lambda=4*(3*(6+800*N+400*N+N+B)+B+4)
post_lambda=4*(3*(800*N+400*N+N+B)+B+4)
assert common_lambda==93515864 and post_lambda==93515792
z=F(3,4); rho=F(79967,80000); theta=F(1650)
Hs=800*3*N*F(9,16)+3*B+8
assert B*(1-rho)==theta
residual=B*F(16,N)*(z-rho)+Hs*(1-rho)+theta*rho
assert residual==F(-598067,10000)
service=12/rho*z**(-500)/lowerexp(F(165))
assert service<F(1,10**8)
Cstar=4*B+2457603
assert B+1>=819200 and Cstar==18457603
s=F(400,22457607); t=F(1,10000)
k1=B*(t-s)/(1-t+s)
k2=(Cstar+1+3/(1-s))*s/(1-s)
assert 0<s<t<1 and k1>=k2
feed_exponent=4*s+240*k1-800000000*t
assert feed_exponent==F(-5508991479342664251200,5043026607980323551)<-1092
# Seed intensity <=72 until30 and exactly0 after30. Original bound suffices.
seed_exponent=F(4320,9)-5000*F(1,10)
assert seed_exponent==-20
# Strict exp(1/10)<10/9 supplies strict tail <exp(-20).
seed_switched_exponent=F(2160,9)-5000*F(1,10)
assert seed_switched_exponent==-260
# Exact series at .2 with a rigorous geometric remainder proves .2 tail bound.
x=F(1,5); l=lowerexp(x,30); term=x**31/factorial(31)
u=l+term/(1-x/32)
assert u-1<F(31,140)
division_exponent=960*F(31,140)-1200*F(1,5)
assert division_exponent==F(-192,7)<-20
paths=[
 'EXACT_SERVICE_AND_BRANCHING_SOURCE_20261013.md',
 'FULLER_ORIGINAL_G60_SOURCE_RETRIEVAL_20261013.md',
 'GENERIC_MISSION_AND_COMPOSITION_SOURCE_20261013.md',
 'LOWER_RATE_VALIDITY_AND_RESOURCE_SOURCE_20261013.md',
 'EXACT_CSTAR_RESOURCE_SOURCE_20261013.md',
 'beta1m_branching/BETA1M_BRANCHING_CERTIFICATE_20261013.md',
 'beta1m_branching/fixed_beta1m_branching_check.py',
 'beta1m_branching/reciprocal_beta_extension_check.py',
 'reciprocal_beta_recovery/UNIFORM_RECIPROCAL_BETA_RECOVERY_20261013.md',
 'reciprocal_beta_recovery/base_beta8m_profile_upper.json',
 'reciprocal_beta_recovery/uniform_reciprocal_beta_recovery_certificate.py',
 'historical_reference/TEMPLATE_FREE_RECOVERY_MANUSCRIPT_20261013.md',
 'lower_rate_mission/LOWER_RATE_MISSION_AUDIT_20261013.md',
 'lower_rate_service_next/GENERAL_CREDIT_TILT_AND_BETA4M_CANDIDATE_20261013.md',
 'general_credit_tilt_review/GENERAL_CREDIT_TILT_INDEPENDENT_REVIEW_20261013.md',
]
pins={str(SRC/p):hashlib.sha256((SRC/p).read_bytes()).hexdigest() for p in paths}
report={'status':'PASS','scope':'Global exact arithmetic, service and resource scalar gates; see separate full physical proof and exact local row reviews.','seed_switch_time':30,'seed_before':6,'seed_after':0,'beta':B,'G60_conservative':str(G),'G60_direct':str(Gdirect),'G60_slack':str(G-Gdirect),'full_failure_upper':str(bound),'success_lower':str(1-bound),'renewals_finish_by':str(F(111,2)),'credits_by60':3000000,'common_uniformization_rate':common_lambda,'post30_uniformization_rate':post_lambda,'service_residual':str(residual),'service_per_block_upper':str(ceiling(service)),'feed_cap':800000000,'feed_exponent_upper':str(feed_exponent),'seed_cap':5000,'seed_switched_exponent_upper':str(seed_switched_exponent),'division_cap':1200,'division_exponent_upper':str(division_exponent),'consumed_fuel_cap':800000004,'birth_plus_seed_cap':800005004,'discarded_slots_cap':7372800,'source_sha256':pins}
(ROOT/'seed_withdrawal_mission_results.json').write_text(json.dumps(report,indent=2)+'\n')
(ROOT/'SOURCE_DEPENDENCIES_SHA256.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps(report,indent=2))
