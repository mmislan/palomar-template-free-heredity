#!/usr/bin/env python3
"""Actual-network joint Ready-absorbed no-division drift, with band profiles.
The positive high-count tail handles returns below512; no individual
first-hit event is substituted for the joint Ready boundary.
"""
from fractions import Fraction as Q
from math import factorial
from time import monotonic
from band_exit_certificate import N,BETA,consuming,ceil_q
from band_profile_core import build_low_profile

STAGES=((Q(1,50),2048,258),(Q(1,50),1600,285),
        (Q(3,100),1504,291),(Q(3,100),1408,298))
EPS=Q(1,4700)

def f_tail(a):
    if a<=768:return Q((980-a)*(981-a)*(982-a),(a-10)*(a-9)*(a-8))
    return f_tail(768)*Q(10,11)**(a-768)
f=[Q(0)]*(N+2)
for a in range(510,N+2):f[a]=f_tail(a)
NORMALIZER=f[512]

def build_profile(kappa,cap):
    H,g=build_low_profile(kappa,cap)
    H.extend([[Q(0),Q(0)] for _ in range(N+2-len(H))])
    for a in range(512,N+2):
        if a<768:
            k=6*(1-Q(a,N))*(f[a+1]/f[a]-1)+a*(f[a-1]/f[a]-1)
        else:k=Q(5647*a,56320)-Q(6,11)
        delta=(Q(kappa)+k)/BETA
        assert 0<=delta<Q(1,10000)
        H[a]=[f[a]/NORMALIZER,f[a]*(1-delta)/NORMALIZER]
    return H,g


# Existing h generators are reused by their identical accepted constructor.
# New work: actual cap-dependent positive division reset bound at each stage.
from pathlib import Path
from math import comb
import json
ROOT=Path(__file__).parent;GRID=10**18
def ready_witness_coefficient(rows):
    low=[row for row in rows if row[2]<=511]
    value=Q(0);iterations=0
    while True:
        left=max(low,key=lambda row:row[1]-value*row[0])
        other=max(rows,key=lambda row:row[1]-value*row[0])
        nxt=(left[1]+11*other[1])/(left[0]+11*other[0]);iterations+=1
        assert nxt>=value
        if nxt==value:break
        value=nxt;assert iterations<=100
    g=ceil_q(value,10**9)
    residual_low=max(y-g*x for x,y,a,r in low)
    residual_all=max(y-g*x for x,y,a,r in rows)
    assert residual_low+11*residual_all<=0
    return g,left[2:],other[2:],iterations,residual_low,residual_all
profiles=[];results=[];jumps=[]
for duration,cap,rho in STAGES:
    start=monotonic();H,_=build_profile(rho,cap)
    assert all(H[a][0]>=H[a][1]>0 for a in range(16,cap+1))
    assert all(H[a][r]>=1 for a in range(16,512) for r in range(2))
    Hu=[[ceil_q(x,GRID) for x in row] for row in H]
    M=[Q(0)]*(cap+1)
    hs=[int(row[0]*GRID) for row in Hu]
    for a in range(32,cap+1):
        choose=comb(a,16);total=0
        for k in range(16,a-15):
            total+=choose*hs[k];choose=choose*(a-k)//(k+1)
        M[a]=Q(total,GRID*(1<<a))
    rows=[]
    for a in range(16,cap+1):
        for r in range(2):
            x=max(Q(0),Hu[a][r]-Q(1,GRID))
            y=2*(1+Q(r)*(2*cap+a)/N)*M[a]
            rows.append((x,y,a,r))
    g,left,other,iterations,rlo,rall=ready_witness_coefficient(rows)
    retained=2*(1+Q(3*cap,N));C=retained+g
    if profiles:
        prior=profiles[-1]
        ratio=max(H[a][r]/prior[a][r] for a in range(16,cap+1) for r in range(2))
        J=max(Q(1),ceil_q(ratio,10**12));jumps.append(J)
        assert all(H[a][r]<=J*prior[a][r] for a in range(16,cap+1) for r in range(2))
    profiles.append(H)
    result={'cap':cap,'rho':rho,'duration':str(duration),'retained_coefficient':str(retained),
            'daughter_coefficient_upper':str(g),'C_upper':str(C),
            'deficient_active_row':list(left),'other_active_row':list(other),'iterations':iterations,
            'residual_low_upper':str(ceil_q(rlo,10**18)),'residual_all_upper':str(ceil_q(rall,10**18))}
    results.append(result)
    (ROOT/('stage_profile_'+str(cap)+'_upper.json')).write_text(json.dumps([[str(x) for x in row] for row in Hu])+'\n')
    (ROOT/'stagewise_q1_reset_constants.json').write_text(json.dumps({'stages':results,'jump_factors':[str(x) for x in jumps]},indent=2)+'\n')
    print('PASS new stage reset',result,'seconds',monotonic()-start,flush=True)
assert jumps==[Q(1001764506893,10**12),Q(1),Q(1)]
Gamma=sum(dt*(Q(rho+4)-12*EPS) for dt,cap,rho in STAGES)
assert Gamma==Q(2893,100)-Q(6,23500)
U0=12*Q(112990484353,500000);J=Q(1001764506893,10**12)
exp_lower=sum(Gamma**k/factorial(k) for k in range(121))
I=sum(Q(row['duration'])*Q(row['C_upper']) for row in results)
bound=J*U0*I/exp_lower
q1=ceil_q(bound,10**15)
output={'Gamma':str(Gamma),'integrated_reset_constant':str(I),
        'J_total':str(J),'initial_potential_upper':str(U0),
        'q1_cap_killed_upper':str(q1)}
(ROOT/'stagewise_q1_results.json').write_text(json.dumps(output,indent=2)+'\n')
print('PASS actual cap-killed all-q1 bound',output,flush=True)
