# Template-free heredity of an acquired catalytic repertoire

Author:

## Abstract

Can a catalytic repertoire be acquired and then inherited after external catalyst input stops? We prove sufficient conditions for this form of template-free heredity in a stochastic population of dividing compartments. Seeds introduce a supplied catalyst that may initially be absent. With time normalized so each site has basal division rate one, every catalyst-seed channel stops at30; direct self-amplification and parental partition then sustain the expanded repertoire through60. Both actual daughters inherit every required catalyst at every division in the protected interval, while the current population repeatedly rebuilds its reserves and keeps performing useful chemistry. At an explicit four-site, three-catalyst operating point, the same finite-stock path delivers three million service credits, each one firing of a modeled assigned conversion channel, under individual species, site and short-block quotas, and completes ten selected division/recovery episodes through60 with success probability exceeding99.5%. The analysis retains shared-fuel competition, molecular loss, complementary sister allocations and additional divisions under the switched dynamics. Fuel and precursor supplies remain available within finite budgets. The inherited property is the presence of a prescribed functional repertoire; fidelity of species proportions and selectable hereditary alternatives require further results.

## 1. The scientific question: from acquisition to inherited function

A compartment can contain catalysts, grow their numbers and divide without preserving a useful chemical organization. A rare catalytic type may disappear when material is partitioned, even when the parent's total catalyst inventory is large. A population may also recover its catalyst counts while failing to perform useful chemistry during recovery. To demonstrate heredity in such a system, one must connect establishment, physical transmission and continuing function on the same operating history.

Here the inherited property is categorical: each compartment contains every member of a prescribed catalytic repertoire. We ask whether a population prepared with two old catalytic types can acquire a third supplied type, transmit the expanded repertoire through actual divisions, and repeatedly regain sufficient catalyst reserves while meeting ongoing output obligations. The model contains direct self-amplification but no sequence-template-reading or sequence-copying channel. In this precise sense its hereditary mechanism is template-free.

The distinction between acquisition and inheritance matters. Input can introduce a previously absent type, and catalytic amplification can increase it. Once the expanded repertoire is established, however, our successful paths retain every required type in both daughters immediately after division. These paths do not establish a type, lose it at division and then recreate it from absence. Physical partition supplies the direct connection between a parent's repertoire and its daughters' repertoires.

Seed withdrawal makes the acquisition-to-maintenance transition observable in the model. An absent type cannot amplify itself before some input introduces it. Continuing immigration could then obscure whether the acquired inventory supports maintenance. We therefore switch every seed channel off at deterministic time 30, on every realization regardless of whether acquisition has succeeded. The successful postwithdrawal population must retain its repertoire, replenish copies through catalytic birth and meet its assigned output without further catalyst immigration. Supplied fuel and precursors cannot recreate a candidate absent from the entire population: catalytic birth needs existing candidate copies, and division only redistributes a parental inventory.

Compositional heredity provides a broader setting for this question. Growing and splitting molecular assemblies can preserve a biased organization through catalytically enhanced recruitment [1]. Structural autocatalytic closure, as studied in the RAF framework [2], addresses catalytic support and construction from a food set. It does not itself bound the probability of a particular population surviving molecular loss, stochastic partition and resource competition while meeting output deadlines. The present problem is kinetic and probabilistic.

Activity, inheritance and evolvability also impose different tests. Studies of compositional replication have identified limits to selectable variation [3] and investigated additional structures that support limited heritable variation [4]. Experiments on autocatalytic RNA networks likewise show that network structure influences production and compositional change, with substrate-determined relaxation limiting distinct inherited states [5]. Those RNA experiments provide context, rather than an experimental realization of this model. Fatty-acid vesicle experiments demonstrate growth and division with distribution of encapsulated contents [6]; here the compartments and division rule are supplied.

The immediate predecessor, Useful catalytic acquisition under fixed operating constraints [7], already proves acquisition, retained floors, distributed service and divisions after seed withdrawal at a higher shared-rate parameter. The present advance combines these properties with repeated population-wide recovery and finite cumulative supplies at the lower rate. A separate earlier construction [8] tests both daughters' return to the same labelled chemical-state region. Our categorical repertoire trait uses different premises and a coarser hereditary standard; its theorem is not imported into the present law.

The second distinction is between inheritance at a division and renewal over time. A population needs sufficient copy numbers to withstand repeated partitioning and chemical loss. We therefore prove repeated return to a simultaneous reserve threshold for the actual population while output channels remain active. This combines repertoire retention with renewed operating capacity. The proof follows the current population at four fixed sites; population turnover can replace particular descendants.

Our quantitative result is a sufficient operating regime for this mechanism. It does not characterize every regime in which repertoire heredity is possible. Its explicit thresholds, rates and deadlines make the conditions auditable and reveal what the argument needs: prepared old catalysts, establishment time for the candidate, enough copies to protect complementary daughters, replenished local fuel, restoration of catalyst reserves and a finite allocation of all gross inputs.

## 2. The mechanism and the apparatus supplied to it

There are four occupied spatial sites. At site i, the counts of three prescribed catalytic species are a_ij, each between zero and a cap N=2048. One binary fuel variable R_i is shared by all three species at that site. A fuel token can support a catalytic birth, active loss or assigned consuming conversion, after which the local fuel is empty. One firing of an assigned conversion channel earns one service credit. This is an operational output count; the model specifies no particular chemical product or thermodynamic yield. Empty sites recharge, and occupied fuel can also discharge without useful output.

Two old species begin with at least 512 copies at each site. The candidate species may begin with any allowed count, including zero at every site. All initial fuel configurations are allowed. Seeds provide individual catalysts at a count-dependent rate. A catalyst's self-amplification channel has a rate proportional to its existing count and to available fuel, with a cap factor that suppresses growth as the count approaches 2048. Thus a type can enter through input and then amplify through the stipulated catalytic reaction. At zero count, its direct catalytic birth channel cannot operate.

At time 30, the seed coefficient becomes zero for all three species at all four sites. The switch removes immigration without changing the current molecular counts, fuel state or supplies. Catalytic births, losses, useful jobs and both division channels continue. After withdrawal, every new catalyst copy is produced by the prescribed catalytic birth reaction; fuel and precursor inputs remain available within their cumulative budgets. 

The shared fuel makes the species' histories dependent. Activity by one species empties the fuel available to the others. The same fuel also influences division. The theorem treats these coupled histories through the actual joint state and physical event law.

Every site has a basal division channel of rate one. Additional divisions are triggered at rates that depend on local fuel and catalyst abundance. At a division, the initiating parent and one uniformly selected distinct victim are replaced by the two daughters. This keeps the census at four sites. The victim's contents are discarded. For each species, a fair half-binomial allocation assigns k_j copies to one daughter and the remaining a_ij-k_j copies to her sister. These sister counts are complementary. The count-split variables of different species are independent conditional on the complete predivision state and mark, but the two daughters are dependent within each species.

A basal division partitions the parent's existing fuel between the daughters using a complementary fair-bit allocation. A triggered division first consumes the parent's fuel and credits its triggering conversion, then gives both daughters empty fuel. Both division channels overwrite the victim's fuel and catalysts. Those discarded quantities enter the gross accounting.

The model supplies the catalytic catalogue, specificity of each self-amplification reaction, compartments, fuel transport and the operations that perform division and replacement. The theorem proves reliability of the resulting stochastic chemistry and partitioning under a stated finite allocation of material. Figure 1 shows the mechanism.

*Historical schematic omitted from this text edition: Mechanism schematic. The adjacent text supplies the model and proof.*

**Figure 1. Mechanism schematic, not a simulation or experimental trajectory.** Candidate input and direct amplification establish an expanded catalytic repertoire. A single parent's complementary allocation produces the two daughters at the parent and victim sites. On successful protected post 30 paths, each daughter contains at least 16 copies of each required type. Later chemistry restores the current four-site population to the 512-copy reserve threshold; other divisions remain active. The32-copy parental condition is necessary, not sufficient, for a favorable random split. All seed channels stop at30; fuel and precursor feeding continue.

## 3. A complete quantitative heredity and renewal theorem

We use one central operating point, beta=4000000, for the common fuel recharge, discharge and ordinary-job coefficient. The two phases have different required repertoires: both old species are required before time 30, and all three species afterwards. Every required species at every site must deliver at least 500 conversion credits in each fixed 0.1 block of its applicable phase. A block is not suspended or extended during recovery.

| Parameter or obligation | Value | Mechanistic purpose |
|---|---:|---|
| Occupied sites; prescribed species | 4; 3 | Fixed-census compartment population and expanded repertoire |
| Per-species count cap at each site | 2048 | Finite catalyst capacity |
| Old-species preparation | At least 512 at each site | Initial reserve for the two established types |
| Protected copy floor | 16 | Required type remains present in every complete state |
| Simultaneous reserve threshold | Ready512 | All twelve current counts are at least 512 |
| Candidate establishment time | 30 | Time allowed for input and amplification |
| Service block; individual quota | 0.1; 500 | Continuing local productive function |
| Common fuel/job coefficient beta | 4000000 | Shared-fuel turnover and ordinary output rate |
| Active birth; active death coefficients | 800; 400 | Fuel-consuming catalyst gain and loss |
| Seed coefficient; passive loss coefficient | 6 before 30, zero thereafter; 1 | Acquisition input, then maintenance without immigration |
| Basal initiating-division rate | 1 per site | Continuing physical population turnover |
| Recovery allowance; next-division wait allowance | 0.5; 2 | Bounds on selected renewal episodes |
| Operating horizon | 60 | Common service and stock-accounting horizon |

The rates are in units of one basal division time. These parameters are benchmark design margins within the effective model.

**Theorem 1 (categorical repertoire inheritance with productive population renewal).** Start the finite-stock marked process with each of the two old species at least 512 at each site, arbitrary allowed candidate counts, and arbitrary fuel bits. Run the seed-withdrawal schedule in Section 2: every seed channel has coefficient 6 before 30 and zero from 30 onward. All other physical channels, including ordinary jobs and additional divisions, remain active. Then a single path satisfies all of the following simultaneously with failure probability at most 0.004517975690072193:

1. Throughout [0,30], each old species has at least 16 copies at every site, including every complete postevent state. Each old species at each site earns at least 500 credits in every one of the 300 fixed blocks (n/10,(n+1)/10], n=0,...,299.
2. At time 30, the candidate has at least 16 copies at all four sites. Throughout [30,60], all three species remain at least 16 at every site, including every complete division mark. Each species at each site earns at least 500 credits in each of the 300 blocks (30+n/10,30+(n+1)/10].
3. Every actual division in [30,60] gives both daughters at least 16 copies of every required catalyst. Each initiating parent therefore contains at least 32 copies of each type immediately before that division.
4. Every spatial site initiates at least five actual divisions in [30,60]. Eleven simultaneous Ready512 hits, interleaved with ten selected actual division/recovery episodes, finish by 55.5. The selected division waits are at most 2, and the initial and subsequent recovery intervals are at most 0.5.
5. By time 60, accepted recharges are at most 800000000, accepted seeds at most 5000 and actual marked divisions at most 1200. The gross quantities below remain within the declared finite stocks at every prefix of the same path.

For precision, let tau_0 be the first simultaneous Ready512 time at or after 30. Let sigma_r be the first actual division strictly after tau_(r-1), and tau_r the first simultaneous Ready512 time at or after the complete sigma_r mark, for r=1,...,10. The episode conditions and their deadline are

tau_0<=30+1/2, sigma_r-tau_(r-1)<=2, tau_r-sigma_r<=1/2, r=1,...,10.

tau_10<=30+11(1/2)+10(2)=55.5.

| Cumulative gross quantity through 60 | Ceiling |
|---|---:|
| Accepted feed/recharge entries | 800000000 |
| Initially occupied fuel tokens | 4 |
| Consumed fuel events | 800000004 |
| Accepted seed entries | 5000 |
| Catalytic-birth plus seed precursor entries | 800005004 |
| Actual marked divisions/daughter operations | 1200 |
| Catalyst-slot handling (discarded/restored slots) | 7372800 |
| Discarded victim fuel | 1200, already included within gross supply |

The catalyst-slot bound is handling and capacity accounting, using at most3N slots for a victim overwrite and hence3ND over the actual divisions. The source calls these discarded/restored slots; restoration of handling capacity is not an influx of catalyst molecules. The only catalyst-entry channels are seeds, withdrawn at30, and catalytic births paid by fuel and precursor supplies. Daughter counts still come from the parent's complementary partition.

The prepared initial catalyst inventory is separate: at most 16384 copies when the candidate is absent everywhere and at most 24576 when its initial counts are arbitrary. Intrinsic catalyst capacity is 24576 slots. If each ordinary or division-coupled conversion label debits one unit of its declared job substrate, 800000004 units give the stated finite upper allocation. The supplied apparatus performs compartment handling and replacement.

The service obligations comprise 2400 old-species site/block quotas before 30 and 3600 all-species site/block quotas afterwards. Each quota requires 500 credits. They therefore yield 1200000 credits in the first phase and 1800000 in the second, giving 3000000 by 60. The 55.5 deadline applies to the selected renewal sequence; all service obligations continue to 60. At least 20 divisions occur in the post 30 phase because each of the four sites initiates at least five. The ten selected episodes are embedded in this continuing population turnover.

For comparison, a continuously seeded population at the same beta=4000000 operating point satisfies the same complete event and advertised budgets. Other complete seeded parameter points use beta=8000000 with recovery0.2, or beta=4500000 with recovery0.5. Appendix G gives their full statements and proofs. The seed-withdrawal theorem above is the principal result; it establishes maintenance without catalyst immigration after the fixed acquisition phase.

## 4. What the daughters inherit, and what recovery restores

The hereditary conclusion follows from physical partition and the all-time floor event. At an actual protected post 30 division, the daughters at the two affected sites have, for every species j, the counts k_j and a_ij-k_j from one parent. The complete postmark floors require both counts to be at least 16. Their sum is the parent's count, hence a_ij>=32. Each daughter receives copies of all three required types through that split.

Once seeding stops, fuel and precursors cannot regenerate a candidate absent from the entire population: its birth rate is proportional to its existing count, and a split redistributes only existing parental copies. The all-sites-zero face is invariant under the postwithdrawal generator, as proved in Appendix H.10. A single empty site can receive the type from a positive donor through physical transmission. This shows why continued candidate function depends on acquired and transmitted inventory without requiring a molecular ancestry claim.

*Historical schematic omitted from this text edition: Phased timeline schematic. The adjacent text supplies the model and proof.*

**Figure 2. Phased operating timeline, not a simulated history.** Before 30, old-species floors and all old service quotas are protected while the candidate is established. From 30 to 60, all three species are protected and all corresponding service quotas apply. An initial recovery and ten selected division/recovery episodes fit by 55.5. Additional divisions and every physical output channel remain active; cumulative stocks stay charged throughout.

This identifies a concrete inherited property: membership in the complete catalytic repertoire. It does not require the daughters to have equal abundances. Their proportions can differ, and neither need immediately be Ready512. The 16-copy floor protects the type-presence claim; the 512-copy threshold measures a larger simultaneous reserve. The cap 2048 bounds the allowed state and capacity. These three numbers serve different roles.

A Ready hit before a selected division is also different from the parent's count at the division. The division may occur up to two time units after that hit, with chemistry and other divisions acting during the wait. We therefore obtain the 32-copy predivision consequence from the immediate daughter floors, rather than claiming that the parent was still at 512 just before it split.

Recovery follows the actual four-site population. Additional divisions can occur while a recovery interval is in progress. A named daughter may be selected as a later victim and disappear. A subsequent Ready hit concerns the compartments then occupying the four sites, including any replacements. It provides a renewed population reserve. Each of the ten selected divisions produces two actual daughters, whose individual survival until the next Ready hit is not guaranteed.

Function is assessed locally in space. Conversion counters record output at an initiating site and species. A victim replacement does not erase earlier output, and a division does not split an output ledger between daughters. A block boundary rebases its observational counter without changing molecules, fuel or reaction rates. Thus useful service can continue through turnover, but the historical credit in a ledger is not inherited molecular material.



## 5. Why the coupled proof works

The proof connects the operating requirements on one marked physical law. Each uses a quantitative inequality, and the joint conclusion pays their risks together. Appendices A-H contain the complete premises and proofs, including the separate switched-law argument.

| Scientific obligation | Full proof |
|---|---|
| Exact physical split and direct daughter inheritance | Appendix A and H.1 |
| Acquisition and every required count floor | Appendix B and H |
| Every local fixed-block output quota | Appendix C and H |
| Simultaneous recovery with continuing divisions | Appendix D and H |
| Exposed histories and episode composition | Appendix E and H |
| Gross supplies and identical-mark finite stocks | Appendix F and H |
| Other complete points; occupation-service extension | Appendix G |

**Establishment and retention.** A nonnegative count/fuel potential is at least one below the 16-copy floor and very small for prepared 512-copy states. Its full population drift includes chemical gain/loss and the actual complementary daughter marginals. This bounds old-species floor failure, establishment of an arbitrarily initialized candidate by 30 and its later floor failure. The candidate is not assumed to start prepared. The branching certificate also retains daughter counts below the protected floor; deleting those terms would change the argument.

**Productive continuity.** For a selected required site/species, an exponential credit potential combines ordinary output with the actual shared fuel bit. Its generator is evaluated with all other jobs, active chemistry and all incoming and initiating divisions included. On a protected block, the resulting decay bounds a 500-credit miss. Nonnegative division-coupled credits can only help the actual quota. Applying this estimate at exposed grid starts preserves every individual block obligation.

**Recovery under continuing divisions.** A two-fuel count profile measures remaining distance to simultaneous Ready512, while staying positive above that threshold so high-count returns are treated correctly. Summing coordinate profiles uses the full generator and preserves shared-fuel dependence. A separate positive reset operator accounts for the actual joint daughter mark, including the killed outcomes in which either daughter violates the floor. Complementarity supplies the two daughter marginals without treating sisters as independent. The intrinsic count cap, each count/fuel row and the full binomial allocation range enter the profile certificate.

**A physical clock for correlated resets.** Fuel balance bounds the cumulative division intensity. A bounded-jump martingale controls departures of this clock from its deterministic comparison. A pathwise Poisson time-change inclusion bounds many divisions even when the clock and its driving events depend on each other. Combining the profile bound for few divisions with the clock bound for many divisions gives a uniform surviving-nonreturn probability below 1/100000 over a 0.5 recovery interval. This is an intersection with floor survival. The floor-protection proof supplies the separate risk of leaving the admissible set.

**Withdrawal under the changed generator.** Before 30, acquisition uses the seed-on dynamics. After 30, the floor potential is evaluated on the established live region under the seed-free generator; the recovery profile is checked separately on that generator. The ordinary-service potential is unchanged by seed removal because seed entry alters neither its credit counter nor its fuel weight. The proof uses the actual distribution at the deterministic switch. It does not assume that less immigration improves the coupled population. The stock estimates and coupling carry this same deterministic schedule.

**Exposed histories and finite stocks.** The marked process restarts from the completed physical state at each selected stopping time. Each local estimate is multiplied by the indicator that preceding obligations succeeded and then averaged over the exposed past. The argument never conditions the future law on eventual global success. Eleven recovery allowances, ten division-wait allowances and three global stock tails are paid in addition to the complete acquisition/floor/service event. Prefix conservation identities charge accepted feed, all consuming channels and overwritten victim material. A finite-stock process uses exactly the same physical marks as its unlimited counterpart until the first attempted resource excess. On the bounded-resource event the entire operating history agrees through 60. Recovery and ledger boundaries replenish no stock.

For the central operating point, the complete acquisition/floor/service/division event has risk at most 9545923/9062500000. The joint composition is

failure <= 9545923/9062500000 + 11/100000 + 10 exp(-8) + 3 exp(-20)
        <= 0.004517975690072193.

The coefficients count distinct obligations; they are not an assumption that these events are independent. The full proofs retain the original stopping boundaries, complete marks and cumulative ledgers.

## 6. Scientific meaning and the limits of the operating regime

The result exhibits a specific route to template-free heredity: a supplied catalytic type enters a prepared chemical population, direct amplification builds its abundance, complementary partition transmits the expanded repertoire to both daughters, and subsequent chemistry restores the population's reserves while output continues. The inheritance claim is supported by the split itself, not by an analogy between population recovery and biological reproduction.

The required inputs are substantial. The model prescribes three self-amplifying catalysts and their specificity, provides occupied compartments and division operations, and uses rapid shared-fuel turnover. The theorem does not generate catalytic specificity, autonomous membranes or a chemical system from scratch. Seed input is withdrawn after acquisition in the strengthened theorem. Continued fuel and precursor supply remains essential.

The inherited repertoire is one specified categorical state. The theorem does not establish fidelity of molecular proportions, identify the ancestry of individual molecules, track ten generations of one uninterrupted lineage, compare multiple selectable hereditary states or prove open-ended evolution. The finite census and uniformly selected victim make the distinction between population renewal and persistent lineage essential.

The certified resource ceiling is also a bound on sufficient supply. Dividing 800 million accepted feed tokens by three million guaranteed output credits gives about 266.7. This ratio is a sufficient stock-to-guaranteed-output ceiling on the proved event. It is not measured consumption, a minimum resource cost or an energetic-dissipation result. No laboratory calibration is supplied for the time or rate units.

Seed withdrawal separates the environmental introduction of a type from the maintenance of its inherited contents. At each successful division, parental partition supplies the complete repertoire to both daughters; between divisions, copy-dependent catalytic birth replenishes losses while useful output continues. The finite-horizon theorem demonstrates that these requirements are compatible within one explicit stochastic mechanism and finite supply allocation.

The next questions concern cost, inherited variation and chemical implementation. How do copy reserves and supply margins scale with repertoire size? When can distinct catalytic states survive division and respond to selection? Which chemistry realizes the prescribed amplification, fuel sharing and partition? These questions connect the finite repertoire guarantee to quantitative fidelity, heritable variation and a chemically specified mechanism.

## A. Exact physical law and operating event

This appendix specifies the marked physical law and its observations. The chemical formulae use the coefficient beta of the operating point under discussion. The central theorem takes beta4000000; the original point takes beta8000000. The seed coefficient is6 in the baseline. Appendix H gives the separately proved deterministic seed-withdrawal law.



### A.1. Counts, shared fuel and the complete complementary division mark

The physical count/fuel projection is finite-state. External service and division ledgers are additive observations with unbounded natural values, so the full ledger-augmented source is countable-state; its total rate is uniformly bounded. The general finite-state theorem applies to the projected marked core, while conditional restart also carries all observations. There are four sites. Each site carries three counts a_ij in {0,...,N}, N=2048, and one shared binary fuel bit R_i. The rates relevant to a selected count a are:

- seed birth: 6(1−a/N), preserving fuel;
- passive death: a, preserving fuel;
- active birth: 800 R a(1−a/N), clearing that site's fuel;
- active death: 400 R a, clearing that site's fuel;
- ordinary consuming job: beta R a/N, clearing fuel, with beta fixed at the stated operating point.

Each fuel-zero site recharges at rate beta. Each fuel-one site has discharge rate beta. The three ordinary-job channels are physically active throughout recovery. Independent local source review confirms that the rate function the physical generator has no service-window, required-species, time, or ledger gate; the service predicates and external credit ledger in the original service-observation definition retain the same physical generator.

A site i has basal division rate 1 and total triggered division rate R_i sum_j(a_ij/N). The victim is a uniformly selected different site. Conditional on the full premark state, chosen parent, victim and division channel, the count mark k=(k_1,k_2,k_3) and bit e in {0,1} have joint probability

P(k,e | premark state, parent, victim, channel)
 =(1/2) product_(j=1)^3 [binom(a_ij,k_j) 2^(−a_ij)],
0<=k_j<=a_ij.

Thus the three count-split variables are conditionally independent half-binomial variables, and the fair bit is independent of their complete vector. The daughter count vectors are k and a_i−k; sisters are complementary within every species. Set Rstar=R_i for a basal division and Rstar=0 for a triggered division. The daughter fuels are Rstar*e and Rstar*(1−e). Hence a basal division preserves the parent's total fuel across the complementary daughters, while a triggered division empties parental fuel first. The total fuel loss is the victim's old fuel in the basal channel and one plus that fuel in a triggered channel, whose positive rate requires R_i=1.

The live domain is the set of states with every count at least 16 and at least one count below 512. The boundary consists of original first Ready H or first floor failure D. No individual count's first crossing replaces this simultaneous Ready condition. No persistent named-sister guarantee is asserted.

An admissible starting state lies in this live domain and may have arbitrary fuel bits. A state already Ready has zero nonreturn probability. A state below the floor is outside the admissible recovery set.

### A.2. Preparation, required floors and the exact G60 event

Fix two old species and one candidate in the supplied three-species catalogue. Initially each old species has at least512 copies at each of the four sites. Candidate counts may be arbitrary, including zero everywhere; fuel bits may be arbitrary. Base the external service and resource ledgers at time zero without changing any count or fuel. The initial prepared catalyst inventory is separate from subsequent seed and precursor inputs: it is at most16384 copies if the candidate is absent everywhere, and at most24576 if its initial counts are arbitrary. At most four initial occupied fuel tokens are supplied.

Define G60 by the following simultaneous conditions:

1. On [0,30], both old species have at least16 copies at every site at every time, including complete post-jump states. Each old job earns at least500 conversions per site in every one of the300 fixed blocks (n/10,(n+1)/10], n=0,...,299.
2. At time30, the candidate has at least16 copies everywhere.
3. On [30,60], all three species have at least16 copies everywhere at every time. Each job earns at least500 conversions per site in each of the300 fixed blocks (30+n/10,30+(n+1)/10]. Each spatial site initiates at least five actual divisions during this phase.

This is the exact event whose failure is at most1/500. It includes acquisition, every applicable floor, every grid service quota and the post-phase division requirement. Its probability premise is the prepared old512 founders, not an arbitrary floor16 recovery start.

## B. Establishment and retention of catalytic types

The branching potential controls preparation, acquisition and every required floor. Its full daughter moments and all-natural bounds are distinct from the killed recovery profile.


### B.1. The reciprocal-beta branching family

Put hh(a)=1/[(a+1)(a+2)(a+3)(a+4)(a+5)], D_br=1860480 and C_br=D_br*hh(12)/(3/4)^12=1275068416/16120377. Define

A_br(a)=C_br*(3/4)^a for0<=a<=12,
A_br(a)=D_br*hh(a) for a>=13,
g_br(0)=-A_br(0)/2,
g_br(a)=A_br(a)*min(6a,70) for a>=1,
W_beta(a,1)=A_br(a),
W_beta(a,0)=A_br(a)+g_br(a)/beta.

Here1 is fueled and0 is unfueled. This branching potential has a deliberately negative fuel gap at count0. It is separate from the recovery potential in Appendix D.5; no fuel-order assumption is imposed on the branching certificate at0.

The ratio A_br(a+1)/A_br(a) is3/4 through the geometric prefix and(a+1)/(a+6) from a=12 onward, including the join. At beta=1000000 the unfueled branch also decreases: its0-to1 ratio is6000036/7999996, and through the remaining varying prefix its multiplier numerator m>=1000000 increases by at most6, so3(m+6)/(4m)<1. Its later multiplier is constant. Both branches are positive, their global maximum is C_br<80, A_br(15)=1, and their below16 minimum is1. Monotonicity gives the prepared bound W_beta(a,R)<=6/10^8 for every a>=512. These are all-natural statements, including counts beyond N. For beta>=1000000, the unfueled weights are convex combinations of A_br and their beta1m values; all these bounds therefore persist over the continuum.

For B_a distributed as Bin(a,1/2), the identity

E_hh(a)=E[hh(B_a)]
 =32hh(a)-(32/24)*sum_(j=0)^4[(-1)^j*binom(4,j)*2^(-a-j-1)/(a+j+1)]

The moment identity follows from

hh(k)=(1/24) integral_0^1 t^k(1-t)^4dt, s=(1+t)/2.

The exact moments of A_br and g_br are

EA(a)=D_br*E_hh(a)+2^(-a)*sum_(k=0)^min(a,12)[binom(a,k)*(A_br(k)-D_br*hh(k))],
EG(a)=70EA(a)+2^(-a)*sum_(k=0)^min(a,11)[binom(a,k)*(g_br(k)-70A_br(k))].

These finite expressions retain all daughter counts, including counts below the protected floor. Write u=a/N, v=H_f-beta*U_f, and x=1/beta. The admissible foreign loads are exactly0<=U_f<=2 and0<=v<=1843200. The literal residual siteOp+(1/2)W_beta is affine in U_f,v. Thus its four-corner bounds imply its bound at every interior load.

For completeness, with A=A_br(a), g=g_br(a), Aplus=A_br(a+1), Aminus=A_br(max(a-1,0)), and corresponding gplus,gminus, the fueled residual is Tinf+x*T1 and the unfueled residual is Finf+x*F1, where

Tinf=(6+800a)*(1-u)*(Aplus-A)+401a*(Aminus-A)
 +(1+u+U_f)*g+2EA-2A+(u+U_f)*(2EA-A)+A/2,
T1=800a*(1-u)*gplus+400a*gminus+v*g+[1+2*(u+U_f)]*EG,
Finf=6*(1-u)*(Aplus-A)+a*(Aminus-A)-g+2EA-2A+A/2,
F1=6*(1-u)*(gplus-g)+a*(gminus-g)+2EG-(3/2)*g.

The beta-times-fuel-gap terms survive at x=0; this endpoint is the algebraic residual limit. The exact witness compares all2049*2*4=16392 count/fuel/corner rows at x=0 and x=1/1000000, and verifies the affine identities against the literal operator. Their respective upper bounds are8/10^7 and131/10^8. The finite moment formulas above specify those rational checks, with full-binomial comparisons at the joins and maximizing rows. For lambda=1000000/beta,

R_beta <=(1-lambda)*(8/10^7)+lambda*(131/10^8).

At beta=4500000, lambda=2/9, giving137/150000000<13/10^7. The independently implemented direct beta4.5m operator also checks all16392 rows; its maximum is at count954, fueled, U_f=2,v=1843200, and is bounded by177551208159/200000000000000000. Hence the complete new SiteCert has floor16, theta_A=1/2, b0=13/10^7, Wmax80 and prepared bound6/10^8. Its nonnegative theta_A permits the source SiteCert.toRet transfer.

The same family gives b'=131/10^8 for every beta>=1000000 and restores b0 for every beta>=1020000. The specified beta1m candidate still fails b0 in42 high-count rows; that failure is preserved. This local branching family alone does not establish a full beta1m mission.

### B.2. Original beta8m branching and service certificate

For completeness, the original certificate underlying this event has the following explicit form. Put r(a)=a!/(a+5)!, A0=1/r(15)=1860480, C0=A0*r(12)/(3/4)^12, and define

W(0,R)=C0*(1+10^(-7)R)/(1+10^(-7)),
W(a,R)=C0*(1+2*10^(-6)(1−R))*(3/4)^a, 1<=a<=12,
W(a,R)=A0*(1+9*10^(-6)(1−R))*r(a), a>=13.

The source certificate cert0 verifies W>=0, W<=80, W>=1 below16, and W<=6/10^8 above512. For foreign species load U_f and fuel-loss load H_f, the literal source gives

0<=U_f<=2,
beta*U_f<=H_f<=beta*U_f+800*2048*(9/16)*2.

The one-species population operator is obtained by adding the chemical rows in Appendix A.1, basal daughter gain minus twice the old potential, and triggered daughter gain minus the parental potential; dropping incoming triggered-victim losses is an upper bound. Its source-checked local inequality is

L sum_i W(a_ij,R_i) <= −(1/2) sum_i W(a_ij,R_i)+4*b0,
b0=13/10^7.

These inequalities are the original explicit finite certificate, not a supplied acquisition-success kernel. The binomial identities and each rational row are established in the original branching-certificate proof and the CF3 site modules. The fuel load bounds retain the dependence between foreign triggering and consumption.

For service, use Y_ij=2^(−q_ij)*(rho if R_i=1 else1), rho=99911/100000. On a required floor16 live state its literal generator satisfies L Y_ij<=−7120Y_ij. A missed500-credit requirement is dominated by (2^500/rho)Y_ij. For the initiating-division counter, L(6^(−nd_i))<=−(5/6)6^(−nd_i), since the basal channel at each site has rate1. Both external counters survive victim overwrite.

Positive killed-tick iteration and its Poisson mixture convert these local inequalities to block bounds. At each block boundary, resetting observational q changes no physical state or channel. Induction with the guard sum of W, the candidate's decaying W during the pre-phase, and sum_i6^(−nd_i) during the post-phase gives

P(G60^c)
 <=48/10^8+320/2900000
   +600*((6/5)*b0+1/10^10)+5184/10^10
 <1/500.

Here exp(−15)<=1/2900000 pays arbitrary initial candidate counts, exp(−25)<=1/10^10 pays the division deficit, and the per-block service contribution is at most1/10^10. The exact source proof the original acquisition/service proof establishes these comparisons and the same 300+300-block induction. The initialization bound 48/10^8 uses only the eight prepared old coordinates. This is why no initial512 requirement is placed on the candidate.

The path interpretation also follows directly: at a live block start the killed tick is P(1_live f), so its nth power checks every complete post-tick state. Independent Poisson weights identify all-time floor survival. The positive first-block500-credit demand excludes a spurious zero-tick contribution from a dead phase start. Applying the deterministic Markov property at grid boundaries gives precisely the original iterated mission operator. Thus the source's the original acquisition/service event bound and G60 are the same event on the constructed marked law.

### B.3. Complete beta4m acquisition, floors and fixed-grid event

Use precisely the preparation and G60 definition in Appendix A.2. Only the eight old coordinates start at least512; candidate counts and all fuels are arbitrary. For species j put Phi_j=sum_i W_beta(a_ij,R_i). The actual full physical generator satisfies

L_Phi_4m<=-(1/2)*Phi_j+4*b0.

Indeed, sum the literal chemical terms. Basal parent gains are the two complementary daughter marginals minus the parent's weight; uniform basal victim losses sum to one additional copy of every site's weight, producing the source -2W term. For triggers, retain both daughter gains and the parent subtraction, dropping only the nonpositive victim loss. No independence between the sister counts is required. The summed SiteCert bound proves this drift on the unrestricted physical law.

For both old species together, stop at their first floor violation through60. The complete terminal state has summed potential at least1. Dropping the negative drift gives failure at most48/10^8+480b0. For the candidate, the unrestricted drift and initial Phi<=320 give

E_Phi_candidate_4m(30)<=320*exp(-15)+8*b0*(1-exp(-15)).

From30, another30 units of drift cost at most120b0. This includes a floor violation already at30, since a count below16 then has potential at least1. Acquisition and candidate-floor failure are therefore at most320exp(-15)+128b0. This uses the actual time30 candidate law, without imposing Ready512 at that time.

On the resulting floor-good event every required block has a live start and whole-block floor survival. At each exposed grid start, use the service theorem with its past-measurable admissible-prefix indicator; its intersection bound pays at most1/10^8 per block, over all600 blocks. Separately, each spatial site's actual initiating-division count dominates its rate-one basal count on[30,60]. The source tilt6 gives at most6^4 exp(-25) for fewer than five initiations at one site, or5184exp(-25) in total. No independence with service is needed.

Positive rational exponential polynomials give exp(15)>2900000 and exp(25)>10^10. Thus the direct physical-event proof gives a floor/acquisition coefficient608b0. Conservatively enlarge this to the retained source-compatible720b0 and obtain

G60_4m_budget<=48/10^8+320/2900000
 +600*((6/5)*b0+1/10^8)+5184/10^10
 =9545923/9062500000<1/500.

This complete event retains old floors and old-species site quotas before30; candidate establishment at30; all-species floors and site quotas afterwards; and five post30 initiating divisions at every site. There are2400 pre30 and3600 post30 coordinate-block quotas, each500, yielding1200000 plus1800000 conversions and3000000 by60. The smaller G60 allowance alone is not the full mission failure probability.

## C. Productive continuity under shared fuel

These estimates keep every ordinary service channel and physical division active. An observational quota is assessed at its own species, site and fixed block.


### C.1. General ordinary-credit tilt on the complete marked law

Fix a spatial coordinate (i,j). Let a be its physical count, R its shared site fuel and Q its ordinary conversion credits since the exposed start. The ledger Q is spatial: it is never split, overwritten or reset by a division. All other ordinary jobs remain on. Since division-coupled credits are nonnegative, a miss of the original source quota implies an ordinary-only miss.

For the literal four-site, three-species law, with alpha=800 and N=2048, define

Y_tilt=z^Q*(rho if R=1 else1), 0<z<=rho<=1,
Hs_tilt=alpha*c*N*(9/16)+c*beta+8.

**General credit-tilt theorem.** Let1<=K<=N be an integer required count floor. Assume the selected species j belongs to the current required set, and let D be the first complete physical mark that violates that set's floors. Suppose theta_tilt>=0 and

theta_tilt<=beta*(1-rho),
beta*(K/N)*(z-rho)+Hs_tilt*(1-rho)+theta_tilt*rho<=0.

From every live complete physical state, at any deterministic duration w and any integer quota m>=1,

P_tilt(D>w,Q_w<m)<=rho^(-1)*z^(-m)*exp(-theta_tilt*w).

The statement has the physical stopping-history form at every finite exposed start, conditional only on that start's complete past. It is an intersection bound; it does not condition on future floor survival.

**Proof.** When R=0, recharge contributes exactly -beta*(1-rho)*z^Q. Seeds and passive deaths preserve the weight. Ordinary jobs and active local chemistry cannot fire. An incoming division leaves the fuel empty or supplies fuel; either choice preserves or decreases this potential. Hence the empty-fuel generator is at most -beta*(1-rho)*z^Q.

When R=1, the selected ordinary job contributes exactly beta*(a/N)*(z-rho)*z^Q. Discharge and the two other ordinary jobs have total rate at most3beta. For one active birth/death pair, its combined rate is alpha*N*u*(3/2-u)<=alpha*N*(9/16); the three pairs therefore cost at most alpha*c*N*(9/16). These events clear fuel, with weight increment (1-rho)*z^Q. Seeds and passive deaths preserve this count-independent weight.

Every division touching the selected site is included. Its own total intensity is at most4; the incoming-victim intensity is at most the sum of three donor bounds4/(M-1), also4. At every complete mark the new fuel weight is at most1 and ordinary Q is unchanged. Thus all touching divisions cost at most8*(1-rho)*z^Q, pointwise for arbitrary donors and complementary sister marks. Non-touching marks preserve the local function. State-null marked divisions remain counted. Consequently

L_tilt_Y/z^Q<=-beta*(1-rho) when R=0,
L_tilt_Y/z^Q<=beta*(a/N)*(z-rho)+Hs_tilt*(1-rho) when R=1.

On the live domain a>=K, the selected coefficient is nonpositive. Replace a by K to obtain an upper bound. The two hypotheses then give L^D Y<=-theta_tilt*Y. Killing on a floor exit replaces a nonnegative postmark value by zero and only decreases the generator.

The physical state space is finite; the external unbounded credit ledger is not part of a finite-state claim. Its marked exponential tilt can be represented on the finite physical states. Alternatively, the elementary killed process exp(theta_tilt*t)*Y_t has nonpositive drift and is bounded on every finite time interval by exp(theta_tilt*w). Localization and bounded convergence give

E_tilt[1_(D>w)*Y_w]<=exp(-theta_tilt*w)*Y_0<=exp(-theta_tilt*w).

On a quota miss Q_w<m, Y_w>=rho*z^m; the exponent m rather than m-1 is conservative. This proves the probability inequality. At an exposed stopping time, restart on the completed physical state as in Appendix E.1. Multiply the pointwise estimate by any past-measurable live/success-prefix indicator and average using the tower property. No future-event conditioning, independent sisters or stationary fuel law enters the argument.

This proof uses the ordinary-job coefficient beta. The original source service theorem hard-codes the credit factor1/2 and may additionally use a division-coupled selected credit with coefficient beta+1. It cannot be invoked by simply replacing that factor with z. The theorem above is a separate full-physical-law proof.

### C.2. Exact beta4m service and branching inputs

Take beta=4000000, K=16 and

z_4m=3/4, rho_4m=79967/80000, theta_4m=1650,
Hs_4m=14764808, Lambda_4m=93515864.

The written Par.Valid conditions M>=2,N>0,alpha>=0,beta>=0,epsilon>=0 hold. The literal rate formula in Appendix C.3 gives the displayed positive Lambda, which exceeds theta_4m. The empty-fuel hypothesis is equality, and the fueled residual is

service_residual_4m=beta*(16/2048)*(3/4-rho_4m)
 +Hs_4m*(1-rho_4m)+1650*rho_4m=-598067/10000<0.

Let P_n(x)=sum_(k=0)^n x^k/k!. Since P_n(x)<=exp(x) for x>=0, the block union over at most12 required coordinate quotas satisfies the exact rational comparison

service_block_4m<=(12/rho_4m)*(4/3)^500/P_200(165)
 <1948303823/250000000000000000<1/10^8.

Every source0.1 block remains individual, and no readiness, moving window or pooled total replaces its quotas. The exact rational witnesses verify this displayed inequality; a factorized lower polynomial [P_100(33/2)]^10 supplies an independent stronger comparison. Neither uses a floating-point exponential.

The full branching family from Appendix B.1 applies to this physical beta. Its reciprocal interpolation gives

branching_4m_bound=8/10^7+(1/4)*(131/10^8-8/10^7)
 =371/400000000<13/10^7=b0.

All-natural nonnegativity, Wmax80, W>=1 below16 and W<=6/10^8 at counts>=512 follow from the same explicitly proved family. This is a new W_beta at beta4m; it is not the old beta8m certificate transplanted to another law. The independent witness also assembles all16392 literal count/fuel/load-corner rows and cross-checks complete binomial daughter moments at the joins and maximizing count. Those finite diagnostics supplement the analytical family proof; they do not replace it.

### C.3. Legacy beta4.5m service and generic event substitution

The written validity conditions are M>=2,N>0,alpha>=0,beta>=0,epsilon>=0; all hold. At this point the literal uniformization rate and service load are

Lambda_low=4*[3*(6+800*2048+400*2048+2048+4500000)+4500000+4]=101515864,
H_s_low=800*3*2048*(9/16)+3*4500000+8=16264808.

Choose rho_low=22481/22500 and theta_s_low=3800. Then1/2<=rho_low<=1,0<rho_low,0<=theta_s_low<=Lambda_low and theta_s_low=beta*(1-rho_low). The other literal source service premise has residual

service_residual_low=(beta+1)*(16/2048)*(1/2-rho_low)
 +H_s_low*(1-rho_low)+theta_s_low*rho_low
 =-1949591/115200 <0.

The service potential remains Y_ij=2^(-q_ij)*(rho_low if fueled else1), with quota multiplier2^500/rho_low. For n required species, the source-normalized aggregate service term is

S_low(n)=(4n/rho_low)*2^500*exp(-380)
 <=3653/10^17 <1/10^10 for n<=3.

The exact comparison uses the degree-100 Taylor polynomial

P_100(19)=sum_(j=0)^(100) (19^j/j!),
exp(380)>=[P_100(19)]^20.

This lower bound uses no decimal exponentials. The killed-law and Poisson normalization is unchanged, so this is the actual fixed500-credit source requirement.

We invoke the generic mission_lower statement with the new SiteCert, not the fixed-p0 theorem or its auxiliary constants. Its remaining premises are theta_A=1/2>=0 and<=Lambda_low, b0>=0, z=6>=1, Lambda_low>=1 and block width1/10>=0. Set quota m=500, terminal division demand5 and pre/post block counts300. Positivity of Lambda_low permits its cancellation in the literal definitions:

blockErr_low(n,cV,bV)=n*(4b0/10)+cV*bV*Lambda_low/10+S_low(n),
postErr_low=6^4*4*exp(-25)+300*blockErr_low(3,6^4,0).

The pre-phase has n=2,cV=1,bV=4b0/Lambda_low and the post-phase has n=3,cV=6^4,bV=0. Both whole per-block errors are therefore at most(6/5)b0+10^(-10). Candidate decay is exp(-15), and the division-deficit term is5184exp(-25). Initialization charges only the eight old prepared coordinates, giving48/10^8; arbitrary candidate counts give potential at most320. Rational lower Taylor bounds establish exp(15)>=2900000 and exp(25)>=10^10. Direct generic substitution yields

G60_budget_low=48/10^8+320/2900000
 +600*[(6/5)*b0+1/10^10]+5184/10^10
 =37968367/36250000000 <1/500.

Every generic premise and both phase errors have been reconstructed at the changed coefficient. W0_ready,cert0,blockErr_p0,cf3Rate_p0 and Hs_p0 are not reused as lower-rate certificates. Killed-tick iteration and its Poisson mixture, as in Appendix A.2, identify the same complete G60 event, including full post-mark floors and all quotas. Appendix E.1's physical restart construction uses Lambda_low here and carries the same external ledgers.

## D. Recovery with dependent daughters and a correlated physical clock

Here a recovery failure is surviving nonreturn before a simultaneous readiness hit and before floor exit. The separate acquisition/floor event pays actual boundary failure in the full theorem.


### D.1. General potential-and-resource-clock theorem

Let X_phys be a time-homogeneous finite-state physical marked CTMC with finite total marked-event rate in each state, including marked events whose state update is null. Specify a live state domain and let tau be its first exit time; a state-augmented equivalent may encode a history-dependent boundary. For a chosen run, stop at tau, retaining the actual terminal value of any auxiliary resource statistic.

Distinguish reset marks with predictable intensity nu and stopped count N_t. Null marked resets are counted. Let Q be the live generator with reset marks removed and included as killing; let B be their positive live-poststate gain operator.

Let A be an admissible set of live starting states. Suppose a nonnegative potential U and constants M, gamma, C > 0 satisfy

U >= 1 on live states,
sup_(x in A) U(x) <= M,
Q U <= −gamma U,
B U <= C U.

Suppose a bounded resource statistic F and constants Fmax, a, kappa, b, V > 0 satisfy

0 <= F <= Fmax,
nu−a <= −kappa L F on live states,
|Delta F| <= b,
sum_e rate_e(x)(Delta_e F)^2 <= V on live states.

The bounds include actual transitions into the boundary and terminal F values. L is the stopped physical generator. After retained stopping, nu=LF=0, so the drift inequality holds there automatically.

Then for every T>0, integer K>=1, delta>kappa Fmax, and 0<theta<3/b,

P(tau>T)
 <= M exp(−gamma T) sum_(j=0)^(K−1)(CT)^j/j!
  + P(Poisson(aT+delta)>=K)
  + exp[−theta(delta/kappa−Fmax)
         +VT theta^2/(2(1−b theta/3))].

This bounds surviving nonreturn, not recovery failure alone. A mission success theorem must separately control boundary failure.

### Conditional restart form

Let sigma be an almost-surely finite stopping time for the natural marked history of the underlying physical process, with X_phys(sigma) in A. Define the local boundary time in the shifted process X_phys(sigma+u), and freshly stop that run there. The same deterministic right-hand side bounds the conditional surviving-nonreturn probability given the complete history through sigma.

This follows from the marked strong Markov property and the uniform pointwise hypotheses. It does not resume a globally stopped chain after its old absorption, condition on future survival, or reset Ready history within a recovery word.

### D.2. Full proof: division words, resource balance and correlated clock

#### D.2.1. The low-word contribution

Write P_j(t) for the actual unnormalized live law with exactly j resets. The positive word equations are

P_0'=P_0Q,
P_j'=P_jQ+P_(j−1)B.

Induction using the U inequalities gives

P_j(t)1 <= P_j(t)U <= M exp(−gamma t)(Ct)^j/j!.

Summing j=0,...,K−1 proves the first term. Boundary killing remains in every word and every reset mark.

#### D.2.2. Resource balance controls the random clock

The compensated resource martingale is

M^F_t = F_t−F_0−integral_0^t LF(X_s)ds.

For the actual reset compensator Lambda_t=integral_0^t nu_s ds, the drift inequality gives

Lambda_T <= aT+kappa(F_0−F_T+M^F_T)
         <= aT+kappa(Fmax+M^F_T).

Consequently Lambda_T>aT+delta implies M^F_T>delta/kappa−Fmax. The initial resource is paid explicitly; no stationary approximation is made.

#### D.2.3. Bounded-jump exponential estimate

For |x|<=b and theta>=0, the exponential integral remainder gives

exp(theta x)−1−theta x
 <=(x^2/b^2)[exp(b theta)−1−b theta].

For 0<=b theta<3, the positive Taylor series gives

[exp(b theta)−1−b theta]/b^2
 <=theta^2/[2(1−b theta/3)].

The compensated-jump exponential calculation therefore yields a nonnegative exponential supermartingale. The local variance-density hypothesis bounds its predictable quadratic variation by VT. Exponential Markov inequality gives the third displayed term. Finite marked-event rates justify this calculation on every bounded time interval, including the stopped terminal jump.

#### D.2.4. The clock may be correlated with resets

Construct a unit-rate Poisson primitive Y for the aggregate physical reset channel, with the actual state-dependent marks sampled at its firings. Then N_T=Y(Lambda_T). Lambda and Y need not be independent.

The proof uses only the pathwise inclusion

{N_T>=K, Lambda_T<=aT+delta} subset {Y(aT+delta)>=K}.

Every Poisson path is nondecreasing, so this remains true for a clock depending on the same path. Split the live event by N_T<K or N_T>=K and union-bound the clock exception. This proves the theorem.

### D.3. Intrinsic-cap two-fuel profile and actual paired reset witness at beta8m

#### D.3.1. Rational two-fuel construction below the threshold

The intrinsic-cap profile h(a,R) is a rational count/fuel supersolution. Use the five bands [16,31], [32,63], [64,127], [128,255], [256,511] at common tilt 258 and nuisance cap N=2048. For a selected coordinate write

s(a)=6(1−a/N), m(a)=a,
b(a)=800a(1−a/N), d(a)=400a,
T(z)=800z(1−z/N)+400z+beta z/N,
off(a)=beta+beta a/N+2T(N).

The reference two-fuel generator is

G_ref u(a,0)=s(a)[u(a+1,0)−u(a,0)]
 +m(a)[u(a−1,0)−u(a,0)]+beta[u(a,1)−u(a,0)],

G_ref u(a,1)=s(a)[u(a+1,1)−u(a,1)]
 +m(a)[u(a−1,1)−u(a,1)]
 +b(a)[u(a+1,0)−u(a,1)]
 +d(a)[u(a−1,0)−u(a,1)]
 +off(a)[u(a,0)−u(a,1)].

In each band solve the two Dirichlet problems (G_ref+258)u=0: the left-exit column has boundary values one at the lower exit in either fuel and zero at the upper exit, and the right-exit column has the reversed values. The exact block-tridiagonal solve is followed by independent checks of the original equations, positivity, fuel ordering u(a,0)>=u(a,1), and row-sum barrier at least one. The two exit directions are merged over exit fuel only; the process inside each band still has both fuel states.

There are ten interface rows, the two count endpoints of each band in fuel zero. Build K from the corresponding neighboring-band exit coefficients, rounded upward to the grid 10^(-12), and b_term from the final band's upper-exit coefficient. The first band's lower exit is killed. Exact rational witnesses satisfy

g=b_term+Kg, g>0,
v=1+Kv, v>=1.

The second identity proves strict contraction in the weighted v norm. Within each band set h to the exact left and right exit columns multiplied by their neighboring interface values g; the terminal upper value is one and the floor value is zero. The outward interface comparisons dominate each actual continuation. Direct checks give h>=1 below 512 and h(a,0)>=h(a,1)>0.

This reference comparison is valid for the actual shared-fuel chemistry: T is increasing on [0,N], so the actual nuisance consumption is at most off(a). Its generator difference is the nonpositive product of that rate difference and u(a,0)−u(a,1). No independence of the two nuisance histories is used. The concrete rational constructors are the two-fuel band-exit constructor and the rational profile constructor; their unchanged independently audited equations specify the finite witness completely.

#### D.3.2. Positive tail and actual generator inequality

Above 512, the construction uses the positive tail

f(a)=(980−a)(981−a)(982−a)/[(a−10)(a−9)(a−8)] for a<=768,
f(a)=f(768)(10/11)^(a−768) for a>768,

and set h(a,R)=f(a)[1−delta(a)R]/f(512). For 512<=a<768 use

k(a)=s(a)[f(a+1)/f(a)−1]+m(a)[f(a−1)/f(a)−1],
delta(a)=[258+k(a)]/beta.

For a>=768 use

delta(a)=[258+5647a/56320−6/11]/beta.

The finite exact checks establish 0<=delta(a)<1/10000 for every tail count 512<=a<=2048. They establish h(a,0)>=h(a,1)>0 on ALL counts 16<=a<=2048, and h(a,R)>=1 for 16<=a<=511 and both R in {0,1}. The tail remains positive even when both values are below one. The conservative junction at 768 is included explicitly. Here G denotes the chemical generator with all division marks omitted. The uneliminated generator rows for every 16<=a<=2048 and both fuels, including the 511/512 interface and high-count returns, establish

G h <= −258h+1/4700.

Let U=sum_(i,j)h(a_ij,R_i). Shared fuel creates no difficulty for this sum: the full generator acts linearly on each actual coordinate function. On a live nonReady state U>=1. Removing resets as killing contributes at least 4, and original Ready/floor killing only decreases U. Therefore

Q U <= −(262−12/4700)U.

The finite maximum over a in {16,...,2048} and R in {0,1} is bounded by 112990484353/500000. Consequently the uniform initial bound for U is

M=12*(112990484353/500000)=338971453059/125000.

#### D.3.3. The actual paired reset inequality

For the reset, define

p(a,R)=1+R(2+a/2048),
M_h(a)=E[h(K,0)1{16<=K<=a−16}], K~Bin(a,1/2).

For a fixed retained site, each of the other three potential parents leaves it retained with victim probability 2/3. Each parental rate is at most 4. Thus its retained gain coefficient is at most (2/3)*3*4=8, and the total retained coordinate potential is at most 8U. Complementary-binomial symmetry and the pointwise fuel-zero envelope bound the daughter source by sum 2p(a,R)M_h(a). The full prestate fuel is retained in p; no independent daughters are substituted.

Because a live state has a count at most 511, a finite exact row check establishes

max_(16<=a<=511, R in {0,1})[2p(a,R)M_h(a)−d h(a,R)]
 +11 max_(16<=a<=2048, R in {0,1})[2p(a,R)M_h(a)−d h(a,R)] <= 0

where

d=93867565097/200000000.

Choosing the actual deficient coordinate as the first witness proves

B U <= C U,
C=8+d=95467565097/200000000.

For a<32 the moment M_h(a) is zero. For 32<=a<=2048 the rational witness sums every integer k from 16 through a−16 with its exact binomial weight. It rounds h upward to the grid 10^(-18) for the moment and uses that upper value minus 10^(-18), clipped below by zero, as a lower bound for each denominator term h(a,R). It verifies the displayed sum of the two finite maxima using these outward bounds. Thus the computed residual dominates the exact residual in every stated row. These finite assertions prove the local operator inequality; the proof does not assume recovery or infer it from sampled states.

Only the intrinsic count cap 2048 is used here. The profile and reset inequalities are time homogeneous and hold for any deterministic duration. None of the intermediate caps at times 0.02, 0.04, or 0.07, nor their cap-risk budget, is extended beyond 0.1 or used in this theorem.

### D.4. Fuel balance controls the actual division clock at beta8m

Set

F=sum_i R_i,
z_i=sum_j a_ij/N,
Z=sum_i R_i z_i.

On the live domain,

0<=F<=4, Z<=3F, nu=4+Z.

Let

A_active=sum_(i,j) R_i[800a_ij(1−a_ij/N)+400a_ij].

The literal event rates give

LF=beta(4−2F−Z)−A_active−D_fuel,

where D_fuel>=0 is the physical division fuel-loss drift. Since A_active>=400N Z,

LF<=beta[4−2F−(689/625)Z].

With c=1875/3317 and a=20768/3317, the relation Z<=3F gives

nu−a <= −(c/beta)LF,
kappa=c/beta=3/42457600.

Stopping retains the terminal fuel configuration. There is no artificial jump to a zero-fuel cemetery state. Every physical fuel jump has absolute value at most 2.

The predictable quadratic-variation rate is bounded channel by channel:

- recharge: at most 4beta;
- discharge and ordinary jobs: at most 16beta;
- active events: at most 12*450N=5400N, since 1200a−800a^2/N is maximized at a=3N/4;
- division: at most 4nu<=64;
- seed and passive jumps: zero contribution.

Thus V=20beta+5400N+64=171059264. This pays arbitrary initial fuel, every chemical consuming channel, and both basal and triggered division fuel losses.

The network therefore satisfies every hypothesis of the general theorem, uniformly over admissible physical restart states and marked histories.

### D.5. Uniform reciprocal-beta recovery family

Let H_upper(a,R) be the literal rational upper export of the accepted intrinsic-cap recovery profile, defined by the pinned rational profile export in the accompanying evidence. Below512, its exact predecessor profile lies in[H_upper-10^(-18),H_upper]. Define A_rec=H_upper(a,0) and Delta_rec=H_upper(a,0)-H_upper(a,1) for16<=a<512; set both to zero below16. At counts a>=512, use the exact tail f of Appendix D.3.2 and

A_rec(a)=f(a)/f(512),
Delta_rec(a)=A_rec(a)*(258+k_rec(a))/8000000,
k_rec(a)=6*(1-a/N)*(f(a+1)/f(a)-1)+a*(f(a-1)/f(a)-1) for512<=a<768,
k_rec(a)=5647a/56320-6/11 for a>=768.

The new function is defined by the rounded export below512 and the reconstructed exact tail above it. No equality between the rounded export and its exact predecessor is asserted. For every finite constant beta>=1000000, set c_gap=5500000 and

h_beta(a,0)=A_rec(a),
h_beta(a,1)=A_rec(a)-(c_gap/beta)*Delta_rec(a),
U_beta=sum_(i,j)h_beta(a_ij,R_i).

Here the recovery fuel order is h_beta(a,0)>=h_beta(a,1). The nuisance consuming intensity T_beta(z)=800z(1-z/N)+400z+beta*z/N is increasing on[0,N], since its derivative is at least beta/N-400>0. Therefore the actual shared-fuel chemical generator is bounded in the required direction by the reference off-rate beta*(3+a/N)+800N, without assuming independence of nuisance histories.

Let P be seed/passive count motion and J active count motion: Pg=6(1-a/N)[g(a+1)-g(a)]+a[g(a-1)-g(a)], Jg=800a(1-a/N)[g(a+1)-g(a)]+400a[g(a-1)-g(a)]. For x=1/beta, the uneliminated reference residuals (G_beta+150)h_beta are

R0_rec=P A_rec+150A_rec-c_gap*Delta_rec,
R1_rec=P A_rec+J A_rec+150A_rec+c_gap*(3+a/N)*Delta_rec
 +c_gap*x*[-P Delta_rec+(800a*(1-a/N)+400a+800N-150)*Delta_rec].

They are affine in x on[0,1/1000000], retaining both beta-times-gap cancellations. Exact checks of all4066 count/fuel rows verify both endpoint residuals: at most zero below512, at most1/4700 above it. They also verify every physical event-list identity at beta1m, and an independent direct implementation checks the4066 physical beta4.5m rows. Positivity, the below512 barrier at least1, and12max A_rec<=338971453059/125000 hold at the beta1m endpoint and extend by convexity.

The profile interval checks and exact tail gap give, for every beta>=1000000,

(9997/10000)*U_old <=U_beta <=(10000/9999)*U_old.

The positive killed division-gain operator is unchanged: division rates and all parent, victim, complementary daughter and fuel marks retain the law of Appendix A.1. Applying the comparison to the accepted intrinsic-2048 reset witness C_old=95467565097/200000000 gives

B_div U_beta <=[(10000/9999)*C_old/(9997/10000)]*U_beta <478U_beta,
Q_beta U_beta <=-(154-12/4700)*U_beta.

The second inequality sums chemical drift -150U_beta+12/4700, uses U_beta>=1 on the live nonReady domain, and retains at least4 reset killing. Original floor exits, simultaneous Ready killing and positive-tail returns remain in the operators. The reset transfer is pointwise under one positive operator and does not assert recovery-probability monotonicity between different path laws.

For the actual shared-fuel statistic F and marked division intensity nu, the argument of Appendix D.4 now gives

kappa_beta=3/(5beta+1200N),
a_clock_beta=4+12beta/(5beta+1200N)<=32/5,
nu-a_clock_beta <=-kappa_beta*L_beta F,
V_beta=20beta+5400N+64.

It follows directly from L_beta F=beta*(4-2F-Z)-A_active-D_fuel, A_active>=400N*Z, and Z<=3F. Terminal physical fuel, the initial payment4 and the jump-size bound2 are retained. Fix T=1/2,K=14,delta=1/100,theta=1/640. Uniformly, kappa_beta<=3/7457600 gives4kappa_beta<1/100=delta, and0<theta=1/640<3/2. Thus every applicability condition of Appendix D.1 holds. The clock exponent simplifies exactly to

E_beta=9141301/460320+(509/36825600)*(beta-1000000),
a_clock_beta*T+delta <=321/100.

Its positive slope proves the uniform exponent lower bound. Apply Appendix D.1-D.2 with M=338971453059/125000, gamma=154-12/4700 and C=478. All words0..13 and at least14 actual resets are covered. The correlated clock uses the same pathwise Poisson time-change inclusion; no count/clock independence is introduced. Positive Taylor lower polynomials and geometric-remainder upper polynomials yield

q_beta(1/2) <=M*exp(-gamma/2)*sum_(n=0)^13[(478/2)^n/n!]
 +P(Poisson(321/100)>=14)+exp(-9141301/460320)
 <=8622092430140/10^18 <1/100000.

The three separately rounded components are0.000001387409862688,0.000007232308304574 and0.000000002374262879. Their ceilings sum to one unit at10^(-18) more than the displayed once-rounded total; the latter follows from adding the underlying rational bounds before rounding. This is surviving nonreturn P_beta(H>1/2,D>1/2), uniformly from every count16..2048 and arbitrary fuel, with the physical stopping-time restart form of Appendix E.1. It does not itself pay floor failure or a full beta1m mission.

## E. Physical stopping histories and selected renewal episodes

The full marked restart law carries observations and cumulative stocks. Each success-prefix indicator is exposed before its local estimate is used.


### E.1. Full physical stopping-time restart

The bounded count/fuel projection is finite-state. The full source with external natural-valued q and nd, and with gross resource counters, is countable-state. Its total rate is bounded by Lambda=157515864. Construct it from independent exponential waits of rate Lambda and independent marks implementing the literal channels, complementary split and uniform distinct victim, with a residual dummy tick. Its tick kernel is I+L/Lambda. Dummy proposals consume no material and are not divisions; actual division marks remain counted if their projected count/fuel update is null.

At an exposed stopping index, independent tails of the wait/mark sequence prove restart by summing over the index's value. For an arbitrary finite stopping time sigma in the natural nonanticipating marked history, first prove restart at deterministic times by Poisson independent increments and exponential lack of memory. It then holds at grid-valued stopping times by splitting over their values. Approximate sigma from above by sigma_m=2^(−m)ceil(2^m sigma). On any bounded interval there are finitely many ticks almost surely, so X(sigma_m)=X(sigma) eventually; right continuity gives eventual equality of each fixed future cylinder. Dominated convergence and a monotone-class argument give the full conditional future-path law. Localization removes boundedness of sigma. The same limit retains the fresh residual wait and all unseen marks. No future waiting time is exposed in this filtration.

Consequently the source-specific recovery theorem applies at each admissible completed physical restart state, conditionally on the entire past. It applies to the original physical process freshly stopped at its local H/D boundary; it does not revive an already absorbed chain. Service-grid position, all gross stocks and past success flags remain carried history. Ledger rebasing is observational and never replenishes stock.

### E.2. Actual division/recovery episodes and first-failure composition

Let tau0 be the first time at or after30 when all twelve counts are at least512. For r=1,...,10 let sigma_r be the first actual basal or triggered division strictly after tau_(r−1), and let tau_r be the first whole-population512-ready time at or after the COMPLETE sigma_r mark. Define E(h,w) by

tau0<=30+h,
sigma_r−tau_(r−1)<=w,
tau_r−sigma_r<=h, r=1,...,10.

At each recovery start with all twelve counts at least16, Appendix G.1 bounds the local surviving nonreturn by q(h); an already Ready start has zero nonreturn. On G60 every relevant state after30, including a full division update, is floor-admissible. To compose, charge first failure only on the histories where previous episodes succeeded and no prior floor failure has occurred. Those indicators are measurable at the exposed start. Intersecting a late-recovery event with G60 is contained in surviving nonreturn, because G60 prevents its floor exit. Apply conditional restart and the tower property to the exposed indicators, without conditioning the future on G60 itself. Eleven recovery errors contribute at most11q(h).

At any finite start, the four state-independent basal clocks have total rate4. They can be realized as independent clocks among the physical channel drivers; the same fresh-law argument applies after stopping. The first actual division occurs no later than the next basal firing, even though triggered divisions and other chemistry are correlated. Each wait failure contributes at mostexp(−4w). Ten wait failures therefore contribute at most10exp(−4w), without independence between episodes.

Successful preceding deadlines imply

tau10<=30+11h+10w.

For h=1/5 and w=2 this is261/5=52.2, leaving all relevant deadlines inside the original [30,60] floor interval. The whole acquisition/service/division/recovery event on the original law therefore has failure at most

1/500+11q(1/5)+10exp(−8).

G60 also guarantees BOTH raw daughters'16-copy floors at each selected division. Ready at tau_(r−1) alone does not imply a512-copy parent just before sigma_r, which may be up to two time units later. Neither a larger immediate newborn margin nor persistent named-newborn survival until tau_r is asserted. Recovery is of the actual current four-site population, including any subsequent overwrite.

## F. Gross inventories and same-path finite-stock operation

Every identity is a prefix identity for complete marks. The finite supply argument transfers one entire operating path and never resets material at a recovery or ledger boundary.


### F.1. Gross balances, accepted-feed moment and original beta8m realization

Let A be accepted recharges, B catalytic births, E accepted seeds, H active turnovers, P passive decays, Q useful ordinary plus triggered jobs, U unproductive discharges, D actual divisions, W_R overwritten victim fuel, W_S overwritten victim catalyst counts, and S total catalyst count. Induction over the full marks gives, at every prefix including a terminal jump,

F=F0+A−B−H−Q−U−W_R,
S=S0+E+B−P−H−W_S,
0<=W_R<=D, 0<=W_S<=6144D.

Thus consumed fuel B+H+Q+U<=A+4, and B+E<=A+4+E. A trigger's fuel and useful credit are charged BEFORE splitting. A basal split conserves the parent's fuel; a triggered split has total daughter fuel zero. Victim losses are gross debits and are not canceled against daughters or counted twice in the same fuel currency. Useful conversions are credited exactly once to their initiating spatial site and species; inherited external history is not new daughter output.

The literal combined consuming intensity at an occupied site is bounded by C_star=34457603: maximize 800*2048*(3u/2−u^2)+(beta+1)u on0<=u<=1 for each of three species, and add the discharge beta. Its maximum occurs at u=1. Basal victim-fuel loss intensity is exactly F and additional triggered victim loss is at most3F.

For eta>=s>=0, set

k(eta,s)=max{beta*(exp(eta−s)−1),
                 (C_star+1+3exp(s))*(exp(s)−1)}.

The weighted test v=exp(−sF), tilting ONLY accepted recharge marks by exp(eta), has

L_eta v/v <=beta*(4−F)*(exp(eta−s)−1)
            +F*(C_star+1+3exp(s))*(exp(s)−1)
          <=4k(eta,s).

In a triggered division overwriting occupied fuel, use exp(2s)−1=(exp(s)−1)+exp(s)(exp(s)−1); the first token is charged in C_star and the extra victim token in the3exp(s) term. Positive weighted-tick iteration and the SAME Poisson clock give

E exp(eta*A_T)<=exp(s*(4−F0)+4T*k(eta,s)).

Take eta=1/10000, s=800/42457607, T=60. The elementary bound exp(z)−1<=z+z^2/[2(1−z/3)] for0<=z<3 yields the rational upper k

k_upper=11704058599555614193200/18025996259152434517.

The certified rational comparison is

4s+240k_upper−1558500000/10000
 =−377451736952843887250/18025996259152434517 <−20.

Therefore P(A60>1558500000)<=exp(−20), uniformly in arbitrary initial fuel. Seeds have total intensity<=72, so E exp(t E60)<=exp(4320(exp(t)−1)); t=1/10 and exp(1/10)<10/9 give P(E60>5000)<exp(−20). Actual divisions have intensity<=16. Their same marked-count exponential envelope has mean960; t=1/5 and exp(t)−1<=31/140 give P(D60>1200)<=exp(−192/7)<exp(−20). These are moment envelopes for state-dependent accepted counts, not assertions of independent Poisson counts.

Let R60 be the simultaneous three cap events. Its complement has probability at most3exp(−20) on the ORIGINAL unlimited marked law. On R60 the following declared stocks suffice through60:

| Gross quantity | Bound |
|---|---:|
| Accepted feed tokens |1558500000|
| Initially occupied fuel |4|
| Consuming fuel events |1558500004|
| Accepted seed entries |5000|
| Catalytic-birth plus seed precursor entries |1558505004|
| Actual divisions/daughter operations |1200|
| Discarded/restored catalyst slots |7372800|
| Discarded victim fuel |1200, already paid within the fuel supply|

Ordinary and triggered job substrates are debited by their actual uniquely credited conversion labels; Q<=1558500004 supplies a finite upper allocation if each declared job substrate costs one unit. This is a debit convention for the effective source, not a new microscopic reaction mechanism or universal energy tariff. Initial catalyst capacity is four times three times2048=24576 prescribed slots. Daughter formation, compartment handling and export/overwrite remain supplied operations.

Construct the finite-stock version with the SAME waits, channel, victim and complementary split marks as the original process, stopping at the first attempted excess of a declared original resource. Before that mark the complete paths and rates agree by induction; on R60 no excess occurs through60. Apply this coupling to the entire event G60 intersect E(1/5,2), already proved on the original law, and union-bound the three global tails once. Recovery does not reset a resource or use the unlimited-source generator after exhaustion.

**Joint finite-stock theorem.** From the preparation in Appendix A.2, with probability at least0.994, the same finite-stock path satisfies G60, E(1/5,2), and all the original resource bounds in the table. In particular it earns1200000 old-job conversions before30 and1800000 all-job conversions after30, totaling3000000 by60; every site initiates at least five post-phase divisions. The ten selected division/recovery episodes finish by52.2.

**Proof of the displayed reliability.** The preceding arguments give

failure<=1/500+11/50000+10exp(−8)+3exp(−20).

The positive series exp(1)>27/10 implies exp(8)>2800 and exp(20)>10^8, whence

failure<1/500+11/50000+1/280+3/10^8<3/500.

Thus success exceeds497/500=0.994, and in particular exceeds0.99. The independently certified finer outward mission ceiling is0.005574632462485986, consistent with this elementary bound. No recovery-cap risk is added: only the intrinsic2048 profile is used.

The3m-credit deadline remains60. The52.2 bound applies to the return sequence. G60 also embeds500 credits in any0.2 window wholly contained in its applicable phase: a full0.1 grid block lies inside that window. This pathwise fact holds at adapted window starts. It does not infer500 credits in arbitrary0.1 windows or transfer output to two named sisters.

### F.2. Exact beta4m recovery, budgets and complete finite-stock composition

The uniform physical recovery theorem of Appendix D.5 applies at beta4m because it applies at every finite beta>=1000000. It bounds surviving nonreturn, uniformly over all twelve counts16..2048 and arbitrary fuels:

q_4m(1/2)<=8622092430140/10^18<1/100000.

Use the completed-mark, physical stopping-time restart and successful-prefix composition from Appendix E.2. There are eleven recoveries, and ten first-actual-division waits of length2. Every wait has conditional no-division probability at most exp(-8), since all four basal clocks remain on; null marked divisions count. The success deadlines obey30+11/2+20=55.5<60. Every paid recovery is inside G60's floor-protection horizon. G60 supplies the event inclusion from late recovery to surviving nonreturn; the future physical law is never conditioned on G60. Credits and stocks are not replenished at any recovery boundary.

For gross resources, the source combined-consuming envelope is

Cstar_4m=beta+3*(819200+beta+1)=18457603.

The endpoint regime beta+1>=819200 holds. The +1 includes division-coupled consumption. As in Appendix F.1, basal victim-fuel loss has separate intensity F, and triggered victim loss is at most3F. Consequently the same SR3 physical moment argument gives

k_4m(eta,s)=max{beta*(exp(eta-s)-1),
 (Cstar_4m+1+3*exp(s))*(exp(s)-1)},
P_feed_4m(A60>B)<=exp[s*(4-F0)+240*k_4m(eta,s)-eta*B].

Take eta=1/10000, s=400/22457607 and B=800000000, with0<s<eta<1. The inequality exp(x)<=1/(1-x) for0<=x<1 bounds the two maximum entries by

k1_4m=beta*(eta-s)/(1-eta+s)=73830428000000/224557612393,
k2_4m=(Cstar_4m+1+3/(1-s))*s/(1-s),
k1_4m>=k2_4m.

The last inequality is exact cross multiplication of the displayed positive rational expressions. Paying arbitrary initial fuel by4s gives

feed_exponent_4m=4s+240*k1_4m-800000000/10000
 =-5508991479342664251200/5043026607980323551<-1092<-20.

Hence the accepted-feed tail is below exp(-20). This is an accepted-event occupation-sensitive bound, not a Poisson claim for accepted recharges or a raw-proposal mean. The unchanged seed intensity72 and marked-division intensity16 give, as in Appendix F.1, seed and division tails below exp(-20) at5000 and1200. The three resource tails are charged globally once.

The complete gross identities from Appendix F.1 hold at every prefix, including the terminal mark. On the common resource-good event:

| Cumulative accepted quantity through60 | Ceiling |
|---|---:|
| Feed/recharge entries A | 800000000 |
| Initially occupied fuel | 4 |
| Consumed fuel B+H+Q+U | 800000004 |
| Seed entries E | 5000 |
| Catalytic-birth plus seed entries B+E | 800005004 |
| Actual marked divisions D | 1200 |
| Discarded/restored catalyst slots | 7372800 |
| Discarded victim fuel | 1200, already paid within gross supply |

A trigger consumes its one token before splitting and can lose the victim's token too. The identity F0+A=F+consumed+victim-loss gives consumed<=A+4; adding1200 again to gross supply would double-charge victim losses. The same one-unit-per-credited-label substrate convention supplies ceiling800000004. Prepared initial catalyst inventory and24576 intrinsic catalyst capacity slots are supplied separately, as before.

Construct finite stocks with the identical waits, channels, parent/victim and complementary split marks until the first attempted declared-resource excess. Full paths agree before that mark. On the resource-good event no excess occurs through60; apply this coupling to the complete acquisition/service/recovery event, paying the three global tails once. No recovery or service ledger boundary replenishes a stock.

**Complete beta4m finite-stock theorem.** From the preparation in Appendix A.2, one finite-stock path satisfies every original G60 obligation,3000000 credits by60, ten selected division/Ready512 renewals by55.5 and all table ceilings, with

full_failure_4m<=9545923/9062500000+11/100000+10*exp(-8)+3*exp(-20)
 <=4517975690072193/10^18=0.004517975690072193<0.01.

For the last exact comparison, replace exp(8),exp(20) in the denominators by their positive degree200 rational lower polynomials, add all allowances, and take one outward ceiling at denominator10^18. The exact rational witnesses give the displayed ceiling. This is the full failure budget, including recovery, waits and resources.

## G. Other complete points and the occupation-service extension

These are separately specified proved parameter statements. The occupation-service result is an intersection estimate, and its missing occupation lower tail remains explicit.


### G.1. Original beta8m numerical recovery corollary

Use

T=1/5, K=9, delta=3/1000, theta=1/640.

The deterministic comparison clock and Bernstein exponent are

aT+delta=4163551/3317000,
theta(delta/kappa−4)−VT theta^2/[2(1−2theta/3)]
 =18817641/767200.

The exact rational checker gives separate outward component ceilings:

- words 0 through 8: 0.000008858008362762;
- Poisson count at least 9: 0.000006934993643584;
- clock exception: 0.000000000022272099.

Adding the exact rational expressions before the final ceiling yields

P(H>0.2,D>0.2)
 <=3948256069611/250000000000000000
 =0.000015793024278444 <1/50000.

The separately rounded component values are not used to assert a smaller rounded sum. The cutoff includes all words: 0 through 8 are handled by the potential, and at least 9 by the actual physical clock. No recovery sector is omitted.

The actual recurrence theorem is uniform at admissible stopping-time restarts. Starting already Ready is an immediate recovery. The result does not bound P(H>0.2) by itself: the separate floor-protection event must still be paid in a success statement.

### G.2. Complete operating tradeoffs

| Complete parameter point | Recovery allowance | Ten-renewal deadline | Credit deadline/count | Accepted-feed ceiling | Joint failure bound |
|---|---:|---:|---|---:|---|
| beta8000000 | 0.2 | 52.2 | 3000000 by60 | 1558500000 | <0.006 |
| beta4500000 | 0.5 | 55.5 | 3000000 by60 | 900000000 | <=0.005464632462485986 |
| beta4000000 | 0.5 | 55.5 | 3000000 by60 | 800000000 | <=0.004517975690072193 |

The beta4m point halves the original common fuel-related rates. Its feed ceiling is800million rather than1.5585billion, while its longer renewal deadline remains55.5 and every service deadline remains60. All points retain5000 seeds,1200 divisions and7372800 copy-slot ceilings. These are certified effective-model tradeoffs, not an optimized rate threshold or physical calibration. Even800million accepted feeds for3million guaranteed credits remains a large external resource assumption. The fixed-census acquisition/renewal meaning and other limitations of Section 6 remain in force.

### G.3. Complete beta4.5m statement

Use exactly the preparation in Appendix A.2: each of the eight old-species coordinates initially has at least512 copies; the candidate may have arbitrary counts, including absence everywhere; all fuel bits may be arbitrary. Initial catalyst inventories and the at most four occupied fuel tokens are supplied separately from subsequent birth and seed entries. Define G60 by all three conditions in Appendix A.2 on this new physical law, including acquisition at30, every pre/post floor and fixed-grid quota, and five initiating post-phase divisions at each spatial site. Define the actual marked renewal event E(h,w) as in Appendix E.2.

**Lower-rate theorem.** On one finite-stock path, G60, E(1/2,2), and the resource ceilings below hold simultaneously with failure probability at most

failure_low <=1/500+11/100000+10exp(-8)+3exp(-20)
 <=2732316231242993/500000000000000000
 =0.005464632462485986 <0.01.

The ten selected division/recovery episodes finish by

tau10_low <=30+11/2+20=111/2=55.5.

The unchanged service grid guarantees3000000 conversions by60:1200000 old-job credits before30 and1800000 all-job credits after30. The55.5 deadline concerns the renewal sequence, while the credit deadline remains60.

| Cumulative accepted quantity through60 | Ceiling |
|---|---:|
| Feed/recharge entries A |900000000|
| Initially occupied fuel |4|
| Consumed fuel B+H+Q+U |900000004|
| Seed entries E |5000|
| Catalytic-birth plus seed entries B+E |900005004|
| Actual divisions D |1200|
| Discarded/restored catalyst slots |7372800|
| Discarded victim fuel |1200, already paid within fuel supply|

The counts are accepted physical entries and events, with the same gross debit convention as Appendix F.1. Supplies are never replenished at a recovery or ledger boundary. The following proof establishes each new local input, the full generic mission substitution, and the stock bridge on this common law.

### G.4. Complete beta4.5m stock and stopped-history proof

For the new coefficient the exact combined consuming intensity at a fueled site is bounded by

C_star_low=beta+3*(819200+beta+1)=20457603.

Indeed each species contributes the concave quadratic800N*(3u/2-u^2)+(beta+1)u. Its maximum is at the admissible endpoint u=1 because beta+1>=800N/2. The extra1 includes the division-coupled job. Basal victim-fuel losses have intensity F; additional triggered victim-fuel losses have intensity at most3F. Consequently the actual source SR3 moment bound of Appendix F.1 holds with

k_low(eta,s)=max{beta*(exp(eta-s)-1),(C_star_low+1+3exp(s))*(exp(s)-1)},
P(A_T>B_feed)<=exp[s*(4-F0)+4T*k_low(eta,s)-eta*B_feed], eta>=s>=0.

Take eta=1/10000,s=450/24957607,T=60,B_feed=900000000. The positive-series inequalities exp(x)<=1/(1-x) and exp(x)-1<=x/(1-x), valid for0<=x<1, give

k1_low=beta*(eta-s)/(1-eta+s)=10228803500000/27728401377,
k2_low=(C_star_low+1+3/(1-s))*s/(1-s)=229753669385092050/622859685522649,
k1_low>=k2_low,
4s+240*k1_low-900000000/10000
 =-338119685867744343800/230678181435141613 <-20.

This proves P(A60>900000000)<exp(-20), uniformly in initial fuel. The witness includes both kinds of victim loss and uses the combined reaction envelope. A separate simpler proposal-clock proof remains valid: A60 is dominated by a Poisson proposal count with mean1080000000, and tilt1/100 gives P(A60>1100000000)<=exp(-1000000/11)<exp(-20). The sharper900-million bound is used in the theorem.

Seed and division intensities remain at most72 and16. The same exponential count envelopes as Appendix F.1 give P(E60>5000)<exp(-20) and P(D60>1200)<=exp(-192/7)<exp(-20). The gross identities are pointwise and unchanged, so at every prefix consumed fuel is at most A+4, birth-plus-seed entries are at most A+4+E, victim fuel is at most D, and discarded/restored catalyst slots are at most6144D. A trigger consumes its token before splitting and can additionally lose the victim's fuel; no token is omitted or charged twice. These identities give the table in Appendix G.3. Job substrates, if allocated by the original one-unit-per-credited-label convention, also have finite ceiling900000004. Initial catalyst capacity remains24576 prescribed slots, with apparatus and division operations supplied as before.

Construct the new finite-stock process with the same waits, channels, parent/victim and complementary split marks as its unlimited counterpart, stopping at the first attempted excess. Before that mark its full path agrees by induction; on the three resource-cap events no excess occurs through60. Their union risk is at most3exp(-20), charged once globally, and stocks never reset.

Finally apply the exposed-history argument of Appendix E.2 on this new physical law. Start recovery at30, then at each completed actual selected division mark. On each successful-prefix history the uniform bound in Appendix D.5 applies conditionally to the freshly stopped physical run. Intersecting late recovery with G60 implies surviving nonreturn, since G60 protects the floor over every required interval. The preceding-success indicator is measurable at the exposed start; the tower property never conditions the physical future on G60. Eleven recoveries cost at most11/100000. The four basal clocks still give each length2 wait a conditional no-division risk at most exp(-8), so ten waits cost at most10exp(-8), including state-null actual division marks.

Successful-prefix induction gives30+11/2+20=55.5<60, placing every charged recovery inside the protected post-phase horizon. Add the complete G60 risk and the three global stock tails, and use the same-path finite-stock coupling. Rational Taylor bounds on exp(8) and exp(20), rounded outward only after addition, give the displayed failure ceiling. This proves the full lower-rate theorem.

Relative to the retained beta8m case, the common beta coefficient is43.75% lower and the accepted-feed ceiling is about42.25% lower, with the recovery allowance increasing from0.2 to0.5 and the renewal deadline from52.2 to55.5. Both cases retain3000000 grid credits by60 and the same seed, division and7372800 copy-slot ceilings. The new bound amounts to300 accepted-feed units per guaranteed credit and remains a conservative effective-model stock guarantee. It establishes the same fixed-census acquisition and population-renewal meanings as Section 6. The full beta1m mission remains open, including its source service gap; the original0.1 recovery gate also remains open.

### G.5. General all-state affine count-fuel occupation theorem

Keep M=4,c=3,N=2048,alpha=800,epsilon=6 and a positive beta. Fix a spatial coordinate, let a and R be its actual count and shared fuel, and let Q count its ordinary credits since the exposed start. For an integer1<=L<=N put f(a)=min(a,L). Choose d>=0,lambda>=0 and z>0 satisfying

affine_hypotheses: z<=1-d*L, lambda<=beta*d,
beta/N*(z-1)+d*(H_affine+1)+lambda
 +d*v*(beta/N-lambda)<=0 for every0<=v<=L,
H_affine=alpha*c*N*(9/16)+c*beta+8.

The first condition makes every fuel weight strictly positive. Define

Y_affine=z^Q*(1-d*f(a)*R).

**Affine occupation-service theorem.** On every complete physical state, including counts below16 and arbitrary donor counts and fuels,

L_Y_affine<=-lambda*f(a)*Y_affine.

For the unchanged physical path let A_t=integral_0^t f(a_s)ds. Then

Z_affine(t)=exp(lambda*A_t)*z^(Q_t)*(1-d*f(a_t)*R_t)

is a nonnegative supermartingale. With Q based at zero, its initial expectation is at most1 uniformly over the physical start. These statements have the exposed finite stopping-time form.

**Proof.** At empty fuel, recharge contributes -beta*d*f(a)*z^Q. Seeds/passive changes preserve the weight1. Incoming division fuel can only lower the current weight, and active/ordinary local consumption cannot occur. Thus the generator is at most -beta*d*f(a)*z^Q, giving the required inequality by lambda<=beta*d.

At occupied fuel put v=f(a), rho_a=1-dv. The selected ordinary job contributes beta*(a/N)*z^Q*(z-rho_a). Since z<=1-dL<=rho_a and a>=v, replace a by v to upper-bound this nonpositive term. The discharge, foreign ordinary jobs, active birth/death pairs and all touching divisions have the envelope H_affine from the full channel argument in Appendix C.1. Every such complete event has new fuel weight at most1 and therefore increase at most d*v*z^Q, independently of count update and sister/victim marks. Seed births are nonpositive because f is increasing. Passive death contributes exactly

passive_affine=d*a*(f(a)-f(max(a-1,0)))*z^Q<=d*v*z^Q.

For1<=a<=L this is equality; at a=0 it vanishes; above L the exact increment vanishes. The two sides of the a=L seam are therefore treated correctly. At the intrinsic cap N, upward seed and birth rates vanish.

After adding lambda*v*Y, the fueled generator is at most

affine_residual=v*z^Q*[beta/N*(z-1)+d*(H_affine+1)+lambda
 +d*v*(beta/N-lambda)]<=0.

This proves the all-state generator theorem. The argument counts all physical donor replacements and complementary sister marks by a pointwise post-weight bound, rather than assuming independent sisters or a stationary fuel fraction. The external ordinary credit ledger is neither a count variable nor inherited daughter material.

The product/jump rule now gives nonpositive drift for exp(lambda*A_t)*Y_t. On[0,T], this process is bounded by exp(lambda*L*T), since0<1-dfR<=1 and0<z<=1. Localization followed by bounded convergence proves the supermartingale without claiming that the unbounded ledger-augmented state is finite. The physical state space and total marked rates are finite and bounded.

Killing at a complete floor exit sends the potential and future occupation rate to zero and only lowers the generator. Retained stopping instead stops the entire compensated process, including its occupation integral and ledger, at the physical boundary. Freezing the terminal physical state while continuing positive occupation indefinitely would not be this stopped theorem. For the intersection bound below, the unmodified physical law suffices, and required floor survival may simply be intersected afterwards.

### G.6. Exact beta1m witness and service-miss intersection

At beta=1000000 choose

affine_1m_values: L=512, z=3/4, d=17/1000000, lambda=17,
H_affine=5764808, rho_min=1-d*L=15489/15625>3/4.

Here lambda=beta*d and the coefficient d*(beta/N-lambda) is positive. The affine bracket is consequently maximized at v=512, where it equals

affine_1m_bracket=-1186611/400000<0.

This proves every count/fuel row analytically, including0,512,513 and2048. The preserved producer and independent witness texts additionally check the4098 lattice rows; their frozen exact results are numerical witnesses to the displayed argument, not a substitute for it.

Let A_t be the literal capped-count integral with cap512. On{Q_t<500,A_t>=10}, the supermartingale satisfies

occupation_terminal_bound: Z_t>=exp(170)*(3/4)^500*rho_min.

Markov's inequality and the uniform initial bound therefore give

occupation_service_bound: P(Q_t<500,A_t>=10)
 <=(15625/15489)*(4/3)^500*exp(-170)
 <4396459/10^18<11/2500000000000.

The strict rational comparison follows by replacing exp(170) in the denominator by P_300(170); the independent factorized lower polynomial [P_120(17)]^10 verifies it separately. The quota exponent500 is conservative because an integer miss has Q<=499. No floating-point exponential is used.

At a finite stopping time sigma, use the completed physical state and fresh Q^sigma,A^sigma on the following physical segment. The source marked restart from Appendix E.1 and the uniform initial bound give the same inequality conditional only on F_sigma. In particular, for any past-measurable successful-prefix event E and the original current required-set floor time D_req,

occupation_exposed_bound: P(E,Q^sigma_(1/10)<500,A^sigma_(1/10)>=10,D_req^sigma>1/10)
 <=(11/2500000000000)*P(E).

This is a joint-event bound conditional only on the exposed past. Dividing by the probability of future occupation or survival would assert a different, unproved conditional estimate. The original0.1 grid and500-credit quota are unchanged; recovery-by0.5 cannot replace or postpone a service block.

### G.7. The remaining occupation lower-tail obligation

The occupation-service theorem bounds a quota miss jointly with sufficient capped-count occupation. A lower tail for that occupation under the actual successful-prefix grid-start distributions is not yet proved. One reviewed sufficient state-weighted target is

P_x(A_i<10,D_j>0.1) <= [Phi_j(x)+4b'0.1]/100,
b'=131/10^8.

Here Phi_j sums the genuine four-site beta1m branching potential. If that target is later proved on the complete law, its grid-start costs can be controlled by the known branching drift, including the arbitrarily initialized candidate's time30 law. Together with the proved service bridge and a separately proved non-service baseline, the reviewed conditional G60 allocation is60203249/36250000000<1/500. This is a conditional implication, not a beta1m G60 theorem. The complete beta1m mission also needs its same-law recovery/restart, stocks and full composition attached to the operating event.

The failed sufficient methods described in the accompanying technical documentation do not give counterexamples to the physical occupation target. Full beta1m service/operation and the original0.1 recovery gate remain open. The complete beta8m, beta4.5m and beta4m results stand independently.



### G.8. Other evaluated beta8m deadlines and the open sharper gate

These alternative points use the beta8m physical system and its intrinsic-cap recovery constants.

Two other deliberately evaluated points remain valid:

- h=0.175, K=7: q(h)<=0.000164617431183082<1/2500. With w=2, tau10<=51.925 and the supplied risk expression is below 0.01.
- h=0.158, K=6: q(h)<=0.000632876226290382<1/1500. With w=2.5, tau10<=56.738 and the supplied risk expression is below 0.01.

All job credits remain on the time-60 service grid. These are transparent deadline/risk tradeoffs, not claims of an optimized parameter. The original beta8m principal point is h=0.2 with the original wait cap 2 and the stronger 1/50000 recovery allowance.

The original h=0.1, 1/2500 recovery gate is OPEN. The accepted partial certificates for that sharper problem remain valid, but are not silently substituted for the completed longer-deadline proof.

## H. Complete proof after deterministic seed withdrawal

This appendix proves the principal switched-law result at beta4000000. The all-count acquisition certificate applies before30; live-region retention and the seed-free recovery generator are treated separately afterward. The literal one-species branching operator with seed coefficient epsilon is denoted S with the seed coefficient as a subscript, and is specified by the full operator and daughter moments in Appendix B.1. All other physical channels retain Appendix A's law.


### H.1. Exact immediate inheritance consequence

Let the physical marked process have the source division law: a division at parent site i selects a different victim site v, draws a catalyst split vector K conditional on the complete premark state, and replaces sites i and v by the two daughter vectors

K and a_i(t-) - K.

For each catalyst j, K_j has the prescribed Binomial(a_ij(t-), 1/2) marginal; the daughters are complementary, not independent. A basal or triggered division changes fuel as in the source but does not add catalyst molecules during its division mark.

Let I be an interval with a fixed required catalyst set J. Suppose the event F(I,J) holds: at every time in I, including every complete postmark state, every site has at least 16 molecules of each j in J. Then at every actual complete division mark t in I whose two daughters are installed in the population,

16  <=  K_j  <=  a_ij(t-) - 16  for every j in J.

In particular, both daughters have at least 16 of every required catalyst, and the parent's predivision count satisfies a_ij(t-)  >=  32 for every j in J.

**Proof.** The two postmark site counts are precisely K_j and a_ij(t-)-K_j. Both sites belong to the population tested by F(I,J), so both are at least 16. Their sum is the parental predivision count. There is no intermediate chemical or seed mark inside this completed division update. This is a pathwise event implication and uses no conditioning or independence assumption. 

Apply this with J equal to the two old species before time 30 and all three species on [30,60]. In particular, it applies to all ten selected renewal divisions, which occur after time 30 and complete by 55.5. The all-time floor also excludes any local zero-count interval between the selected divisions on the successful path. Thus success is not being inferred merely from later recolonization after a zero count.


### H.2. The seed-withdrawal physical law and mission event

Retain M=4 sites, c=3 catalysts, N=2048, alpha=800, and beta=4,000,000 simultaneously in recharge, discharge, and each ordinary consuming job. A shared binary fuel bit controls the source channels at each site. Define the deterministic seed coefficient

epsilon(t) = 6 for 0  <=  t < 30, and 0 for t  >=  30.

The per-coordinate seed intensity is epsilon(t)(1-a/N). The supply is switched off at30 on every realization, regardless of whether acquisition has succeeded. No intervention is conditioned on acquisition or on future mission success. The switch changes rates only; it neither changes the state nor adds or removes resources. A deterministic switching time has no physical mark almost surely. Taking the seed-on convention at the single point 30 instead produces the same law.

All passive deaths, catalytic births, active deaths, recharge, discharge, ordinary jobs, basal divisions and triggered divisions remain as in the source. Divisions still overwrite a uniformly selected different victim; actual complementary sisters and the correct fuel losses are retained. State-null marked divisions still count. Ordinary jobs remain physically active at all times, including during acquisition and recovery.

Initially the two old species have at least 512 copies at every site. The candidate has arbitrary counts in 0,...,2048, including zero everywhere. All fuel bits are arbitrary. Resource and service ledgers start at zero without altering the physical state.

Write G60^off for the following event on this switched law:

- Through [0,30], both old species stay at least 16 at every site, including complete terminal marks, and every required old-species/site job gets at least 500 credits in each of the original 300 blocks (n/10,(n+1)/10].
- At time 30 the candidate is at least 16 at every site.
- Through [30,60], all three species stay at least 16 at every site, and every one of the twelve species/site jobs gets at least 500 credits in each of the original 300 post30 blocks.
- Each spatial site initiates at least five actual divisions during [30,60].

No quota is pooled or relaxed. A proof based on ordinary credits alone implies the original source quota event, which may also count division-coupled credits.

The physical state space is finite. The original epsilon6 envelope Lambda=93,515,864 bounds both phases; the epsilon0 envelope is 93,515,792. Independent Poisson waits and marks with the common envelope, using the time-dependent channel probabilities, construct the switched law. This also makes its agreement with the original seed-on law through time 30 immediate.


### H.3. Retention after seed withdrawal

Use the accepted beta-dependent branching function at beta=4m:

h5(a) = 1/[(a+1)(a+2)(a+3)(a+4)(a+5)],
C0 = 1860480 h5(12)/(3/4)^12,
A_br(a) = C0(3/4)^a for a <= 12, and 1860480 h5(a) otherwise,
g(0) = -A_br(0)/2,
g(a) = A_br(a) min(6a,70) for a >= 1,
W(a,true) = A_br(a),
W(a,false) = A_br(a)+g(a)/4000000.

The previously accepted all-natural properties remain exact: W is nonnegative, W <= 80, W >= 1 below count16, and W <= 6/10^8 at count >= 512. With seeds on, it has the full all-count acquisition certificate drift

S_6 W  <=  -(1/2) W + b0,    b0=13/10^7.

Seed withdrawal changes the literal complete branching operator by

S_0 W = S_6 W - 6(1-a/N)[W(a+1,R)-W(a,R)].

It would be invalid simply to discard this term as beneficial. For this decreasing branching profile, removal increases its drift. Moreover, a seed-free all-count acquisition certificate with the same positive decay cannot be inferred at a=0.

The relevant postacquisition gate is the weaker **live-region retention certificate**: it requires the full branching drift only for live counts a >= 16, with the original below-floor barrier left intact. The separate exact rational retention witness enumerates all a=16,...,2048, both fuels and all four corners of

Hf=beta Uf+v,   0 <= Uf <= 2,   0 <= v <= 1,843,200.

Its operator includes every catalytic and passive channel, every fuel transition, and the full binomial daughter gains. Load dependence is affine, so corner verification covers every admissible pair. No artificial floor killing is substituted in this branching check. All16,264 live rows pass; the largest value of S_0 W+W/2 is less than0.000000899768126928, at a=951, fueled, Uf=2 and v=1,843,200. In particular, the checked seed-free rows give

S_0 W  <=  b0  on the entire live count/load domain.

This is precisely the restricted drift needed after time30. The pointwise shape/barrier properties are unchanged because W is unchanged.

For a species j let Phi_j=sum_i W(a_ij,R_i). The source's summation of actual division gains gives

L_t Phi_j  <=  -(1/2)Phi_j+4b0                 before30, all states;
L_t Phi_j  <=  4b0                           after30, while all j-counts >= 16.

For clarity, the basal summed gain contains the two daughter expectations minus parent and uniform-victim loss, giving the literal basal -2W term. For triggers, dropping the nonpositive victim-weight loss gives the source branching operator upper bound. Sister independence is never used; the two correct marginals suffice for this sum. Foreign-species counts may be arbitrary within 0,...,N in both estimates.


### H.4. Direct piecewise-time proof of G60^off

The proof does not plug epsilon0 into the original all-count mission theorem. It composes the seed-on acquisition law with seed-free live-region retention at a deterministic switch, using the same W on both sides.

#### Old-species floors

Stop the old-species summed potential at its first complete floor violation. Before the switch, discarding the negative all-count acquisition certificate drift gives rate <= 8b0. After the switch and before that first exit, the new live-region retention certificate gives the same rate <= 8b0. The below16 barrier implies the stopped potential is at least one when an exit has occurred. Optional stopping, or the finite marked-generator expectation calculation separately across time30, yields

P(old floor failure by60)  <=  8(6/10^8)+8b0*60
                          =48/10^8+480b0.

The terminal physical mark is included. No post-exit drift premise is used.

#### Acquisition and candidate floor

Up to time30 the law and full all-count acquisition certificate are unchanged. Since Phi_candidate(0) <= 320,

E Phi_candidate(30)
   <= 320 exp(-15)+8b0[1-exp(-15)].

From time30 stop at the first candidate floor violation; if the candidate is already below16 anywhere at time30, that stopping time is 30 itself. At a live post30 state the new live-region retention certificate gives drift <= 4b0. Taking expectations from the arbitrary time30 distribution therefore gives

P(candidate acquisition/floor failure through60)
   <= E Phi_candidate(30)+4b0*30
   <= 320 exp(-15)+128b0.

This charges acquisition failure and postacquisition retention together without conditioning on a future success event or supposing the candidate is already Ready512 at time30.

All required floors and acquisition are thus paid by

48/10^8+320 exp(-15)+608b0.

#### Fixed-grid service

The independently accepted generalized ordinary-credit potential is

Y=z^Q (rho if fueled, otherwise1),
z=3/4, rho=79967/80000, theta=1650.

It has no count-dependent factor. Seeds leave both Q and fuel unchanged, so their generator contribution is exactly zero. Removing them does not alter any step of its full physical channel proof. On the original required floor-live domain,

L_t^D Y  <=  -theta Y

in either phase. Explicitly,

beta(1-rho)=1650,
beta(16/N)(z-rho)+Hs(1-rho)+theta rho=-598067/10000,
Hs=14,764,808.

The proof includes all touching divisions, incoming victim replacements, shared-fuel chemistry and always-active jobs. Killing on the complete required floor exit only lowers Y. Its exposed-block-start intersection bound is

P(D>w, Q_w<500 | block-start history)
   <= rho^(-1) z^(-500) exp(-1650w).

With w=0.1, the sum over at most12 required coordinates is less than10^-8. Multiply by each past-measurable live-prefix indicator and apply the tower property; the complete floor-good event is used only as a subsequent event inclusion. The switch is a service-grid boundary, so every fixed block is wholly in one homogeneous phase. All600 blocks cost at most600*10^-8.

#### Initiating divisions

The state-independent basal initiation clock at each spatial site retains rate1 throughout [30,60]. Its actual initiation count is at least that basal count. The source z_div=6 exponential bound gives at most6^4 exp(-25) for fewer than5 initiations at a site, hence5184 exp(-25) over four sites. This requires no independence from service, floor, or recovery events.

#### Complete G60^off allowance

Combining the preceding three arguments proves the direct bound

P((G60^off)^c)
   <= 48/10^8+320 exp(-15)+608b0+600*10^-8+5184 exp(-25).

Use exp(15)>2,900,000 and exp(25)>10^10. Since608b0<720b0, the unchanged advertised conservative allowance remains valid:

P((G60^off)^c)  <= 9545923/9062500000.

The gap between the direct rational allocation and the advertised allocation is112b0. This slack is not needed elsewhere. It is retained to make the new seed-withdrawal theorem numerically identical to the accepted advertised mission bound.


### H.5. Seed-free recovery: exact generator gate

The recovery potential is different from W and is not monotone in count. Reusing its previous theorem without a generator check would be unjustified.

Use the same accepted reciprocal-gap potential at beta4m. For each count,

h(a,0)=A_rec(a),
h(a,1)=A_rec(a)-(11/8)Delta(a).

Below16 both entries are zero. For16 <= a<512, A_rec and A_rec-Delta are defined by the literal rational upper export of the accepted old profile. They are the definition of the new function; they are not falsely identified with the unknown exact old values. The old exact values lie between the export and that export minus10^-18.

For a >= 512 the physical tail and its fuel correction are reconstructed exactly:

f(a)=(980-a)(981-a)(982-a)/[(a-10)(a-9)(a-8)] for a <= 768,
f(a)=f(768)(10/11)^(a-768) above768,
A_rec(a)=f(a)/f(512),
Delta(a)=A_rec(a)[258+k(a)]/8000000,

with k(a) defined in Appendix D.3.2, including its conservative junction at768. The rational witness retains this original correction after withdrawing seed; changing a physical rate does not redefine the witness.

For the seed-free reference chemical operator the exact rows are

G0 h(a,0)=a[h(a-1,0)-h(a,0)]
           +beta[h(a,1)-h(a,0)],

G0 h(a,1)=a[h(a-1,1)-h(a,1)]
           +800a(1-a/N)[h(a+1,0)-h(a,1)]
           +400a[h(a-1,0)-h(a,1)]
           +[beta(3+a/N)+800N][h(a,0)-h(a,1)].

The reference dominates actual nuisance consumption because T_beta(z)=800z(1-z/N)+400z+beta z/N is increasing on[0,N] at beta4m, and h(a,0) >= h(a,1). This is a statewise sign comparison, not a nuisance-independence argument.

Every one of the4,066 count/fuel rows, including the16 floor boundary,511/512 join,768 tail junction and2048 cap, satisfies

(G0+150)h(a,r)  <= 0             for16 <= a<512,
(G0+150)h(a,r)  <= 1/4700        for512 <= a <= 2048.

The direct seed-free minimum source-adjusted decay ratios are at least152.25010591680908294 in fuel0 (at a=807) and471.362280546028176897 in fuel1 (at a=16). These diagnostics are not used as rounded premises; the full inequalities are checked with exact fractions.

The rational witness also verifies the exact identity

G0h = G6h -6(1-a/N)[h(a+1,r)-h(a,r)]

at every row. There are positive seed-generator terms at low counts, showing explicitly why a uniform monotonicity claim would have been wrong; at decreasing sections removal worsens the potential drift. Nonetheless the full seed-free inequalities retain the original decay coefficient150.


### H.6. Reset, clock and conditional recovery remain valid

The same pointwise profile properties and comparison with the old exact profile hold:

h(a,r)>0 on16,...,2048;
h(a,r) >= 1 below512;
(9997/10000)h_old <= h <= (10000/9999)h_old;
12 max h <= M=338971453059/125000.

The actual positive live-postdivision reset operator B_div is exactly unchanged: seed events are not division events, and all physical division rates, complete marks, victims, daughter states and Ready/floor killing are retained. Therefore the accepted old intrinsic2048 reset witness transfers pointwise by positivity:

B_div U  <= 478U,    U=sum_(i,j)h(a_ij,R_i).

This compares functions under one unchanged operator. It does not compare path probabilities with and without seeds. Removing all reset gains and keeping resets as killing gives at least4 additional killing. Since U >= 1 on a live nonReady population,

Q0 U  <= -gamma U,
gamma=150+4-12/4700=180947/1175.

The source general recovery theorem now applies directly to the seed-free homogeneous physical process after30.

Seeds do not change fuel, so removing them leaves the pointwise fuel balance and jump-variation bound intact:

F=sum_i R_i, Z=sum_i R_i sum_j a_ij/N,
nu=4+Z,
LF=beta(4-2F-Z)-A_active-D_fuel,
A_active >= 400N Z,
kappa=3/(5beta+1200N),
a_clock=4+12beta/(5beta+1200N) <= 32/5,
V=20beta+5400N+64,
|Delta F| <= 2.

Actual terminal fuel is retained at the local boundary. There is no artificial cemetery fuel loss. At beta4m, T=1/2,K=14,delta=1/100,theta_clock=1/640 give clock exponent28228801/460320 and comparison mean1080309/350900. The accepted conservative exponent9141301/460320 and mean321/100 remain valid.

Hence the same exact rational low-word/clock calculation gives

q_off(1/2)
  =sup_(admissible x) P_x^off(H512>1/2,D16>1/2)
   <= 8622092430140/10^18 <1/100000.

This includes every word with0,...,13 divisions and the event of at least14 divisions. The correlated reset clock is handled by pathwise Poisson time-change monotonicity, not by independence of the clock and its own primitive.

All recovery statements in Appendices H.5-H.7 are proved on the unlimited-stock switched physical law, carrying its cumulative resource counters; Appendix H.8 subsequently transfers the entire event to the finite-stock realization. For a stopping time sigma >= 30, conditional on the full natural marked history through sigma, the future physical law is the homogeneous seed-free law from the completed state. This follows either by the source marked strong-Markov construction restricted to the post30 process, or by restarting the common Poisson construction after the deterministic switch. Service-grid position, cumulative resource counters and past flags are carried without resetting; on this unlimited-stock law the physical transition rates after30 do not depend on those counters. Each recovery is freshly stopped at its local H/D boundary. An already-Ready state returns immediately. A state below16 is not an admissible recovery input.


### H.7. Eleven recoveries and ten actual division waits

Use the source renewal definitions:

- tau0 is the first simultaneous Ready512 time at or after30.
- sigma_r is the first actual basal or triggered division strictly after tau_(r-1).
- tau_r is the first simultaneous Ready512 time at or after the complete sigma_r mark, for r=1,...,10.

Require tau0 <= 30+1/2, each sigma_r-tau_(r-1) <= 2 and each tau_r-sigma_r <= 1/2. On successful prefixes,

tau10 <= 30+11(1/2)+10(2)=55.5<60.

Every exposed recovery start is post30, so Appendix H.6's seed-free conditional law applies. The all-time floor part of G60^off ensures the completed start is admissible, and that a late recovery on the full good event is contained in the local surviving-nonreturn event. Multiply each local estimate by the indicator of preceding success, no prior floor failure, and a currently admissible completed start, all measurable at that start, then apply the tower property. The latter restriction is essential because a division can create a below16 state outside G60^off; no recovery estimate is applied at that state. Do not condition the future physical law on G60^off itself.

The four unchanged basal clocks ensure that a first-actual-division wait exceeds2 with conditional probability at most exp(-8), including state-null marked divisions. No independence between episodes is needed. Eleven recovery allowances and ten waits cost at most

11/100000+10 exp(-8).

All3,000,000 credits remain on the unchanged grid through60. Recovery boundaries do not reset service blocks, replenish stocks or provide catalysts. By Appendix H.1, on the resulting mission every selected division, and indeed every complete post30 division through60, gives both actual daughters every required catalyst above the16-copy floor.


### H.8. All resources are paid on the switched law

The probability law has changed after30. Resource transfer is therefore justified by uniform physical generator inequalities, not by claiming accepted-feed counts are pathwise smaller without seeds.

#### Feed

The same pointwise consuming envelope holds at every state in both phases:

Cstar=4beta+2457603=18,457,603.

The seed channel changes neither feed counter A nor fuel F. It therefore contributes exactly zero to the source tilted feed/fuel generator. The same SR3 inequality holds before and after the deterministic switch and hence on their concatenation:

P(A60>B)  <=  exp[s(4-F0)+240 kappa_feed(t,s)-tB],
kappa_feed=max{beta(exp(t-s)-1),
                (Cstar+1+3exp(s))(exp(s)-1)}.

The basal and triggered victim fuel losses are still paid separately inside this bound. For t=1/10000,s=400/22457607,B=800000000, the same exact rational upper exponent is

-5508991479342664251200/5043026607980323551 <-1092<-20.

#### Seeds and divisions

The seed intensity is at most72 up to30 and exactly zero afterward. Thus its integrated mean-envelope is2160, not4320. Keeping the original5000 seed cap is conservative; t=1/10 and exp(t)<10/9 actually give a tail below exp(-260), hence below exp(-20). No seed is accepted after30 under the switched law.

Actual division intensity stays at most16 in both phases. The original1200 marked-division cap has exponent at most-192/7<-20. Accepted counts need not be independent Poisson variables; these are bounded-intensity exponential count estimates.

#### Gross stocks and finite-stock realization

The original exact pathwise ledgers remain valid, including every complete terminal jump:

F0+A=F+(B_cat+H+Q+U)+W_R,
consumed fuel <= A+4,
catalytic births+seeds <= A+4+E,
W_R <= D,   W_S <= 3ND.

On the common resource-good event the ceilings are:

- Accepted feed/recharge entries:800,000,000
- Consumed fuel:800,000,004, including at most4 initially occupied fuel slots
- Accepted seeds:5,000, all at or before30
- Catalytic-birth plus seed precursor entries:800,005,004
- Actual marked divisions:1,200
- Discarded/restored catalyst slots:7,372,800
- Discarded victim fuel:at most1,200, already paid within gross fuel supply

Prepared initial catalyst inventories remain an explicit initial condition. Catalytic birth after30 still consumes its required fuel and precursor resource; turning off basal seeds creates no free material or energy.

Construct the finite-stock *switched-law* process with the same waits, channel decisions, victim and complementary split marks as the unlimited-stock switched process, stopping at the first attempted declared-resource excess. Until that mark the processes agree. On the switched-law resource-good event no excess occurs through60. Apply this identical-mark coupling to the entire mission and charge the three global resource tails only once. No stock is replenished at time30, service boundaries or recoveries.


### H.9. Complete finite-mission inequality

Combining Appendices H.4, H.7 and H.8 gives

P(finite-stock switched mission fails)
   <= 9545923/9062500000+11/100000+10 exp(-8)+3 exp(-20)
   <= 4517975690072193/10^18.

The exact rational witness and outward Taylor bounds establish the displayed inequality. It is a complete finite-mission corollary with seed withdrawal, not merely a set of local drift rows. It explicitly includes acquisition, all-time floors, every fixed-grid quota, per-site initiating divisions, ten whole-population Ready renewals, all global resource tails and finite-stock coupling.


### H.10. The entirely absent catalyst face is invariant

**Proposition (inventory is necessary for postwithdrawal candidate function).** Fix a species j and let Z_j be the set of physical population states in which a_ij=0 at every site. Under the law with every seed intensity zero from30 onward, Z_j is invariant. At any almost-surely finite natural-history stopping time sigma>=30, on X_sigma in Z_j the population remains in Z_j at every later time with conditional probability one while that seed-free law remains in force.

**Proof.** In a complete premark state in Z_j, seed influx has zero rate. Every catalytic birth, passive/active loss, ordinary j-service and j-triggered division rate contains a_ij or a_ij/N and therefore vanishes. Recharge/discharge affect only fuel; other-species chemistry cannot create j.

A basal division or division triggered by another species can still occur, but its parent's j count is zero. The half-binomial mark is Bin(0,1/2), so both installed daughters have zero j; every untouched site also has zero j. Victim selection and either fuel allocation preserve the same conclusion. Every positive-rate mark from Z_j thus has its complete postmark state in Z_j. Bounded rates and the finite physical state space imply nonexplosion. Induction over marks proves invariance on bounded intervals, and a countable union extends it to later times. The homogeneous post30 marked restart gives the stopping-time form.

Other species and fuel may keep evolving: the invariant face is not an absorbing full state. A single empty site is also different from Z_j; a positive donor can physically transmit j into it by division. No subsequent ordinary j-service or j-triggered consuming credit can be earned after entry into Z_j. This proves the proposition.

The proposition adds no probability allowance to Theorem1. It explains a structural causal dependence: fuel and precursors alone cannot recreate an entirely absent candidate in this generator. Continued candidate function depends on previously acquired inventory, its amplification and its transmission. It does not identify necessary labelled molecules, establish information capacity or create a second functional attractor.

## References

1. Segré, D., Ben-Eli, D. and Lancet, D. (2000). Compositional genomes: Prebiotic information transfer in mutually catalytic noncovalent assemblies. Proceedings of the National Academy of Sciences 97(8), 4112-4117. https://doi.org/10.1073/pnas.97.8.4112
2. Hordijk, W. and Steel, M. (2004). Detecting autocatalytic, self-sustaining sets in chemical reaction systems. Journal of Theoretical Biology 227(4), 451-461. https://doi.org/10.1016/j.jtbi.2003.11.020
3. Vasas, V., Szathmáry, E. and Santos, M. (2010). Lack of evolvability in self-sustaining autocatalytic networks constraints metabolism-first scenarios for the origin of life. Proceedings of the National Academy of Sciences 107(4), 1470-1475. https://doi.org/10.1073/pnas.0912628107
4. Vasas, V., Fernando, C., Santos, M., Kauffman, S. and Szathmáry, E. (2012). Evolution before genes. Biology Direct 7, 1. https://doi.org/10.1186/1745-6150-7-1
5. Ameta, S., Arsène, S., Foulon, S., Saudemont, B., Clifton, B. E., Griffiths, A. D. and Nghe, P. (2021). Darwinian properties and their trade-offs in autocatalytic RNA reaction networks. Nature Communications 12, 842. https://doi.org/10.1038/s41467-021-21000-1
6. Zhu, T. F. and Szostak, J. W. (2009). Coupled Growth and Division of Model Protocell Membranes. Journal of the American Chemical Society 131(15), 5705-5713. https://doi.org/10.1021/ja900919c
7. Useful catalytic acquisition under fixed operating constraints (2026). Unpublished manuscript, 5 October 2026.
8. Reliable copying of chemical states: finite-molecule guarantees and molecular redundancy (2026). Unpublished manuscript, 13 September 2026.
