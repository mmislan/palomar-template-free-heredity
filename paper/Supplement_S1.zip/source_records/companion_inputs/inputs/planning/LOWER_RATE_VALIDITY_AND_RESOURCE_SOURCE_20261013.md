The proposed parameters satisfy the **written `Par.Valid` conditions**, and direct substitution gives **`cf3Rate p = 101515864`**, so \(3800\le\texttt{cf3Rate p}\). These are definition-level checks; recovery, service and full mission acceptance remain separate.

The pinned source copies `SiteCF3.lean`, lines13–18:

```lean
structure Par.Valid (p : Par) : Prop where
  hM : 2 ≤ p.M
  hN : 0 < p.N
  hα : 0 ≤ p.α
  hβ : 0 ≤ p.β
  hε : 0 ≤ p.ε
```

Thus \(M=4,N=2048,\alpha=800,\beta=4500000,\epsilon=6\) meet every listed condition. There is no additional large-beta condition in this definition.

`Defs.lean`, lines189–190, gives:

```lean
def cf3Rate (p : Par) : ℝ :=
  p.M *
    (p.c * (p.ε + p.α * p.N + p.α / 2 * p.N + p.N + p.β)
      + p.β + (1 + p.c))
```

For the proposed point:

\[
4[3(6+800\cdot2048+400\cdot2048+2048+4500000)+4500000+4]
=101515864.
\]

The literal source channels are:

```lean
-- seed
p.ε * (1 - s.u j)

-- recharge
p.β * (1 - s.r)

-- division
| none => 1
| some j => s.u j * s.r
```

Consequently the existing counting bounds apply to these channels:

\[
\lambda_A=\beta(M-F)\le M\beta,\qquad
\lambda_E\le Mc\epsilon,\qquad
\lambda_D\le M(1+c).
\]

At the prospective beta4.5m point, these are **18,000,000**, **72**, and **16** respectively. Their time60 count envelopes have means **1,080,000,000**, **4320**, and **960**.

The upstream conventional proof, `proof_notes/PROOF.md`, Proposition2.2, supplies the direct recharge-proposal construction:

> Realise recharges by thinning independent rate-`beta` proposal clocks at the sites (a proposal is accepted iff the site's fuel is empty). Then `Q_ch <= P`, the number of proposals in the block, which is Poisson with mean `M beta w`.

This is domination of accepted recharges by proposal counts; accepted counts themselves are state-dependent.

The existing `SERVICE_RESOURCE_PROOF.md`, §6, states:

> Accepted seed count E has intensity <=M*c*epsilon=72; division count D has intensity <=M*(1+c)=16. Uniformized labelled-tick iteration gives their Poisson-envelope moment bounds directly, even though actual counts are not independent Poisson variables.

Its displayed bounded-count tail is:

```text
P(N>=mu+d) <= exp(-d^2/[2*(mu+d/3)]).
```

Canonical paper161 §7.4 uses the following explicit seed/division statements:

> Seeds have total intensity<=72, so E exp(t E60)<=exp(4320(exp(t)−1)); t=1/10 and exp(1/10)<10/9 give P(E60>5000)<exp(−20). Actual divisions have intensity<=16. Their same marked-count exponential envelope has mean960; t=1/5 and exp(t)−1<=31/140 give P(D60>1200)<=exp(−192/7)<exp(−20).

The earlier resource proof uses a4800 seed cap; **the canonical paper’s retained budget is5000**.

The exact unchanged stock-ledger statements are `SERVICE_RESOURCE_PROOF.md`, LemmaSR1:

```text
F = F0 + A - B - H - Q - U - W_R,
S = S0 + E + B - P - H - W_S.

F0 + A = F + C + W_R,
Q <= C <= F0 + A,
A = C + W_R + F - F0 <= C + D + M,
0 <= W_R <= D,  0 <= W_S <= c*N*D,
```

where \(C=B+H+Q+U\); \(A\) counts accepted recharges, \(B\) catalytic births, \(E\) seeds, \(H\) active turnovers, \(P\) passive decays, \(Q\) ordinary plus triggered jobs, and \(U\) unproductive discharges.

The supplied proof explains:

> At a basal split the two daughter fuel bits sum to initiator fuel, and their complementary molecule counts sum species-wise to its original count on every positive-probability allocation. The only population loss is the overwritten victim. At a trigger, charge its one-token pre-consumption first, then apply the same allocation argument with initiator fuel zero; total fuel loss is 1+R_v, not one. Ledger resets do not change F,S or the cumulative physical counters.

Canonical §7.4 applies these identities at every prefix, including a terminal jump:

```text
Consumed fuel B+H+Q+U <= A+4.
Catalytic-birth plus seed entries B+E <= A+4+E.
0 <= W_R <= D.
0 <= W_S <= 6144D.
```

The original canonical numerical budgets through60 are:

| Quantity | Ceiling |
|---|---:|
| Accepted feed/recharge tokens \(A\) | 1,558,500,000 |
| Initially occupied fuel | 4 |
| Consuming fuel events | 1,558,500,004 |
| Accepted seed entries \(E\) | 5,000 |
| Catalytic-birth plus seed precursor entries | 1,558,505,004 |
| Actual divisions/daughter operations \(D\) | 1,200 |
| Discarded/restored catalyst slots | 7,372,800 |
| Discarded victim fuel | 1,200, already paid within fuel supply |

The original beta8m feed cap was proved using the existing occupancy-sensitive LemmaSR3:

```text
kappa(theta,s)=max{
  beta*(exp(theta-s)-1),
  (C_star+1+c*exp(s))*(exp(s)-1)
}, theta>=s>=0.

E_x exp(theta*A_T)
 <= exp(s*(M-F0)+M*T*kappa(theta,s)).

P_x(A_T>B)
 <= exp(s*(M-F0)+M*T*kappa(theta,s)-theta*B).
```

For the original point, canonical §7.4 substitutes \(C_\star=34457603\), \(\theta=1/10000\), \(s=800/42457607\), \(T=60\), and records:

```text
k_upper=11704058599555614193200/18025996259152434517.

4s+240k_upper−1558500000/10000
 =−377451736952843887250/18025996259152434517 <−20.
```

Therefore its original feed-cap failure is at most \(e^{-20}\). The raw recharge-proposal domination above is also an existing source input for evaluating a new feed tail directly; I did not evaluate that new tail.

Finally, the finite-stock coupling statement is LemmaSR4:

```text
P_finite(G and no exhaustion)
 >= P_original(G)-P_original(A_T>B_feed).
```

It uses the same clock, channel, split and victim marks until the first attempted stock excess. Canonical §7.4 extends the stop to all declared resources and charges the three global tails once. Stocks are not replenished at recovery or ledger resets.

Recorded source pins, reused without rehashing:

| Source | SHA-256 |
|---|---|
| FunctionalCapacity/SiteCF3.lean | `bc8a9c5678ffdd47fb6e40f9f8e2457ae8176e0940aca76010af7c0f232c258e` |
| FunctionalCapacity/Defs.lean | `4849c8f8a8012dbe63a22f9819bdd3e4b6cc478d001f55c36144d95549ee72c6` |
| Upstream proof_notes/PROOF.md | `fe2d7b6923ab9f236884c2a66adcf548427a1c5a99fa2fbc53d3baa380b5b13a` |
| SERVICE_RESOURCE_PROOF.md | `dcf8181bcfcb402a5ca401a8333d3799766e1b464de8b281fe7658493329c5ac` |
| CANONICAL_MANUSCRIPT.md | `0d131feb093fcc8c345befa69b53bc43421baa5256e40b67d5140b2d19417c56` |
| SOURCE_GATE_PROOF_EXCERPTS_20261013.txt | `6fae9db69186e9d3eeda259666428be6da65dedb8f00b0c7ca7267348616bb6b` |

No files were written or compiler/checker executed. No prospective mission or resource-tail acceptance was claimed.
