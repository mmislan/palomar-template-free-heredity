# Independent audit of a prospective lower-rate mission

## Final audit status

**ACCEPTED as a complete prospective analytical beta4.5m mission corollary.** Both uniform local certificates, literal generic mission premises and error definitions, the complete G60 event, service, recovery/restart composition, resource tails, gross ledgers and finite-stock coupling have been independently matched. The source-compatible sharper feed cap is 900,000,000. The simpler 1,100,000,000 proposal-envelope cap is also proved and retained as a fallback. No mathematical source gate remains open for this corollary. No new Lean theorem has been compiled or producer-accepted, and no accepted beta8m file has been changed.

This audit is cloud-only mathematical work. Python is used only for exact rational finite checks. No compiler, Git action, desktop access, publication, simulation, or frozen-file edit was used.

## 1. Proposed single physical parameter point and corollary

Use the same physical marked network, count cap, catalogue, and complementary split law as the accepted programme, with constant parameters

- M=4, c=3, N=2048, alpha=800, epsilon=6;
- beta=4,500,000 simultaneously in recharge, discharge, and ordinary consuming-job rates;
- original retention floor 16 and simultaneous Ready threshold 512;
- the unchanged 600 fixed service blocks of length 1/10 through time 60;
- recovery allowance h=1/2 and original division-wait cap w=2.

Initially each of the two old species has at least 512 copies at each site. Candidate counts can be arbitrary in 0..2048, including zero everywhere; fuels can be arbitrary. External service and resource ledgers are based at zero without changing the physical state.

The probability is at least

1 - [1/500 + 11/100000 + 10 exp(-8) + 3 exp(-20)]

that the source-defined complete G60 event, ten global division/recovery renewals, and the declared finite-stock nonexhaustion event all hold. The displayed failure expression is at most

2732316231242993 / 500000000000000000
= 0.005464632462485986 < 0.01.

The ten-renewal sequence finishes by

30 + 11(1/2) + 10(2) = 111/2 = 55.5.

The three million guaranteed service credits finish on the unchanged grid by 60, not by 55.5. Their count is

300 * 4 * 2 * 500 + 300 * 4 * 3 * 500 = 3,000,000.

All physical channels remain active throughout; neither recovery boundaries nor service-ledger resets change the physical law.

The resource ceilings through 60, without replenishing resources at any restart, are:

| Cumulative quantity | Ceiling |
|---|---:|
| Accepted feed/recharge entries A | 900,000,000 |
| Initially occupied fuel | at most 4 |
| Consumed fuel B+H+Q+U | 900,000,004 |
| Accepted seed entries E | 5,000 |
| Catalytic-birth plus seed entries B+E | 900,005,004 |
| Actual marked divisions D | 1,200 |
| Discarded/restored catalyst slots | 7,372,800 |
| Discarded victim fuel | at most 1,200, already in gross fuel supply |

These are cumulative accepted-event/entry ceilings, not a claim that the state-dependent counts are independent Poisson variables. Initial catalyst inventories are the same prepared-founder initial condition as in the source theorem; the birth/seed entry ceiling concerns subsequent entries.

## 2. Source gates and provenance

The audit reads these additive source retrievals supplied by the parent:

1. `ORIGINAL_G60_SOURCE_PROOF_EXCERPTS_20261013.md` and `EXACT_SERVICE_AND_BRANCHING_SOURCE_20261013.md`. These two files are identical abbreviated retrievals. They provide the literal SiteCert, siteOp, RetCert transfer, service inequalities, blockErr, and displayed mission_lower bound, but do not by themselves contain the complete mission closing proof.
2. `FULLER_ORIGINAL_G60_SOURCE_RETRIEVAL_20261013.md`. This supplies the exact original G60 event, prepared-founder initialization, original Main instantiation, its complete numerical risk budget, and its marked-path interpretation.
3. `LOWER_RATE_VALIDITY_AND_RESOURCE_SOURCE_20261013.md`. This supplies Par.Valid, cf3Rate, literal accepted-feed/seed/division channels, gross conservation, count-tail statements, and finite-stock coupling.
4. The accepted general recovery theorem in `main_recovery_020_bundle_20261013/TEMPLATE_FREE_RECOVERY_MANUSCRIPT_20261013.md`, including its retained terminal-fuel stopping and conditional physical restart clauses.
5. `GENERIC_MISSION_AND_COMPOSITION_SOURCE_20261013.md`. This supplies the complete generic postErr and mission_lower statement, the full fixed-p0 Main proof, the actual renewal definitions, and the exact restart/composition and resource-coupling arguments.
6. `EXACT_CSTAR_RESOURCE_SOURCE_20261013.md`. This supplies the actual combined consuming intensity, its sharp endpoint envelope, the separate basal/triggered victim-fuel loss bounds, and the exact parameterized SR3 feed bound.

The initial duplicate retrievals have not been overwritten or reinterpreted as longer source documents. The later fuller retrieval is a separately named source.

The two newly proved inputs are the complete `beta1m_branching` and `reciprocal_beta_recovery` packets. Their exact witness checkers were rerun in additive copies under this audit's `reproduction/` directory. The additional `independent_lower_rate_check.py` does not import either author's functions. It separately implements the literal beta4.5m branching operator, binomial transforms, recovery event residuals, interval comparisons, service arithmetic, exponential bounds, resource tails, and final risk arithmetic.

## 3. Validity and uniformization

The literal Par.Valid requires M>=2, N>0, alpha>=0, beta>=0, epsilon>=0. Every condition holds at the new parameter point; it contains no hidden high-beta condition.

Direct substitution into the source definition gives

cf3Rate = 4[3(6+800*2048+400*2048+2048+4500000)+4500000+4]
        = 101515864.

This rate is positive, exceeds theta_A=1/2, and exceeds theta_s=3800. All cancellations of cf3Rate in the displayed source block bound are therefore justified.

## 4. Full branching SiteCert audit

The new family is not the old fixed W0 falsely transplanted to another beta. Define

hh(a)=1/[(a+1)(a+2)(a+3)(a+4)(a+5)],
D=1860480,
C=D hh(12)/(3/4)^12,
A(a)=C(3/4)^a for a<=12 and D hh(a) otherwise,
g(0)=-A(0)/2,
g(a)=A(a) min(6a,70) for a>=1,
W_beta(a,true)=A(a),
W_beta(a,false)=A(a)+g(a)/beta.

### Infinite-domain obligations

A is positive and strictly decreasing: its successive ratio is 3/4 before the join and (a+1)/(a+6) from a=12 onward, including that join. The false branch at beta1m is likewise strictly decreasing, with its only nonconstant multiplier changes below a=12. Its maximum is below the true maximum C<80. At a=0 the false weight is slightly smaller than the true weight; no false universal fuel-order assumption is made there.

A(15)=1, all weights below count 16 are at least 1, and every weight at count at least 512 is at most 6/10^8. For beta>=1m each false weight is a convex combination of A and its beta1m value, proving positivity, the all-natural Wmax bound, the low-count barrier and prepared bound throughout the continuum. These statements extend beyond count N and are not inferred merely from finite drift enumeration.

### Full operator and arbitrary foreign loads

Putting v=Hf-beta Uf turns the literal admissible load set into the rectangle 0<=Uf<=2, 0<=v<=1843200. The residual siteOp+(1/2)W is affine in its two coordinates, so all interior values are convex combinations of the four corners. The checker includes every original birth/death, fuel transition, basal daughter and triggered daughter term. It does not substitute the recovery killed generator or impose an artificial zero boundary at floor 16.

The beta-integral identity

E[hh(Bin(a,1/2))]
=32 hh(a) -(32/24) sum_{j=0}^4 (-1)^j choose(4,j) 2^(-a-j-1)/(a+j+1)

follows by integrating t^k(1-t)^4/24, then changing variables s=(1+t)/2. Finite prefix corrections give the exact A and g moments. I independently checked the complete binomial sums at zero, every join/barrier boundary used, count 512, count 2048, the author maxima 868/979, and the independent beta4.5m maximum 954.

I independently expanded the residual as an affine function of x=1/beta. The beta times O(1/beta) fuel-gap products survive at x=0, so this endpoint is an algebraic residual limit, not an equal-fuel finite-rate model. The authors' all 16,392 endpoint identities and limiting rows reproduce. Their coarse limit residual <=8/10^7 and beta1m residual <=131/10^8 imply, at beta4.5m,

siteOp+(1/2)W <= 8/10^7 +(2/9)(131/10^8-8/10^7)
                  =137/150000000 <13/10^7=b0.

The independent direct beta4.5m source-operator implementation also passes all 16,392 count/fuel/corner rows. Its maximum occurs at a=954, true fuel, Uf=2, v=1843200 and is at most 0.000000887756040795.

**Accepted mathematical input:** SiteCert p_beta4m5 16 W_beta4m5 (1/2) b0 80, with the unchanged prepared bound 6/10^8. More generally the family gives corrected b'=131/10^8 for every beta>=1m and old b0 for every beta>=1.02m. The exact failure of old b0 at beta1m is preserved; no beta1m full mission is claimed.

## 5. Source-normalized service certificate

Choose theta_s=3800 and rho=22481/22500=1-3800/4500000. Then

1/2<=rho<=1, 0<rho, 0<=theta_s<=cf3Rate,
theta_s=beta(1-rho).

The literal source Hs equals

800*3*2048*(9/16)+3*4500000+8=16264808.

The second service residual is exactly

(beta+1)(16/2048)(1/2-rho)+Hs(1-rho)+theta_s rho
=-1949591/115200 <0.

Thus both beta-dependent source service conditions, not merely a heuristic effective rate, hold at the original floor 16. The source credit tilt remains 2^(-q), so the quota multiplier is 2^500/rho. For either required-set cardinality nreq=2 or3, the per-block service term satisfies

(4 nreq/rho) 2^500 exp(-380)
<= (12/rho) 2^500 exp(-380)
<=3653/10^17 <1/10^10.

The exact checker bounds exp(380) below by [sum_{j=0}^{100}19^j/j!]^20. No decimal exponential is used in the asserted comparison.

## 6. Original G60 budget and its preserved event scope

The fuller source retrieval defines G60 from the prepared old founders. It includes every pre/post floor and fixed-grid quota, candidate establishment at 30, and at least five initiating divisions per spatial site during[30,60]. It is not a generic floor-only estimate from arbitrary16-copy states.

The original displayed budget is

48/10^8 +320/2900000
+600[(6/5)b0+1/10^10] +5184/10^10
=37968367/36250000000
<1/500.

Every displayed input is retained: eight prepared coordinates give48/10^8; the arbitrary candidate has potential at most 4*80=320; theta_A30=15; both phases have 300 blocks; the full service term is at most1/10^10 per block; b0 is unchanged; the division rate/law and z=6 deficit witness are unchanged. The useful exponential comparisons exp(15)>=2900000 and exp(25)>=10^10 have no beta dependence.

The source's pre-phase coefficient is300[2(4b0/10)+4b0/10+1/10^10]; its post coefficient is5184/10^10+300[3(4b0/10)+1/10^10]. Both coincide with the joint displayed allocation. The prepared8-coordinate term and candidate decay are not charged again in recovery.

### Literal generic reconstruction, without reusing fixed-p0 auxiliaries

The final source retrieval supplies every mission_lower premise. The new SiteCert is supplied by Section 4. Its theta=1/2 is nonnegative and at most Lambda=101515864; b0>=0. Section 5 verifies rho in[1/2,1], theta_s>=0, theta_s<=Lambda, theta_s<=beta(1-rho), and the full service residual. Finally z=6>=1, Lambda>=1 and w_block=1/10>=0. Set m=500, D=5 and L_alpha=L_p=300. These are every listed premise; no fixed-p0 theorem is invoked at the new parameter.

In the literal blockErr definition, write S_n for its service term, already proved at most10^-10 for n<=3. Cancelling positive Lambda gives

blockErr(p,n,b0,cV,bV,theta_s,rho,1/10,500)
= n*(4b0/10) + cV*bV*Lambda/10 + S_n.

The prephase has n=2,cV=1,bV=4b0/Lambda, so its entire error per block is at most(6/5)b0+10^-10. The postphase has n=3,cV=6^4=1296,bV=0, giving exactly the same upper bound. This explicitly reconstructs the changed-rate analogue of the old fixed-p0 blockErr bound.

The literal postErr additionally contains

z^(D-1)*4*exp[-((1-1/z)/Lambda)(Lambda/10)*300]
=6^4*4*exp(-25)=5184 exp(-25).

The candidate exponent is exactly(1/2)/Lambda*(Lambda/10)*300=15. Prepared initialization follows directly by summing the new W's bound6/10^8 over the eight old coordinates; the candidate bound follows by summing its new Wmax 80 over four sites. Thus neither W0_ready, cert0, blockErr_p0, cf3Rate_p0 nor Hs_p0 is silently reused. The elementary exponential comparisons are reconstructed by rational lower Taylor polynomials. Substitution into generic mission_lower gives the complete displayed G60 budget.

The source marked-path interpretation identifies that same generic mission operator with the event described above. Its Poisson uniformization argument needs the new valid parameter and rate bound, not the original numerical value of Lambda. All source gates therefore match.

## 7. Uniform recovery certificate and independent audit

The accepted underlying lemma bounds surviving nonreturn, using potential low-reset words plus a correlated physical reset clock. For the new reciprocal family use

h_beta(a,0)=A_old(a),
h_beta(a,1)=A_old(a)-(5500000/beta) Delta_old(a),

where below 512 the new A_old and Delta_old are defined from the literal rational upper export, while above 512 the accepted positive tail is reconstructed exactly. Old exact entries below 512 are in[H_upper-10^-18,H_upper]. Thus a rounded export is never asserted equal to the accepted exact profile.

The off-rate reference is beta(3+a/N)+800N. The nuisance consumption T_beta(z) is increasing on[0,N] because beta>=1m>400N, so the fuel-ordered reference dominates the actual shared-fuel generator without assuming nuisance independence.

The uneliminated residuals are affine in reciprocal beta. I independently reconstructed both algebraic endpoints for all 4,066 count/fuel rows (8,132 inequalities) and the complete physical event residual at beta4.5m in all 4,066 rows. The direct rows agree exactly with the affine formulas; all bounds pass. Positivity, below-Ready barrier, maximum and all exact-profile interval comparisons also pass.

The actual division reset operator is independent of beta, since basal/triggered division rates and all marks are unchanged. Pointwise comparison with the accepted old potential is

(9997/10000) U_old <= U_beta <= (10000/9999) U_old.

Positivity of the exact same killed reset operator gives its coefficient below 478. This compares functions under an unchanged operator; it does not couple two path laws or assume recovery probabilities are monotone in beta. Together with the chemical drift and at least4 reset killing,

Q_beta U_beta <= -(154-12/4700) U_beta,
B_div U_beta <=478 U_beta,
sup U_beta <=338971453059/125000.

These inequalities retain the original simultaneous Ready512 and floor 16 boundaries, high-count returns, complementary daughters, and terminal physical fuel convention.

For the actual shared-fuel clock,

kappa_beta=3/(5beta+1200N),
a_beta=4+12beta/(5beta+1200N)<=32/5,
V_beta=20beta+5400N+64.

With T=1/2, K=14, delta=1/100, theta=1/640, the Poisson comparison mean is at most321/100 and the clock exponent is

9141301/460320 +(509/36825600)(beta-1000000).

Its slope is positive, so the beta1m clock bound is uniformly conservative. The reset count is a correlated time change of a Poisson primitive; only pathwise count monotonicity is used, never independence of the count and clock.

The exact rational low-word/Poisson/clock calculation reproduces

P_beta(H>1/2,D>1/2)
<=8622092430140/10^18
=0.000008622092430140 <1/100000

for every finite constant beta>=1m and every admissible restart state. Words0..13 and at least14 resets exhaust all possibilities. The once-rounded total differs by one unit at10^-18 from the sum of separately rounded components, as correctly documented by the author.

**Accepted:** the new uniform recovery-only theorem and its conditional physical stopping-time restart form. This acceptance does not by itself imply G60 or unconditional P(H>1/2) control.

## 8. Stopping/restart composition without conditioning on future G60

Begin recovery at deterministic time30. For each successful recovery, take the next actual marked division time, then freshly define the next Ready/floor stopping problem on the underlying physical chain. A state already Ready recovers immediately. A state belowfloor is excluded by G60 and is not fed to the recovery lemma.

All recovery starts and first-division times are stopping times for the full marked history. The event that earlier selected waits/recoveries succeeded and that the current start lies before its deterministic deadline is measurable at the current start. Multiply the pointwise conditional surviving-nonreturn bound by that event and then average. Do not condition the physical law on the future event G60.

There are 11 recovery intervals and 10 waits. The baseline aggregate division intensity is at least4, including state-null marked divisions, so each no-division wait of length 2 has conditional probability at mostexp(-8). The tower property and a union bound give11/100000+10exp(-8).

On G60, floor 16 is protected throughout[30,60]. Therefore failure of a required recovery byh=1/2, while that complete interval lies before 60, implies the surviving-nonreturn event paid by its conditional estimate. This is an event inclusion, not a replacement of P(H>h,D>h) by P(H>h). If a floor failure happens, it is charged once to G60^c.

Successful-prefix deadline induction puts the last recovery endpoint at most55.5, strictly before 60. Thus every selected recovery interval is in the time range where G60 supplies its floor protection. The process is not a globally absorbed chain incorrectly restarted after its old boundary. Every local run is freshly stopped on the underlying physical marked process, retaining its own terminal fuel statistic.

The service grid is untouched. Recovery may start off-grid; its validity is time homogeneous and uniform in current physical state and marked history. No named-sister lineage or independent sister splitting is inferred.

## 9. Feed, seed and division tails; finite stocks

### Simpler proposal-clock cap, retained as an independent fallback

Accepted recharge intensity is beta(4-F)<=18000000. Equivalently, use the source's independent rate-beta proposal clock at each site and accept a proposal only when fuel is empty. Total accepted feed A_60 is bounded by the total proposal count with mean1080000000. This independence is for the constructed proposal clocks, not for accepted physical events.

For t=1/100, the positive Taylor series gives exp(t)-1< t/(1-t)=1/99. Exponential Markov therefore gives

P(A_60>1100000000)
<=exp[1080000000/99-1100000000/100]
=exp(-1000000/11)<exp(-20).

### Stronger 900 million cap from the existing occupancy-sensitive source bound

The literal source combined consuming intensity at a fueled site is

h_i=beta+sum_j[alpha*N*(3u_ij/2-u_ij^2)+(beta+1)u_ij].

The extra+1 includes the division-coupled job. Its concave quadratic reaches its maximum at u=1 when beta+1>=alpha*N/2=819200. This holds at beta4.5m, so the actual source envelope is

C_star=beta+3(819200+beta+1)=20457603.

Basal victim-fuel loss and triggered victim-fuel loss are separate, with bounds F and cF. Their inclusion gives the source LemmaSR3

kappa(theta,s)=max{beta(exp(theta-s)-1),
                  (C_star+1+3exp(s))(exp(s)-1)},
P(A_T>B)<=exp[s(4-F0)+4T*kappa(theta,s)-theta B],
theta>=s>=0.

Choose theta=1/10000, s=450/24957607, T=60 and B=900000000. These obey 0<s<theta<1. For 0<=x<1 the Taylor series gives exp(x)<=1/(1-x) and exp(x)-1<=x/(1-x). Every multiplied factor is nonnegative. Consequently the two kappa entries are bounded by

k1=beta*(theta-s)/(1-theta+s)=10228803500000/27728401377,
k2=(C_star+1+3/(1-s))*s/(1-s)=229753669385092050/622859685522649.

Exact cross multiplication gives k1>=k2. Paying arbitrary initial fuel by s(4-F0)<=4s yields

4s+240*k1-900000000/10000
=-338119685867744343800/230678181435141613
<-20.

Thus P(A_60>900000000)<exp(-20). This uses the source's actual combined consuming envelope and literal treatment of both kinds of victim-fuel losses; it does not sum incompatible reaction maxima or omit the triggered job. It is a single exact analytic witness, not a search or an optimized-cap claim. This sharper cap is used in the final corollary's resource table.

### Unchanged seed/division tails and pathwise ledger transfer

Seeds have intensity at most 72 and mean envelope 4320. At t=1/10, exp(t)<10/9 gives

P(E_60>5000)<exp[4320/9-500]=exp(-20).

Divisions have intensity at most 16 and mean envelope 960. The source bound exp(1/5)-1<=31/140, independently checked by a rational exponential upper series, gives

P(D_60>1200)<=exp[960(31/140)-240]
=exp(-192/7)<exp(-20).

All three are valid for dependent, state-modulated accepted counts. They can be proved from the marked-count exponential envelope or from constant-rate dominating proposals. Their sum is charged once as 3 exp(-20).

The source gross identities hold at every prefix, including terminal jumps:

C=B+H+Q+U<=A+F0<=A+4,
B+E<=A+4+E,
W_R<=D,
W_S<=cND=6144D.

A basal split loses the overwritten victim's fuel only; a triggered split pays its one-token consumption before applying the complementary allocation. Thus the fuel loss of a triggered split is1+R_v, not1. This is already reflected in the ledger and is not added a second time to the supply cap. At the resource-good event the displayed ceilings in Section1 follow exactly, including the +4 convention and 7,372,800 copy/restoration slots.

The source finite-stock coupling uses the same clocks/channels/victim/split marks up to the first attempted resource excess. On the original-law resource-good event, none of the declared finite supplies is exhausted by 60. The coupling subtracts the three global resource tails from the physical success event once; no restart replenishes any stock.

## 10. Verification and trust boundary

`independent_lower_rate_results.json` and its stdout give exact new numerical checks. Author-checker copies and their outputs are under `reproduction/`; all original packets were left untouched. The analytical proofs above are necessary companions to finite arithmetic: an endpoint table alone does not establish an all-beta family, a SiteCert's all-natural bound, a correlated-clock theorem, or a stopping-time composition.

This is a complete prospective analytical certificate for a new constant-beta physical system. It is not a compiler receipt and does not alter the immutable canonical beta8m paper161. A separately reviewed revision would be needed to incorporate it there. All requested mathematical/source gates for this corollary have been discharged; formal compilation and any producer/canonical acceptance remain separate statuses.
