# A uniform recovery-only theorem for beta at least one million

## Result and status

The prescribed reciprocal-fuel-gap family passes every exact check. For every finite real beta >= 1,000,000, simultaneously and with one fixed set of recovery constants,

P_beta(H > 1/2, D > 1/2) <= 8622092430140 / 10^18
= 0.000008622092430140 < 1/100000.

Here H is the original first simultaneous Ready event, all 12 counts at least 512, and D is the original first count below 16. The statement is uniform over all initial counts 16 through 2048 and arbitrary shared fuel bits. The same bound holds conditionally at physical stopping-time restarts in this admissible state set, by the already accepted recovery/resource-clock theorem.

This is a proposed exact certificate awaiting independent audit. It proves surviving nonreturn only. It does not pay the floor-failure probability, establish G60, acquisition, service, stock/feed budgets, or a full changed-beta mission. The original beta8m full mission and the separately accepted beta1m recovery-only certificate are unchanged. The accepted beta1m point has its own slightly smaller bound; this uniform corollary does not replace it.

The entire family is certified by affine interpolation between two algebraic endpoints. There was no rate sweep, compiler, band solve, CTMC simulation, full-state enumeration, Git action, publication, or user-desktop access.

## 1. The fixed family and its exact input

Put N=2048, beta0=8,000,000, B=1,000,000, c=5,500,000, rho=150, epsilon=1/4700. For count a, set

h_beta(a,0)=A(a),
h_beta(a,1)=A(a)-(c/beta) Delta(a).

At beta=B, c/beta=11/2, exactly the accepted beta1m construction. Below count 16 both A and Delta are zero. For 16<=a<512, A and A-Delta are the literal rational entries of the accepted upper-rounded profile export. These are the actual definition of the new function, not an assertion that the rounded values equal the old exact profile. The old exact entries lie in [H_upper-10^-18,H_upper].

At a>=512, reconstruct the accepted tail exactly. Set

f(a)=(980-a)(981-a)(982-a)/[(a-10)(a-9)(a-8)] for a<=768,
f(a)=f(768)(10/11)^(a-768) for a>768.

For a<768 let

k(a)=6(1-a/N)[f(a+1)/f(a)-1]+a[f(a-1)/f(a)-1],

and for a>=768 let k(a)=5647a/56320-6/11. Then

A(a)=f(a)/f(512),
Delta(a)=A(a)[258+k(a)]/beta0.

This matches the accepted beta1m script, including the exact tail correction, the switch at 768, and the 511/512 join. The extra count N+1 is an auxiliary value only; both upward rates at N vanish. No positive-rate transition leaves the physical count range.

The bundled profile is byte-identical to the accepted export, SHA-256:

1cbf7592037531b0c61ca9c5c01f40e418bf5932b291c25273490e535fb12542.

The checker verifies the digest before reading the profile as rational numbers.

## 2. Exact affine residual identity

Let P be the seed/passive count generator,

P g(a)=s(a)[g(a+1)-g(a)]+m(a)[g(a-1)-g(a)],
s(a)=6(1-a/N), m(a)=a,
b(a)=800a(1-a/N), d(a)=400a.

Define the active count operator

J g(a)=b(a)[g(a+1)-g(a)]+d(a)[g(a-1)-g(a)].

The reference fuel-off rate in a fueled selected coordinate is

off_beta(a)=beta(3+a/N)+800N.

This reference is valid throughout the proposed domain: the consuming intensity at nuisance count z is

T_beta(z)=800z(1-z/N)+400z+beta z/N,

and its derivative is at least beta/N-400>0 because beta>=B>400N=819200. Thus each of the two nuisance counts can be bounded by N. Fuel order gives the correct upper-generator direction without independence of nuisance histories.

Write x=1/beta. For the residual R_r(x)=(G_beta+rho)h_beta(a,r), direct expansion of the original uneliminated generator yields

R_0(x)=P A(a)+rho A(a)-c Delta(a),

R_1(x)=P A(a)+J A(a)+rho A(a)+c(3+a/N)Delta(a)
       +c x {-P Delta(a)+[b(a)+d(a)+800N-rho]Delta(a)}.

Hence R_0 is constant, and R_1 is affine in x on [0,1/B]. In particular,

R_r(x)=(1-Bx)R_r(0)+(Bx)R_r(1/B).

The cancellation beta*[h_beta(a,1)-h_beta(a,0)]=-c Delta(a) in row 0 and the product beta*(3+a/N)*[h_beta(a,0)-h_beta(a,1)]=c(3+a/N)Delta(a) in row 1 are essential. Their limits are finite and usually nonzero. R_r(0) is an algebraic residual endpoint, not the generator obtained by merely setting the two fuel weights equal at a finite beta. The checker retains these products explicitly.

For each count and fuel, the checker reconstructs the affine coefficient pair directly from physical event channels and compares both coefficients to these formulas. It also evaluates x=1/B and checks equality with a separately assembled finite-beta event-list residual. It then checks both endpoints against the same source bound:

R_r(x)<=0 for 16<=a<=511,
R_r(x)<=epsilon for 512<=a<=2048.

All 4066 affine coefficient identities, 4066 finite-beta physical event-list rows, and 8132 endpoint count/fuel inequalities pass. The latter count includes the duplicate constant row-0 endpoint checks. Convex interpolation proves every residual inequality for every beta>=B, including irrational beta. No other beta sample is needed or used.

As a diagnostic only, the smallest source-adjusted decay ratio at beta=B is greater than 152.5806279338545 in fuel 0 (a=807), and greater than 166.1142950973367 in fuel 1 (a=879). At algebraic x=0, row 0 is unchanged; the analogous row-1 endpoint quantity exceeds 538.4849115056568 (a=16).

## 3. Positivity, barrier, maximum, and uniform reset transfer

The checked Delta values are nonnegative, so for beta>=B,

A(a)-(11/2)Delta(a) <= h_beta(a,1) <= A(a)=h_beta(a,0).

The beta=B endpoint is strictly positive on 16..2048 and is at least 1 below 512. The minimum below-512 barrier is exactly 1.011896968305820926. Therefore all profiles in the family are positive, fuel ordered, and satisfy the same below-Ready barrier. Their maximum is always the unchanged fuel-0 maximum; exactly,

12 max_a A(a) <= M=338971453059/125000.

For each count/fuel pair below 512, the checker verifies the stronger interval endpoint inequalities

(9997/10000) H_upper(a,r) <= h_B(a,r),
A(a) <= (10000/9999)[H_upper(a,r)-10^-18].

For the exact tail it verifies the analogous inequalities without the rounding subtraction. These imply, simultaneously for all beta>=B,

(9997/10000) h_old(a,r) <= h_beta(a,r) <= (10000/9999) h_old(a,r).

The upper tail comparison also follows immediately from the accepted relative gap Delta/A<1/10000: h_old(a,1)=A(a)(1-Delta/A)>9999A(a)/10000. The checker reconstructs and verifies this gap bound exactly, rather than relying on the rounded tail export, which would erase tiny absolute fuel differences.

Let U_beta be the sum of the 12 coordinate potentials. The same componentwise comparison gives

l U_old <= U_beta <= u U_old,
l=9997/10000, u=10000/9999.

The positive division reset operator B_div is literally unchanged across this parameter family. It includes the same physical rates, retained sites, uniform victim, parental prestate fuel, complementary binomial sisters, and original global Ready/floor killing. Thus the independently accepted old intrinsic-2048 witness, C_old=95467565097/200000000, gives

B_div U_beta <= u B_div U_old <= u C_old U_old
             <= (u C_old/l) U_beta < 478 U_beta.

The transferred scalar coefficient is at most 477.528822688210603596, strictly below 478. The checker verifies the exact cross-multiplied inequality. This is a pointwise positive-operator transfer. It neither couples the path laws at different beta nor claims monotonicity of the true recovery probability.

Summing the chemical inequalities and retaining original floor/Ready killing gives a chemical drift bound -150 U_beta+12/4700. On the live nonReady domain U_beta>=1. No-division killing has rate nu>=4, so

Q_beta U_beta <= -gamma U_beta,
gamma=154-12/4700=180947/1175.

Floor transitions at a=16, all returns through the positive tail, and simultaneous Ready killing stay literal. Individual coordinate crossings of 512 do not reset the recovery history.

## 4. Actual resource clock and its uniform exponential bound

Let F=sum_i R_i, z_i=sum_j a_ij/N, Z=sum_i R_i z_i. Then 0<=F<=4, 0<=Z<=3F, and the actual marked-division intensity is nu=4+Z. The literal fuel drift is

L_beta F=beta(4-2F-Z)-A_active-D_fuel,
A_active>=400N Z, D_fuel>=0.

Put kappa_beta=3/(5beta+1200N) and c_beta=beta*kappa_beta. Since F>=Z/3,

-kappa_beta L_beta F
 >= c_beta[2F+(1+400N/beta)Z-4]
 >= Z-4c_beta
 = nu-a_beta,

a_beta=4+4c_beta=4+12beta/(5beta+1200N)<=32/5.

The physical stopping convention keeps terminal F; the initial fuel payment remains 4. Each actual fuel jump has absolute size at most 2. A conservative channelwise predictable-variation density is

V_beta=20beta+5400N+64.

The 20beta term pays four recharge, four discharge, and twelve ordinary consuming-job channels. For each active count, b(a)+d(a)<=450N, so twelve coordinates cost at most 5400N. Division rate is at most 16 and squared fuel-jump size at most 4, costing 64. Seed/passive count events do not change fuel. Ordinary jobs remain physically active across all boundaries.

Fix, once and for all,

T=1/2, K=14, delta=1/100, theta=1/640.

The conditions delta>4 kappa_beta and 0<theta<3/2 hold uniformly, because kappa_beta is largest at beta=B. The bounded-resource exponential inequality has exponent

E(beta)=theta(delta/kappa_beta-4)
        -V_beta T theta^2/[2(1-2theta/3)].

Both 1/kappa_beta and V_beta are affine in beta. Exact simplification gives

E(beta)=9141301/460320 + (509/36825600)(beta-1000000).

Its slope is strictly positive; therefore E(beta)>=E(B)>0. This is an exact analytic monotonicity statement, not a sampled trend.

The deterministic Poisson comparison mean satisfies

mu_beta=a_beta T+delta <= (32/5)(1/2)+1/100=321/100=3.21.

The Poisson upper tail increases with its mean. Combining its limiting worst mean with the clock exponent's beta=B worst case is conservative and valid, even though these two worst values occur at different ends of the parameter domain. The inherited correlated-clock proof uses pathwise time-change domination and does not assert independence between the division count, physical clock, or Poisson primitive.

## 5. One fixed outward numerical certificate

The accepted low-word/clock decomposition, with the local inputs proved above, gives

q_beta(T) <= M exp(-gamma T) sum_{n=0}^{13}(478T)^n/n!
             + P(Poisson(321/100)>=14)
             + exp(-9141301/460320).

Words 0 through 13 are paid by the potential. At least 14 actual marked divisions are paid by the clock/Poisson argument. These cover the surviving event without resetting at individual count crossings.

The exact rational checker uses the positive Taylor lower polynomial

L_200(x)=sum_{n=0}^{200} x^n/n! <= exp(x),

and, for 0<=x<202, the geometric-remainder upper bound

exp(x) <= U_200(x)=L_200(x)+(x^201/201!)/(1-x/202).

It upper-bounds the low-word and clock terms by division by L_200. It upper-bounds the Poisson tail by 1-[sum_{n=0}^{13}mu^n/n!]/U_200(mu), with the required direction. All assertions use fractions and integers only.

Separate component ceilings at denominator 10^18 are:

- Low words: 0.000001387409862688
- Poisson tail: 0.000007232308304574
- Clock exception: 0.000000002374262879

The raw rational bounds are added before the final ceiling:

q_beta(1/2) <= 8622092430140/10^18
            = 0.000008622092430140 < 0.00001.

The separate component ceilings sum to 8622092430141/10^18, one unit larger. Both are valid bounds; the displayed theorem uses the once-rounded combined value. No incorrect inequality between separately and jointly rounded expressions is used.

## 6. Scope, provenance, and reproduction

Run `python uniform_reciprocal_beta_recovery_certificate.py` in this directory. It needs only Python's standard library and the bundled pinned profile. It writes `uniform_reciprocal_beta_recovery_results.json`; `check_output.txt` records the successful run. `SHA256SUMS.txt` pins the additive packet.

Read-only source dependencies:

- `../fuel_gap_beta1m/BETA1M_RECOVERY_AND_SHARPENING_20261013.md`
- `../fuel_gap_beta1m/fixed_beta1m_recovery_certificate.py`
- `../fuel_gap_beta1m/ACCEPTANCE_STATUS_20261013.md`
- `ARCHIVE_PATH_002`

The accepted old reset input has the previously audited stagewise reset-constants digest `bd7a5b38df771cce413bec381176f0c068a2946b44b3176a16f76aa4f003b829`; this packet uses its intrinsic-2048 coefficient exactly. The new calculation depends on the accepted old profile enclosures, tail and reset operator witness, plus the accepted general recovery/resource-clock argument. It independently verifies every new local row, interpolation identity, comparison, uniform clock constant, and numerical inequality.

The family changes recharge, discharge, and ordinary consuming-job coefficients together, retaining all other physical rates and the full reset law. It does not establish any full mission at beta=4.5m or another new physical parameter. Any branching-floor, source G60, fixed-grid service, or feed-stock integration belongs to a separate certificate. No frozen source file was modified.
