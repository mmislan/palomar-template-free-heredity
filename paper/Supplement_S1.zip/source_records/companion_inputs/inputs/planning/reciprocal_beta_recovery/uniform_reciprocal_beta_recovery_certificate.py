#!/usr/bin/env python3
"""Exact uniform recovery certificate for ONE prescribed reciprocal-gap family.

Only Python standard-library rational arithmetic enters assertions. This checks
beta >= 1,000,000 by affine endpoint inequalities, not by a parameter sweep.
The algebraic reciprocal-beta-zero endpoint is NOT a finite-rate generator.
No frozen accepted input is written; only this packet's result is generated.
"""
from fractions import Fraction as Q
from pathlib import Path
from math import factorial
import hashlib
import json

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'base_beta8m_profile_upper.json'
PROFILE_HASH = '1cbf7592037531b0c61ca9c5c01f40e418bf5932b291c25273490e535fb12542'
assert hashlib.sha256(SRC.read_bytes()).hexdigest() == PROFILE_HASH
N = 2048
B0, BMIN, GAP_PRODUCT = Q(8000000), Q(1000000), Q(5500000)
TMAX = GAP_PRODUCT / BMIN
RHO, EPS = Q(150), Q(1, 4700)
GRID = 10**18
COMP_LO, COMP_HI = Q(9997, 10000), Q(10000, 9999)
C_OLD, C_NEW = Q(95467565097, 200000000), Q(478)
UMAX = Q(338971453059, 125000)
assert TMAX == Q(11, 2)

HU = [[Q(v) for v in row] for row in json.loads(SRC.read_text())]
H = [list(row) for row in HU]
assert all(row == [0, 0] for row in H[:16])

def tail(a):
    if a <= 768:
        return Q((980-a)*(981-a)*(982-a), (a-10)*(a-9)*(a-8))
    return tail(768) * Q(10, 11)**(a-768)

f = {a: tail(a) for a in range(510, N+2)}
tail_gap_max = (Q(0), None)
for a in range(512, N+2):
    k = (6*(1-Q(a, N))*(f[a+1]/f[a]-1)
         + a*(f[a-1]/f[a]-1) if a < 768
         else Q(5647*a, 56320)-Q(6, 11))
    relative_gap = (258+k)/B0
    assert 0 <= relative_gap < Q(1, 10000)
    if relative_gap > tail_gap_max[0]:
        tail_gap_max = (relative_gap, a)
    H[a] = [f[a]/f[512], f[a]*(1-relative_gap)/f[512]]

A = [row[0] for row in H]
D = [x-y for x, y in H]
assert all(d >= 0 for d in D)
HMIN = [[a, a-TMAX*d] for a, d in zip(A, D)]
HINF = [[a, a] for a in A]

# For every beta>=BMIN, h_beta lies between HMIN and HINF componentwise.
# Both endpoints use the literal rounded input below512 and exact tail above.
assert all(x >= y > 0 for x, y in HMIN[16:N+1])
assert all(v >= 1 for row in HMIN[16:512] for v in row)
assert 12*max(A[16:N+1]) <= UMAX
for a in range(16, N+1):
    for fuel in (0, 1):
        old_lo = H[a][fuel] - (Q(1, GRID) if a < 512 else 0)
        old_hi = H[a][fuel]
        assert COMP_LO*old_hi <= HMIN[a][fuel], (a, fuel, 'comparison lower')
        assert HINF[a][fuel] <= COMP_HI*old_lo, (a, fuel, 'comparison upper')
assert COMP_HI*C_OLD < COMP_LO*C_NEW
assert BMIN > 400*N

# Affine functions in x=1/beta are stored as (constant, coefficient of x).
def add(u, v):
    return u[0]+v[0], u[1]+v[1]

def scale(r, u):
    return r*u[0], r*u[1]

def diff(u, v):
    return u[0]-v[0], u[1]-v[1]

def evaluate(u, x):
    return u[0]+x*u[1]

def hpair(a, fuel):
    return A[a], -fuel*GAP_PRODUCT*D[a]

# Direct physical event-list residual at a finite beta (used only at BMIN).
def direct_residual(a, fuel):
    v = HMIN[a][fuel]
    events = [(6*(1-Q(a, N)), (a+1, fuel)), (Q(a), (a-1, fuel))]
    if fuel == 0:
        events.append((BMIN, (a, 1)))
    else:
        events += [(800*a*(1-Q(a, N)), (a+1, 0)),
                   (Q(400*a), (a-1, 0)),
                   (BMIN+BMIN*Q(a, N)+2*(400*N+BMIN), (a, 0))]
    return sum(rate*(HMIN[j][r]-v) for rate, (j, r) in events) + RHO*v

minimum_rates = [[None, None], [None, None]]
endpoint_rows = coefficient_identities = 0
for a in range(16, N+1):
    s, m = 6*(1-Q(a, N)), Q(a)
    b, d = 800*a*(1-Q(a, N)), Q(400*a)
    PA = s*(A[a+1]-A[a]) + m*(A[a-1]-A[a])
    PD = s*(D[a+1]-D[a]) + m*(D[a-1]-D[a])
    AA = b*(A[a+1]-A[a]) + d*(A[a-1]-A[a])
    R0 = (PA + RHO*A[a] - GAP_PRODUCT*D[a], Q(0))
    R1 = (PA + AA + RHO*A[a] + GAP_PRODUCT*(3+Q(a, N))*D[a],
          GAP_PRODUCT*(-PD+(b+d+800*N-RHO)*D[a]))
    source = 0 if a < 512 else EPS
    for fuel, residual in enumerate((R0, R1)):
        # Reconstruct the affine residual from individual physical channels.
        # A beta-proportional fuel transition multiplies an O(x) difference;
        # its product is constant, including at algebraic x=0.
        v = hpair(a, fuel)
        event_pair = add(scale(s, diff(hpair(a+1, fuel), v)),
                         scale(m, diff(hpair(a-1, fuel), v)))
        if fuel == 0:
            event_pair = add(event_pair, (-GAP_PRODUCT*D[a], Q(0)))
        else:
            event_pair = add(event_pair, scale(b, diff(hpair(a+1, 0), v)))
            event_pair = add(event_pair, scale(d, diff(hpair(a-1, 0), v)))
            event_pair = add(event_pair, scale(800*N, diff(hpair(a, 0), v)))
            event_pair = add(event_pair,
                             (GAP_PRODUCT*(3+Q(a, N))*D[a], Q(0)))
        event_pair = add(event_pair, scale(RHO, v))
        assert event_pair == residual, (a, fuel, 'affine identity')
        assert evaluate(residual, 1/BMIN) == direct_residual(a, fuel)
        coefficient_identities += 1
        for endpoint, x in enumerate((1/BMIN, Q(0))):
            r = evaluate(residual, x)
            assert r <= source, (a, fuel, endpoint, 'residual')
            height = evaluate(v, x)
            rate = RHO+(source-r)/height
            previous = minimum_rates[endpoint][fuel]
            if previous is None or rate < previous[0]:
                minimum_rates[endpoint][fuel] = (rate, a)
            endpoint_rows += 1

GAMMA = RHO+4-12*EPS
T, K, SLACK, THETA = Q(1, 2), 14, Q(1, 100), Q(1, 640)
KAPPA_MINB = 3/(5*BMIN+1200*N)
CLOCK_MINB = 4+12*BMIN/(5*BMIN+1200*N)
V_MINB = 20*BMIN+5400*N+64
assert SLACK > 4*KAPPA_MINB and 0 < THETA < Q(3, 2)
MU = Q(32, 5)*T+SLACK
assert MU == Q(321, 100)
EXP_MIN = (THETA*(SLACK/KAPPA_MINB-4)
           - V_MINB*T*THETA**2/(2*(1-2*THETA/3)))
EXP_SLOPE = THETA*SLACK*Q(5, 3)-20*T*THETA**2/(2*(1-2*THETA/3))
EXP_INTERCEPT = (THETA*(SLACK*Q(1200*N, 3)-4)
                 -(5400*N+64)*T*THETA**2/(2*(1-2*THETA/3)))
assert EXP_MIN == EXP_INTERCEPT+BMIN*EXP_SLOPE == Q(9141301, 460320)
assert EXP_SLOPE == Q(509, 36825600) > 0
assert EXP_MIN > 0
assert GAMMA == Q(180947, 1175)

# These are outward rational exponential bounds, valid at all used arguments.
def exp_lower(x):
    assert x >= 0
    term = value = Q(1)
    for n in range(1, 201):
        term *= x/n
        value += term
    return value

def exp_upper(x):
    assert 0 <= x < 202
    term = value = Q(1)
    for n in range(1, 201):
        term *= x/n
        value += term
    return value+term*x/201/(1-x/202)

def up(x, den=GRID):
    return Q((x.numerator*den+x.denominator-1)//x.denominator, den)

def down(x, den=GRID):
    return Q((x.numerator*den)//x.denominator, den)

word = UMAX*sum((C_NEW*T)**n/factorial(n) for n in range(K))/exp_lower(GAMMA*T)
poisson = 1-sum(MU**n/factorial(n) for n in range(K))/exp_upper(MU)
clock = 1/exp_lower(EXP_MIN)
total = word+poisson+clock
assert total <= up(total) == Q(8622092430140, GRID) < Q(1, 100000)
result = {
    'status': 'PASS: proposed uniform recovery-only theorem; independent audit pending',
    'scope': 'Original H512/D16 surviving nonreturn; all beta>=1000000, initial counts16..2048 and arbitrary fuel; conditional physical stopping-time restart. No G60/service/stock/mission result.',
    'source_profile_sha256': PROFILE_HASH,
    'beta_domain': '[1000000,infinity)',
    'fuel_gap_multiplier': '5500000/beta',
    'rho': str(RHO), 'gamma': str(GAMMA),
    'comparison_lower': str(COMP_LO), 'comparison_upper': str(COMP_HI),
    'reset_transferred_coefficient_upper': str(up(COMP_HI*C_OLD/COMP_LO)),
    'reset_coefficient': str(C_NEW), 'initial_potential_upper': str(UMAX),
    'horizon': str(T), 'cutoff': K, 'slack': str(SLACK), 'theta': str(THETA),
    'poisson_mean_upper': str(MU),
    'bernstein_exponent_beta_min': str(EXP_MIN),
    'bernstein_exponent_beta_slope': str(EXP_SLOPE),
    'clock_a_formula': '4+12*beta/(5*beta+1200*N)',
    'clock_kappa_formula': '3/(5*beta+1200*N)',
    'fuel_qv_rate_formula': '20*beta+5400*N+64',
    'word_upper': str(up(word)), 'poisson_tail_upper': str(up(poisson)),
    'clock_exception_upper': str(up(clock)), 'combined_upper': str(up(total)),
    'sum_of_separate_component_ceilings': str(up(word)+up(poisson)+up(clock)),
    'recovery_target': '1/100000',
    'checked_affine_coefficient_identities': coefficient_identities,
    'checked_endpoint_residual_rows': endpoint_rows,
    'checked_beta_min_physical_event_rows': coefficient_identities,
    'minimum_chemical_rate_lower_diagnostics': {
        'beta_min': [[str(down(rate)), a] for rate, a in minimum_rates[0]],
        'algebraic_reciprocal_beta_zero': [[str(down(rate)), a] for rate, a in minimum_rates[1]],
    },
    'below_ready_barrier_lower': str(down(min(v for row in HMIN[16:512] for v in row))),
    'tail_relative_gap_max_through_auxiliary_Nplus1': [str(tail_gap_max[0]), tail_gap_max[1]],
}
(ROOT/'uniform_reciprocal_beta_recovery_results.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
