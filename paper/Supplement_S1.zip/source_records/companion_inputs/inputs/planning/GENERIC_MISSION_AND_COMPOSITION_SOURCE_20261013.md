Retrieved below: the complete generic statement, the full fixed-beta8m instantiation proof, and the explicit parameterized conventional composition statement. **`mission_lower` exposes its beta-dependent premises; `main_mission` remains a fixed-`p0` proof and uses fixed-`p0` auxiliary bounds.** Nothing was executed or changed.

`MissionBound.lean`, lines118–120, complete `postErr` definition:

```lean
def postErr (p : Par) (b θs ρ z w : ℝ) (m D Lp : ℕ) : ℝ :=
  z ^ (D - 1) * (Real.exp (-((1 - 1 / z) / cf3Rate p * (cf3Rate p * w) * Lp)) * p.M)
    + Lp * blockErr p p.c b (z ^ (D - 1)) 0 θs ρ w m
```

`MissionBound.lean`, lines185–195, complete `mission_lower` statement:

```lean
theorem mission_lower (hp : p.Valid) (hc : SiteCert p K W θ b Wmax) (hθ0 : 0 ≤ θ)
    (hθΛ : θ ≤ cf3Rate p) (hb : 0 ≤ b)
    {ρ θs z w : ℝ} (hρh : 1 / 2 ≤ ρ) (hρ1 : ρ ≤ 1) (hθs0 : 0 ≤ θs) (hθs : θs ≤ cf3Rate p)
    (hθβ : θs ≤ p.β * (1 - ρ))
    (hsrv : (p.β + 1) * ((K : ℝ) / p.N) * (1 / 2 - ρ) + Hs p * (1 - ρ) + θs * ρ ≤ 0)
    (hz : 1 ≤ z) (hΛ : 1 ≤ cf3Rate p) (hw : 0 ≤ w) (m D Lα Lp : ℕ) (jc : Fin p.c) (x : Pop p) :
    1 - PhiReq W (univ.erase jc) x
        - 1 * (Real.exp (-(θ / cf3Rate p * (cf3Rate p * w) * Lα)) * PhiS W jc x)
        - postErr p b θs ρ z w m D Lp
        - Lα * blockErr p (p.c - 1) b 1 (p.M * b / cf3Rate p) θs ρ w m
      ≤ mission hp K m D Lα Lp w jc x := by
```

Its surrounding variables are:

```lean
variable {K : ℕ} {W : ℕ → Bool → ℝ} {θ b Wmax : ℝ}
```

The complete `Main.main_mission` proof, lines117–199, copied from the writer’s pinned excerpts:

```lean
theorem main_mission (jc : Fin p0.c) (x : Pop p0)
    (hx : ∀ i j, j ≠ jc → 512 ≤ ((x i).a j : ℕ)) :
    998 / 1000 ≤ mission p0_valid 16 500 5 300 300 (1 / 10) jc x := by
  have hb0 : (0 : ℝ) ≤ b0 := by unfold b0; norm_num
  have hΛ : cf3Rate p0 = 157515864 := cf3Rate_p0
  have h := mission_lower p0_valid cert0 (by norm_num) (by rw [hΛ]; norm_num) hb0
    (ρ := 99911 / 100000) (θs := 7120) (z := 6) (w := 1 / 10)
    (by norm_num) (by norm_num) (by norm_num) (by rw [hΛ]; norm_num)
    (by norm_num [p0]) (by rw [Hs_p0]; norm_num [p0]) (by norm_num) (by rw [hΛ]; norm_num)
    (by norm_num) 500 5 300 300 jc x
  refine le_trans ?_ h
  -- term 1: old species start in the ready region
  have hcard : (univ.erase jc : Finset (Fin p0.c)).card = 2 := by
    rw [Finset.card_erase_of_mem (Finset.mem_univ _), Finset.card_univ, Fintype.card_fin]
    rfl
  have hT1 : PhiReq W0 (univ.erase jc) x ≤ 2 * (4 * (6 / 10 ^ 8)) := by
    unfold PhiReq
    have hj : ∀ j ∈ (univ.erase jc : Finset (Fin p0.c)), PhiS W0 j x ≤ 4 * (6 / 10 ^ 8) := by
      intro j hj
      unfold PhiS
      have hne : j ≠ jc := (Finset.mem_erase.1 hj).1
      calc ∑ i, W0 ((x i).a j) (x i).R ≤ ∑ _i : Fin p0.M, (6 / 10 ^ 8 : ℝ) :=
            Finset.sum_le_sum fun i _ => W0_ready _ _ (hx i j hne)
        _ = 4 * (6 / 10 ^ 8) := by
            rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin]
            norm_num [p0]
    calc ∑ j ∈ univ.erase jc, PhiS W0 j x ≤ ∑ _j ∈ (univ.erase jc : Finset (Fin p0.c)),
          (4 * (6 / 10 ^ 8) : ℝ) := Finset.sum_le_sum hj
      _ = 2 * (4 * (6 / 10 ^ 8)) := by rw [Finset.sum_const, hcard]; norm_num
  -- term 2: the candidate clock
  have hT2a : PhiS W0 jc x ≤ 320 := by
    have := PhiS_le cert0.le_max jc x
    have hM : ((p0.M : ℕ) : ℝ) = 4 := by norm_num [p0]
    rw [hM] at this
    linarith
  have hT2b : 0 ≤ PhiS W0 jc x := PhiS_nonneg cert0.nonneg jc x
  have he1 : (1 / 2 : ℝ) / cf3Rate p0 * (cf3Rate p0 * (1 / 10)) * ((300 : ℕ) : ℝ) = 15 := by
    rw [hΛ]; norm_num
  have hT2 : 1 * (Real.exp (-((1 / 2 : ℝ) / cf3Rate p0 * (cf3Rate p0 * (1 / 10)) * ((300 : ℕ) : ℝ)))
      * PhiS W0 jc x) ≤ 320 / 2900000 := by
    rw [he1, one_mul]
    have := exp_15
    have hE : 0 ≤ Real.exp (-(15 : ℝ)) := (Real.exp_pos _).le
    nlinarith
  -- post phase
  have hM : ((p0.M : ℕ) : ℝ) = 4 := by norm_num [p0]
  have hpost : postErr p0 b0 7120 (99911 / 100000) 6 (1 / 10) 500 5 300
      ≤ 5184 / 10 ^ 10 + 300 * (3 * (4 / 10 * b0) + 1 / 10 ^ 10) := by
    unfold postErr
    have he2 : (1 - 1 / (6 : ℝ)) / cf3Rate p0 * (cf3Rate p0 * (1 / 10)) * ((300 : ℕ) : ℝ) = 25 := by
      rw [hΛ]; norm_num
    rw [he2, hM]
    have hb := blockErr_p0 3 le_rfl ((6 : ℝ) ^ (5 - 1)) 0
    have hc3 : p0.c = 3 := rfl
    rw [hc3]
    have := exp_25
    have hE : 0 ≤ Real.exp (-(25 : ℝ)) := (Real.exp_pos _).le
    have h6 : (6 : ℝ) ^ (5 - 1) = 1296 := by norm_num
    rw [h6] at hb ⊢
    have hb' : blockErr p0 3 b0 1296 0 7120 (99911 / 100000) (1 / 10) 500
        ≤ 3 * (4 / 10 * b0) + 1 / 10 ^ 10 := by
      have e : ((3 : ℕ) : ℝ) = 3 := by norm_num
      rw [e] at hb
      linarith
    have e300 : ((300 : ℕ) : ℝ) = 300 := by norm_num
    rw [e300]
    nlinarith
  -- pre phase
  have hpre : ((300 : ℕ) : ℝ) * blockErr p0 (p0.c - 1) b0 1 (p0.M * b0 / cf3Rate p0) 7120
      (99911 / 100000) (1 / 10) 500 ≤ 300 * (2 * (4 / 10 * b0) + 4 / 10 * b0 + 1 / 10 ^ 10) := by
    have hc2 : p0.c - 1 = 2 := rfl
    rw [hc2]
    have hb := blockErr_p0 2 (by norm_num) 1 (p0.M * b0 / cf3Rate p0)
    rw [hM, hΛ] at hb ⊢
    have e : ((2 : ℕ) : ℝ) = 2 := by norm_num
    rw [e] at hb
    have e300 : ((300 : ℕ) : ℝ) = 300 := by norm_num
    rw [e300]
    have e5 : (1 : ℝ) * (4 * b0 / 157515864 * 15751586.4) = 4 / 10 * b0 := by ring
    rw [e5] at hb
    linarith
  have hb : b0 ≤ 13 / 10 ^ 7 := le_of_eq rfl
  linarith
```

For assessing transfer, the fixed auxiliary dependencies visible here are `cert0`, `cf3Rate_p0`, `Hs_p0`, `blockErr_p0`, `W0_ready`, `exp_15`, and `exp_25`. In particular, `blockErr_p0` supplies the original service-tail contribution at7120 and the original rho; copying this proof does not provide the corresponding lower-rate bound.

The explicit **parameterized composition statement** is in `RECOVERY_DEADLINE_DECISION_20261013.md`, “Exact admissible time and risk”:

> Keep acquisition at30, the original two phases, all600 fixed .1 service blocks, and eleven whole-population Ready512 returns. Let h>0 be each return deadline and w>0 each of ten first-actual-division waiting deadlines. The recursively defined times on successful prefixes obey
>
> tau_0<=30+h, tau_10<=30+11h+10w.
>
> Thus the same horizon is preserved whenever11h+10w<=30.

Its local input and conclusion are stated exactly as:

```text
Define q(h)=sup_(x in K16, arbitrary fuel)
 P_x(H512>h AND D16>h),
for the literal full source and original first hits.

P(full parameterized mission failure)
 <=1/500+11q(h)+10exp(-4w)+3exp(-20).
```

The note’s proof statement is:

> The four basal clocks justify exp(-4w); the first ACTUAL division is no later than their first event. Complete marked divisions and all-time floor survival are retained. Charge each recovery/wait only on its exposed preceding-success history, then use G60 to exclude floor exits; do not condition a recovery law on future G60. Budgets and service are events of the same original60-time law.

Canonical manuscript §7.3 defines the actual renewal events:

```text
Let tau0 be the first time at or after30 when all twelve counts
are at least512.

For r=1,...,10 let sigma_r be the first actual basal or triggered
division strictly after tau_(r−1), and let tau_r be the first
whole-population512-ready time at or after the COMPLETE sigma_r mark.

Define E(h,w) by:
tau0<=30+h,
sigma_r−tau_(r−1)<=w,
tau_r−sigma_r<=h, r=1,...,10.
```

Its substantive proof is:

> At each recovery start with all twelve counts at least16, Section6 bounds the local surviving nonreturn by q(h); an already Ready start has zero nonreturn. On G60 every relevant state after30, including a full division update, is floor-admissible. To compose, charge first failure only on the histories where previous episodes succeeded and no prior floor failure has occurred. Those indicators are measurable at the exposed start. Intersecting a late-recovery event with G60 is contained in surviving nonreturn, because G60 prevents its floor exit. Apply conditional restart and the tower property to the exposed indicators, without conditioning the future on G60 itself. Eleven recovery errors contribute at most11q(h).
>
> At any finite start, the four state-independent basal clocks have total rate4. They can be realized as independent clocks among the physical channel drivers; the same fresh-law argument applies after stopping. The first actual division occurs no later than the next basal firing, even though triggered divisions and other chemistry are correlated. Each wait failure contributes at mostexp(−4w). Ten wait failures therefore contribute at most10exp(−4w), without independence between episodes.

The conditional-restart proof immediately preceding it, §7.2, states:

> At an exposed stopping index, independent tails of the wait/mark sequence prove restart by summing over the index's value. For an arbitrary finite stopping time sigma in the natural nonanticipating marked history, first prove restart at deterministic times by Poisson independent increments and exponential lack of memory. It then holds at grid-valued stopping times by splitting over their values. Approximate sigma from above by sigma_m=2^(−m)ceil(2^m sigma). On any bounded interval there are finitely many ticks almost surely, so X(sigma_m)=X(sigma) eventually; right continuity gives eventual equality of each fixed future cylinder. Dominated convergence and a monotone-class argument give the full conditional future-path law. Localization removes boundedness of sigma. The same limit retains the fresh residual wait and all unseen marks. No future waiting time is exposed in this filtration.

The source then requires applying recovery to the **completed physical state**, freshly stopped at its local H/D boundary, while carrying service-grid position, stocks and past flags.

The last \(3e^{-20}\) term is justified by canonical §7.4:

> Construct the finite-stock version with the SAME waits, channel, victim and complementary split marks as the original process, stopping at the first attempted excess of a declared original resource. Before that mark the complete paths and rates agree by induction; on R60 no excess occurs through60. Apply this coupling to the entire event G60 intersect E(1/5,2), already proved on the original law, and union-bound the three global tails once.

Thus the parameterized composition requires the same-model \(G60\) allowance, uniform stopped-restart recovery input, successful deadlines within60, and same-model resource tails/coupling. It introduces no additional numerical beta condition in its displayed formula.

Recorded SHA-256 pins, reused without rehashing:

| Source | SHA-256 |
|---|---|
| MissionBound.lean | `46bf87d7b280e6a7fa53371d4faa871cc61b7e42b6fd9eabc624163af603c6c0` |
| Main.lean | `721fa9694bdc85239456fe11e64d9f64932ebf5c32481c83ff5fbdf0e6b36b38` |
| SOURCE_GATE_PROOF_EXCERPTS_20261013.txt | `6fae9db69186e9d3eeda259666428be6da65dedb8f00b0c7ca7267348616bb6b` |
| RECOVERY_DEADLINE_DECISION_20261013.md | `bd53a2e83f87e1c8de811f4ce8de06191d0c322b83bfb2a83cda151d560677cc` |
| TECHNICAL_PROOF_MILESTONE.md | `85819e6ee8f865fe41399dd7bdbdd6da26591a2860e881d89e052ceb0ebfdf3d` |
| CANONICAL_MANUSCRIPT.md | `0d131feb093fcc8c345befa69b53bc43421baa5256e40b67d5140b2d19417c56` |

This completes the requested copying; it does not declare a lower-rate corollary accepted.
