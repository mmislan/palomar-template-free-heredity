**The displayed service inequalities use \(Y=2^{-q}\) times the fuel weight. The quota multiplier is exactly \(2^m/\rho\)**, where `m` is the required credit count. For the500-credit contract it is \(2^{500}/\rho\). `K128` is the retention floor, not the quota exponent.

I retrieved this from the writer’s pinned [SOURCE_GATE_PROOF_EXCERPTS_20261013.txt](../../../PROOF_NAVIGATION.md), without reopening upstream sources or rerunning hashes.

`Mission.tick_service`, original lines200–204, states:

```lean
theorem tick_service (hp : p.Valid) {K : ℕ} {ρ θs : ℝ}
    (hρ0 : 0 ≤ ρ) (hρ1 : ρ ≤ 1)
    (hρh : 1 / 2 ≤ ρ)
    (hθs : θs ≤ cf3Rate p)
    (hθβ : θs ≤ p.β * (1 - ρ))
    (hsrv :
      (p.β + 1) * ((K : ℝ) / p.N) * (1 / 2 - ρ)
        + Hs p * (1 - ρ) + θs * ρ ≤ 0)
    (req : Finset (Fin p.c)) (ij : Fin p.M × Fin p.c)
    (hj : ij.2 ∈ req) (x : Pop p) :
    (Kd hp K req).P (Ysrv ρ ij) x
      ≤ (1 - θs / cf3Rate p) * Ysrv ρ ij x := by
```

The proof explicitly fixes the credit tilt:

```lean
set g : ℝ := (1 / 2 : ℝ) ^ ((y ij.1).q ij.2) with hg
...
have hhalf :
    (1 / 2 : ℝ) ^ ((y ij.1).q ij.2 + 1) = g / 2 := by
  rw [pow_succ]; ring
```

Thus `ρ` changes the fuel multiplier, while the credit tilt stays one-half per credit. The writer’s map records:

```text
Hs(p)=alpha*c*N*(9/16)+beta*c+2c+2
Y=2^(-q)*(rho if fueled else1)
```

`MissionBound.okS_detect`, original lines24–26, supplies the exact missed-quota normalization:

```lean
theorem okS_detect {ρ : ℝ} (hρ : 0 < ρ) (hρ1 : ρ ≤ 1)
    (m : ℕ) (req : Finset (Fin p.c)) (y : Pop p)
    (h : ¬ okS m req y) :
    ∃ k ∈ (univ : Finset (Fin p.M)) ×ˢ req,
      1 ≤ (2 : ℝ) ^ m / ρ * Ysrv ρ k y := by
```

Its proof uses:

```lean
have hq :
    (1 / 2 : ℝ) ^ m ≤ (1 / 2 : ℝ) ^ ((y i).q j) :=
  pow_le_pow_of_le_one (by norm_num) (by norm_num) hlt.le

have hfac : ρ ≤ (if (y i).R then ρ else 1) := by
  split_ifs <;> linarith
```

The resulting service term appears literally in `blockErr`, original lines49–51:

```lean
def blockErr (p : Par) (nreq : ℕ)
    (b cV bV θs ρ w : ℝ) (m : ℕ) : ℝ :=
  nreq * (p.M * b) / cf3Rate p * (cf3Rate p * w)
    + cV * (bV * (cf3Rate p * w))
    + (2 : ℝ) ^ m / ρ *
        (((p.M * nreq : ℕ) : ℝ) *
          Real.exp (-(θs / cf3Rate p * (cf3Rate p * w))))
```

For the proposed \(\rho=.9956,\theta_s=4400\), the source expression for the unchanged500-credit/0.1 block is therefore

\[
S_{\rm block}=\frac{4\,n_{\rm req}}{.9956}\,2^{500}e^{-4400(0.1)}.
\]

This is substitution into the source formula only; I did not test the proposed witness. Its use with `K=128` requires the corresponding killed dynamics to retain required counts at least128.

The **complete branching acquisition certificate** is `Defs.SiteCert`, original lines219–225:

```lean
structure SiteCert (p : Par) (K : ℕ)
    (W : ℕ → Bool → ℝ) (θ b Wmax : ℝ) : Prop where
  nonneg : ∀ a R, 0 ≤ W a R
  le_max : ∀ a R, W a R ≤ Wmax
  ge_one : ∀ a R, a < K → 1 ≤ W a R
  drift :
    ∀ a R Hf Uf,
      a ≤ p.N →
      0 ≤ Uf →
      Uf ≤ (p.c : ℝ) - 1 →
      p.β * Uf ≤ Hf →
      Hf ≤ p.β * Uf
        + p.α * p.N * (9 / 16) * ((p.c : ℝ) - 1) →
      siteOp p W a R Hf Uf ≤ -θ * W a R + b
```

This requires the drift for **every count from0 throughN**, both fuels, and every admissible foreign-load pair. The branching operator includes the actual daughter gains; it is not the recovery-only killed chemical generator. Its complete definition in the pinned excerpt is:

```lean
def binE (g : ℕ → ℝ) (a : ℕ) : ℝ :=
  ∑ k ∈ range (a + 1), ((a.choose k : ℕ) : ℝ) / 2 ^ a * g k

def siteOp (p : Par) (W : ℕ → Bool → ℝ)
    (a : ℕ) (R : Bool) (Hf Uf : ℝ) : ℝ :=
  let u : ℝ := (a : ℝ) / p.N
  if R then
    p.ε * (1 - u) * (W (a + 1) true - W a true)
      + p.α * a * (1 - u) * (W (a + 1) false - W a true)
      + p.α / 2 * a * (W (a - 1) false - W a true)
      + a * (W (a - 1) true - W a true)
      + (p.β * (1 + u) + Hf) * (W a false - W a true)
      + (binE (fun k => W k true) a
          + binE (fun k => W k false) a - 2 * W a true)
      + (u + Uf) *
          (2 * binE (fun k => W k false) a - W a true)
  else
    p.ε * (1 - u) * (W (a + 1) false - W a false)
      + a * (W (a - 1) false - W a false)
      + p.β * (W a true - W a false)
      + (2 * binE (fun k => W k false) a - 2 * W a false)
```

The **floor-retention certificate**, `RetCert.lean`, original lines16–22, is weaker in drift but retains the below-floor barrier:

```lean
structure RetCert (p : Par) (K : ℕ)
    (W : ℕ → Bool → ℝ) (b Wmax : ℝ) : Prop where
  nonneg : ∀ a R, 0 ≤ W a R
  le_max : ∀ a R, W a R ≤ Wmax
  ge_one : ∀ a R, a < K → 1 ≤ W a R
  drift :
    ∀ a R Hf Uf,
      K ≤ a →
      a ≤ p.N →
      0 ≤ Uf →
      Uf ≤ (p.c : ℝ) - 1 →
      p.β * Uf ≤ Hf →
      Hf ≤ p.β * Uf
        + p.α * p.N * (9 / 16) * ((p.c : ℝ) - 1) →
      siteOp p W a R Hf Uf ≤ b
```

The exact transfer theorem is:

```lean
theorem SiteCert.toRet
    (h : SiteCert p K W θ b Wmax) (hθ : 0 ≤ θ) :
    RetCert p K W b Wmax where
  nonneg := h.nonneg
  le_max := h.le_max
  ge_one := h.ge_one
  drift a R Hf Uf _ ha h1 h2 h3 h4 := by
    have := h.drift a R Hf Uf ha h1 h2 h3 h4
    have := mul_nonneg hθ (h.nonneg a R)
    linarith
```

Accordingly, a `K128` branching certificate would need its stated barrier for **all counts below128**, including absent-candidate counts. A service-row check alone supplies neither that barrier nor the acquisition drift.

The original beta8m certificate is explicitly:

```lean
theorem cert0 : SiteCert p0 16 W0 (1 / 2) b0 80
```

with `b0 = 13/10^7` and prepared-region bound:

```lean
theorem W0_ready :
    ∀ a R, 512 ≤ a → W0 a R ≤ 6 / 10 ^ 8
```

The writer’s map records how these obligations enter acquisition and floors:

```text
Acquisition uses Phi_candidate(x0)<=M*Wmax=320
and decay320*exp(-theta*30).
At old theta1/2 this is320*exp(-15)<=320/2900000.

The prepared old founders contribute only
8*(6/10^8)=48/10^8.

Mission.gen_PhiReq_ret and tick_guard charge
nreq*M*b*w per block.
```

The pinned `mission_lower` statement requires `SiteCert`, nonnegative `θ` and `b`, and both service inequalities. Its lower bound is:

```lean
1 - PhiReq W (univ.erase jc) x
  - Real.exp (-(θ / cf3Rate p * (cf3Rate p * w) * Lα))
      * PhiS W jc x
  - postErr p b θs ρ z w m D Lp
  - Lα * blockErr p (p.c - 1) b 1
      (p.M * b / cf3Rate p) θs ρ w m
≤ mission hp K m D Lα Lp w jc x
```

The writer’s receipt records `READ_ONLY_SOURCE_GATE_MAP_COMPLETE` at **2026-10-13T05:33:12Z**, with `variantMissionClosed: false`. Recorded artifact pins are:

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| CHANGED_RATE_SOURCE_GATE_MAP_20261013.md | 11802 | `c6a5cdc8a7695a74d430f16a7191d4073b91b4ee2a563a642bda1f3d3e225d7f` |
| SOURCE_GATE_PROOF_EXCERPTS_20261013.txt | 88617 | `6fae9db69186e9d3eeda259666428be6da65dedb8f00b0c7ca7267348616bb6b` |

No new source theorem or witness validation was performed.
