#!/usr/bin/env python3
"""Independent exact review of the additive beta4m general-credit witness.
Only Python standard-library rational arithmetic. No producer code is imported
or run, no inputs are rewritten, and no compiler, solver, simulation, or sweep.
"""
from fractions import Fraction as R
from math import comb, factorial, prod
from functools import lru_cache
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
CAND = BASE / 'lower_rate_service_next'
PINS = {
    'GENERAL_CREDIT_TILT_AND_BETA4M_CANDIDATE_20261013.md': '9adf869a363b3142fc56e51ca278d2f9a05208de50688977ae9bb2750f5dddf7',
    'general_credit_tilt_certificate.py': 'b6e6e340af442ce69faf937b2c38c3ae127a3f39cdcf4cb839fe8621f27d6280',
    'general_credit_tilt_results.json': 'd839b53e55167ea93df3922e238c236d979bff20fbcbba4b2f2cce887fef7ea4',
    'general_credit_tilt_stdout.txt': 'd839b53e55167ea93df3922e238c236d979bff20fbcbba4b2f2cce887fef7ea4',
}
for name, digest in PINS.items():
    assert hashlib.sha256((CAND / name).read_bytes()).hexdigest() == digest
for line in (CAND / 'GENERAL_TILT_SHA256SUMS.txt').read_text().splitlines():
    digest, name = line.split()
    assert PINS[name] == digest
assert (CAND / 'general_credit_tilt_results.json').read_bytes() == (CAND / 'general_credit_tilt_stdout.txt').read_bytes()
producer = json.loads((CAND / 'general_credit_tilt_results.json').read_text())

# An independent exact Taylor implementation; powers/factorials, not producer
# recurrence. The upper remainder has successive term ratio at most x/(n+2).
def exp_lower(x, n):
    return sum((x**j / factorial(j) for j in range(n + 1)), R(0))
def exp_upper(x, n):
    assert R(0) <= x < n + 2
    return exp_lower(x, n) + x**(n+1)/factorial(n+1)/(1-x/R(n+2))
def ceil18(x):
    return R((x.numerator*10**18 + x.denominator - 1)//x.denominator, 10**18)
def show(x):
    return str(x)

N = 2048
beta = R(4_000_000)
z = R(3,4)
rho = R(79967,80000)
delta = 1-rho
theta = R(1650)
b0 = R(13,10**7)
Hs = 3*800*R(N)*R(9,16) + 3*beta + 8
Lambda = 4*(3*(6+800*N+400*N+N+beta)+beta+4)
assert Hs == 14764808 and Lambda == 93515864
assert 0 < z <= rho <= 1 and 0 <= theta <= Lambda
assert theta == beta*delta
assert R(1,2) <= Lambda and 1 <= Lambda
residual = beta*R(16,N)*(z-rho)+Hs*delta+theta*rho
assert residual == -R(598067,10000)
# Every physical count in the live range, both fuels. The generator envelope
# includes all three active pairs, discharge/two other jobs, and every touching
# division at total rate <=8; off-fuel division gains are nonpositive.
row_count = 0
for a in range(16, N+1):
    assert -beta*delta + theta <= 0
    assert beta*R(a,N)*(z-rho)+Hs*delta+theta*rho <= residual < 0
    row_count += 2
assert row_count == 4066
# All-count local chemistry maxima and reset envelopes, no donor-state assumption.
for a in range(N+1):
    assert R(a,N)*(R(3,2)-R(a,N)) <= R(9,16)
assert 1+3 == 4 and 3*R(4,3) == 4

# Two independent positive-series lower bounds for exp(165). The first
# independently reproduces the exact producer bound; the factorized one is tighter.
service_200 = 12/rho/z**500/exp_lower(R(165),200)
service_alt = 12/rho/z**500/exp_lower(R(33,2),100)**10
service_ceiling = R(1948303823,250000000000000000)
assert service_200 < service_ceiling < R(1,10**8)
assert service_alt < service_200
assert ceil18(service_200) == service_ceiling
assert producer['service_union_per_block_upper_ceiling'] == str(service_ceiling)

# Direct beta4m SiteCert operator verification, independently assembled from
# the literal seven physical/source terms. Full branching, with no floor killing.
D = R(1860480)
def hfact(a):
    return R(1, prod(range(a+1,a+6)))
scale = D*hfact(12)/R(3,4)**12
@lru_cache(None)
def A(a):
    return scale*R(3,4)**a if a <= 12 else D*hfact(a)
@lru_cache(None)
def gap(a):
    return A(a)*(R(-1,2) if a == 0 else min(6*a,70))
@lru_cache(None)
def weight(a, fuel):
    return A(a) if fuel else A(a)+gap(a)/beta
@lru_cache(None)
def daughter_moments(a):
    # E[hfact(Bin(a,1/2))] via the beta integral, plus finite prefix correction.
    integral = 32*hfact(a) - R(4,3)*sum((R((-1)**j*comb(4,j),(a+j+1)*2**(a+j+1)) for j in range(5)),R(0))
    ea = D*integral + sum((comb(a,k)*(A(k)-D*hfact(k)) for k in range(min(a,11)+1)),R(0))/2**a
    eg = 70*ea + sum((comb(a,k)*(gap(k)-70*A(k)) for k in range(min(a,11)+1)),R(0))/2**a
    return ea, ea+eg/beta

def branching(a, fuel, foreign_jobs, foreign_excess):
    u = R(a,N)
    w = weight(a,fuel)
    prev = max(a-1,0)
    et, ef = daughter_moments(a)
    terms = [6*(1-u)*(weight(a+1,fuel)-w), a*(weight(prev,fuel)-w)]
    if fuel:
        terms += [800*a*(1-u)*(weight(a+1,False)-w),
                  400*a*(weight(prev,False)-w),
                  (beta*(1+u+foreign_jobs)+foreign_excess)*(weight(a,False)-w),
                  et+ef-2*w,
                  (u+foreign_jobs)*(2*ef-w)]
    else:
        terms += [beta*(weight(a,True)-w), 2*ef-2*w]
    return sum(terms,R(0))+R(1,2)*w

family_bound = R(8,10**7)+R(1,4)*(R(131,10**8)-R(8,10**7))
assert family_bound == R(371,400000000) < b0
maximum = None
branch_rows = 0
for a in range(N+1):
    for fuel in (False,True):
        for U in (0,2):
            for excess in (0,1843200):
                value = branching(a,fuel,U,excess)
                assert value <= family_bound < b0
                branch_rows += 1
                if maximum is None or value > maximum[0]:
                    maximum = (value,a,fuel,U,excess)
assert branch_rows == 16392
# Complete direct daughter sums independently cross-check the closed transforms.
spot_counts = sorted({0,1,11,12,13,15,16,511,512,868,979,2048,maximum[1]})
for a in spot_counts:
    et, ef = daughter_moments(a)
    assert et == sum((comb(a,k)*weight(k,True) for k in range(a+1)),R(0))/2**a
    assert ef == sum((comb(a,k)*weight(k,False) for k in range(a+1)),R(0))/2**a
assert 0 < scale < 80 and A(15) == 1
for a in range(16):
    assert weight(a,False) >= 1 and weight(a,True) >= 1
assert max(weight(512,False),weight(512,True)) <= R(6,10**8)
# Infinite-domain extension follows from strict monotonicity proved in review.
for a in range(13):
    assert weight(a+1,False) < weight(a,False)

# Reconstruct the source's pre/post block coefficients, without claiming that
# its fixed-half-credit theorem applies to z=3/4.
block_length = R(1,10)
pre_guard = 2*4*b0*block_length + 4*b0*block_length
post_guard = 3*4*b0*block_length
assert pre_guard == post_guard == R(6,5)*b0
assert R(1,2)*300*block_length == 15
assert (1-R(1,6))*300*block_length == 25
assert 4*6**4 == 5184
assert exp_lower(R(15),100) > 2900000 and exp_lower(R(25),100) > 10**10
g60 = R(48,10**8) + R(320,2900000) + 600*(pre_guard+R(1,10**8)) + R(5184,10**10)
assert g60 == R(9545923,9062500000) < R(1,500)
assert producer['g60_budget'] == str(g60)
# Separate audit cross-check: direct stopped aggregate-potential retention gives
# 480b for old species through60 and 8b+120b for candidate at/after30. The
# resulting 608b fits strictly inside the source's conservative 720b allocation.
assert 608*b0 < 720*b0
independent_g60_comparison = R(48,10**8)+R(320,2900000)+608*b0+600*R(1,10**8)+R(5184,10**10)
assert independent_g60_comparison < g60

# Accepted uniform recovery family: independently re-evaluate its final exact
# low-word/Poisson/clock bound from the previously audited constants.
Mrec = R(338971453059,125000)
gamma = 154-R(12,4700)
T = R(1,2)
mean = R(321,100)
clock_exponent = R(9141301,460320)
low_words = Mrec*sum(((478*T)**k/factorial(k) for k in range(14)),R(0))/exp_lower(gamma*T,200)
poisson_tail = 1-sum((mean**k/factorial(k) for k in range(14)),R(0))/exp_upper(mean,200)
clock_tail = 1/exp_lower(clock_exponent,200)
q = ceil18(low_words+poisson_tail+clock_tail)
assert q == R(8622092430140,10**18) < R(1,100000)
assert R(10000,9999)*R(95467565097,200000000)/R(9997,10000) < 478
kappa_rec = 3/(5*beta+1200*N)
var_rec = 20*beta+5400*N+64
Ebeta = R(1,640)*(R(1,100)/kappa_rec-4) - var_rec*T*R(1,640)**2/(2*(1-R(1,960)))
assert Ebeta == clock_exponent+R(509,36825600)*(beta-1000000) > clock_exponent
assert 4+12*beta/(5*beta+1200*N) <= R(32,5)
deadline = 30+11*T+10*2
assert deadline == R(111,2) < 60
assert 300*4*2+300*4*3 == 6000
assert 6000*500 == 3_000_000
mission = ceil18(g60+R(11,100000)+10/exp_lower(R(8),200)+3/exp_lower(R(20),200))
old_mission = ceil18(R(1,500)+R(11,100000)+10/exp_lower(R(8),200)+3/exp_lower(R(20),200))
assert mission == R(4517975690072193,10**18)
assert old_mission == R(5464632462485986,10**18)
assert producer['full_risk_using_new_g60_ceiling'] == str(mission)
assert g60 < mission < R(1,100)

# SR3 occupation-sensitive feed bound includes both victim-fuel channels.
assert beta+1 >= R(800*N,2)
Cstar = beta+3*(R(800*N,2)+beta+1)
assert Cstar == 18457603
t = R(1,10000)
s = R(400,22457607)
assert 0 < s < t < 1
kap_off = beta*(t-s)/(1-(t-s))
kap_on = (Cstar+1+3/(1-s))*s/(1-s)
assert kap_off == R(73830428000000,224557612393)
assert kap_off >= kap_on
feed_exponent = 4*s+240*kap_off-t*800000000
assert feed_exponent == -R(5508991479342664251200,5043026607980323551) < -1092 < -20
# For seeds exp(.1)<1/(1-.1); divisions use an independently certified exp(.2).
assert 4320*R(1,9)-500 == -20
assert exp_upper(R(1,5),40)-1 < R(31,140)
assert 960*R(31,140)-240 == -R(192,7) < -20
resources = dict(accepted_feed=800000000,consumed_fuel=800000004,accepted_seed=5000,
                 birth_plus_seed=800005004,marked_divisions=1200,
                 discarded_restored_catalyst_slots=3*N*1200,discarded_victim_fuel=1200)
assert resources == producer['resource_ceilings']

# The all-tilt floor-only beta1m limitation is architectural, not an actual
# stochastic service lower bound. Check the exact coefficient, plus+1 variant.
B1 = R(1000000)
H1 = 3*800*R(N)*R(9,16)+3*B1+8
limit = B1*(B1*R(16,N))/(B1+H1)
assert limit == R(976562500,845601) < 1155 < 5000
assert (limit*(1+1/B1))*R(1,10) < 500

sources = ['EXACT_SERVICE_AND_BRANCHING_SOURCE_20261013.md',
           'EXACT_CSTAR_RESOURCE_SOURCE_20261013.md',
           'FULLER_ORIGINAL_G60_SOURCE_RETRIEVAL_20261013.md',
           'GENERIC_MISSION_AND_COMPOSITION_SOURCE_20261013.md',
           'LOWER_RATE_VALIDITY_AND_RESOURCE_SOURCE_20261013.md',
           'historical_reference/TEMPLATE_FREE_RECOVERY_MANUSCRIPT_20261013.md',
           'beta1m_branching/BETA1M_BRANCHING_CERTIFICATE_20261013.md',
           'reciprocal_beta_recovery/UNIFORM_RECIPROCAL_BETA_RECOVERY_20261013.md',
           'lower_rate_mission/LOWER_RATE_MISSION_AUDIT_20261013.md',
           'lower_rate_service_next/OCCUPATION_SERVICE_LEMMA_20261013.md']
source_digests = {p:hashlib.sha256((BASE/p).read_bytes()).hexdigest() for p in sources}
restored = json.loads((BASE/'transport_lower_rate_20261013/recovered_paths.json').read_text())
for p, digest in source_digests.items():
    if p in restored:
        assert restored[p] == digest
result = {
 'status':'PASS independent analytical beta4m review; no canonical adoption or compiler claim',
 'candidate_verified_sha256':PINS,
 'service':{'beta':str(beta),'z':str(z),'rho':str(rho),'theta':str(theta),'Hs':str(Hs),
            'uniformization_rate':str(Lambda),'fueled_residual':str(residual),'live_count_fuel_envelope_rows':row_count,
            'producer_taylor_200_union_bound_ceiling':str(ceil18(service_200)),
            'independent_factorized_union_bound_ceiling':str(ceil18(service_alt))},
 'branching':{'literal_full_operator_rows':branch_rows,'direct_daughter_sum_counts':spot_counts,
              'maximum_location':list(maximum[1:]),'maximum_ceiling':str(ceil18(maximum[0])),
              'accepted_family_interpolation_bound':str(family_bound)},
 'g60_only':{'candidate_conservative_bound':str(g60),'candidate_conservative_bound_ceiling':str(ceil18(g60)),
              'separate_direct_potential_comparison':str(independent_g60_comparison)},
 'complete_mission':{'recovery_tail_recomputed':str(q),'renewal_deadline':str(deadline),
                     'service_deadline':60,'coordinate_block_quotas':6000,'credits':3000000,
                     'failure_bound':str(mission),'failure_bound_using_1_over_500_g60':str(old_mission)},
 'resources':{'Cstar':str(Cstar),'kappa_upper':str(kap_off),'feed_exponent_upper':str(feed_exponent),'ceilings':resources},
 'beta1m_pointwise_floor_effective_rate_upper':str(limit),
 'source_sha256':source_digests,
 'restrictions':['analytical only; no Lean compilation','no producer edits or canonical adoption',
                 'accepted full branching/recovery family proof dependencies retained',
                 'beta1m full service and mission remain open']
}
(HERE/'independent_general_tilt_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
