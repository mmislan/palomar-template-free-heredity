# Template-free recovery from a shared-fuel clock

## Main conclusion

For the actual four-site, three-species marked network described below, let H be the first time all twelve counts are at least 512 and D the first time any count falls below 16. Uniformly over admissible initial counts and arbitrary fuel bits,

P(H > 0.2, D > 0.2) <= 0.000015793024278444 < 1/50000.

The same estimate holds conditionally at every admissible stopping-time restart of the underlying physical marked process. It controls surviving nonreturn; floor failure is a separate event.

The result follows from a general potential-and-resource-clock theorem. Its reset count is handled by a correlated Poisson time change, not by assuming independent Poisson divisions. All chemical drift, paired reset, fuel balance and variance inputs are checked for the actual network.

When inserted into the existing mission composition theorem with the original division-wait cap 2, the proposed main corollary has a ten-renewal sequence bound of 52.2 and retains the three-million-job deadline of 60 on the unchanged service grid. The supplied mission failure expression is at most 0.005574632462485986, below 0.01. Final local initialization/service/resource integration is recorded separately from the recovery proof. The recovery deadline is explicitly changed from 0.1 to 0.2; the original 0.1/1/2500 recovery gate remains open.

## 1. General potential-and-resource-clock theorem

Let X_phys be a time-homogeneous finite-state physical marked CTMC with finite total marked-event rate in each state, including marked events whose state update is null. For a chosen run, stop at a specified recovery/failure boundary tau, retaining the actual terminal value of any auxiliary resource statistic.

Distinguish reset marks with predictable intensity nu and stopped count N_t. Null marked resets are counted. Let Q be the live generator with reset marks removed and included as killing; let B be their positive live-poststate gain operator.

Let A be an admissible set of live starting states. Suppose a nonnegative potential U and constants M, gamma, C > 0 satisfy

U >= 1 on live states,
sup_(x in A) U(x) <= M,
Q U <= −gamma U,
B U <= C U.

Suppose a bounded resource statistic F and constants Fmax, a, kappa, b, V > 0 satisfy

0 <= F <= Fmax,
nu−a <= −kappa L F on live states,
|Delta F| <= b,
sum_e rate_e(x)(Delta_e F)^2 <= V on live states.

The bounds include actual transitions into the boundary and terminal F values. L is the stopped physical generator. After retained stopping, nu=LF=0, so the drift inequality holds there automatically.

Then for every T>0, integer K>=1, delta>kappa Fmax, and 0<theta<3/b,

P(tau>T)
 <= M exp(−gamma T) sum_(j=0)^(K−1)(CT)^j/j!
  + P(Poisson(aT+delta)>=K)
  + exp[−theta(delta/kappa−Fmax)
         +VT theta^2/(2(1−b theta/3))].

This bounds surviving nonreturn, not recovery failure alone. A mission success theorem must separately control boundary failure.

### Conditional restart form

Let sigma be an almost-surely finite stopping time for the natural marked history of the underlying physical process, with X_phys(sigma) in A. Define the local boundary time in the shifted process X_phys(sigma+u), and freshly stop that run there. The same deterministic right-hand side bounds the conditional surviving-nonreturn probability given the complete history through sigma.

This follows from the marked strong Markov property and the uniform pointwise hypotheses. It does not resume a globally stopped chain after its old absorption, condition on future survival, or reset Ready history within a recovery word.

## 2. Proof of the general theorem

### 2.1. The low-word contribution

Write P_j(t) for the actual unnormalized live law with exactly j resets. The positive word equations are

P_0'=P_0Q,
P_j'=P_jQ+P_(j−1)B.

Induction using the U inequalities gives

P_j(t)1 <= P_j(t)U <= M exp(−gamma t)(Ct)^j/j!.

Summing j=0,...,K−1 proves the first term. Boundary killing remains in every word and every reset mark.

### 2.2. Resource balance controls the random clock

The compensated resource martingale is

M^F_t = F_t−F_0−integral_0^t LF(X_s)ds.

For the actual reset compensator Lambda_t=integral_0^t nu_s ds, the drift inequality gives

Lambda_T <= aT+kappa(F_0−F_T+M^F_T)
         <= aT+kappa(Fmax+M^F_T).

Consequently Lambda_T>aT+delta implies M^F_T>delta/kappa−Fmax. The initial resource is paid explicitly; no stationary approximation is made.

### 2.3. Bounded-jump exponential estimate

For |x|<=b and theta>=0, the exponential integral remainder gives

exp(theta x)−1−theta x
 <=(x^2/b^2)[exp(b theta)−1−b theta].

For 0<=b theta<3, the positive Taylor series gives

[exp(b theta)−1−b theta]/b^2
 <=theta^2/[2(1−b theta/3)].

The compensated-jump exponential calculation therefore yields a nonnegative exponential supermartingale. The local variance-density hypothesis bounds its predictable quadratic variation by VT. Exponential Markov inequality gives the third displayed term. Finite marked-event rates justify this calculation on every bounded time interval, including the stopped terminal jump.

### 2.4. The clock may be correlated with resets

Construct a unit-rate Poisson primitive Y for the aggregate physical reset channel, with the actual state-dependent marks sampled at its firings. Then N_T=Y(Lambda_T). Lambda and Y need not be independent.

The proof uses only the pathwise inclusion

{N_T>=K, Lambda_T<=aT+delta} subset {Y(aT+delta)>=K}.

Every Poisson path is nondecreasing, so this remains true for a clock depending on the same path. Split the live event by N_T<K or N_T>=K and union-bound the clock exception. This proves the theorem.

## 3. The physical model and its live domain

There are four sites. Each site carries three counts a_ij in {0,...,N}, N=2048, and one shared binary fuel bit R_i. The rates relevant to a selected count a are:

- seed birth: 6(1−a/N), preserving fuel;
- passive death: a, preserving fuel;
- active birth: 800 R a(1−a/N), clearing that site's fuel;
- active death: 400 R a, clearing that site's fuel;
- ordinary consuming job: beta R a/N, clearing fuel, with beta=8000000.

Each fuel-zero site recharges at rate beta. Each fuel-one site has discharge rate beta. The three ordinary-job channels are physically active throughout recovery. Independent local source review confirms that the rate function cf3Gen p has no service-window, required-species, time, or ledger gate; the service predicates and external credit ledger in Mission.lean retain the same physical generator.

A site i has basal division rate 1 and total triggered division rate R_i sum_j(a_ij/N). The victim is a uniformly selected different site. Conditional on the full premark state, chosen parent, victim and division channel, the count mark k=(k_1,k_2,k_3) and bit e in {0,1} have joint probability

P(k,e | premark state, parent, victim, channel)
 =(1/2) product_(j=1)^3 [binom(a_ij,k_j) 2^(−a_ij)],
0<=k_j<=a_ij.

Thus the three count-split variables are conditionally independent half-binomial variables, and the fair bit is independent of their complete vector. The daughter count vectors are k and a_i−k; sisters are complementary within every species. Set Rstar=R_i for a basal division and Rstar=0 for a triggered division. The daughter fuels are Rstar*e and Rstar*(1−e). Hence a basal division preserves the parent's total fuel across the complementary daughters, while a triggered division empties parental fuel first. The total fuel loss is the victim's old fuel in the basal channel and one plus that fuel in a triggered channel, whose positive rate requires R_i=1.

The live domain is the set of states with every count at least 16 and at least one count below 512. The boundary consists of original first Ready H or first floor failure D. No individual count's first crossing replaces this simultaneous Ready condition. No persistent named-sister guarantee is asserted.

An admissible starting state lies in this live domain and may have arbitrary fuel bits. A state already Ready has zero nonreturn probability. A state below the floor is outside the admissible recovery set.

## 4. Verifying the potential for this network

### 4.1. Rational two-fuel construction below the threshold

The intrinsic-cap profile h(a,R) is a rational count/fuel supersolution. Use the five bands [16,31], [32,63], [64,127], [128,255], [256,511] at common tilt 258 and nuisance cap N=2048. For a selected coordinate write

s(a)=6(1−a/N), m(a)=a,
b(a)=800a(1−a/N), d(a)=400a,
T(z)=800z(1−z/N)+400z+beta z/N,
off(a)=beta+beta a/N+2T(N).

The reference two-fuel generator is

G_ref u(a,0)=s(a)[u(a+1,0)−u(a,0)]
 +m(a)[u(a−1,0)−u(a,0)]+beta[u(a,1)−u(a,0)],

G_ref u(a,1)=s(a)[u(a+1,1)−u(a,1)]
 +m(a)[u(a−1,1)−u(a,1)]
 +b(a)[u(a+1,0)−u(a,1)]
 +d(a)[u(a−1,0)−u(a,1)]
 +off(a)[u(a,0)−u(a,1)].

In each band solve the two Dirichlet problems (G_ref+258)u=0: the left-exit column has boundary values one at the lower exit in either fuel and zero at the upper exit, and the right-exit column has the reversed values. The exact block-tridiagonal solve is followed by independent checks of the original equations, positivity, fuel ordering u(a,0)>=u(a,1), and row-sum barrier at least one. The two exit directions are merged over exit fuel only; the process inside each band still has both fuel states.

There are ten interface rows, the two count endpoints of each band in fuel zero. Build K from the corresponding neighboring-band exit coefficients, rounded upward to the grid 10^(-12), and b_term from the final band's upper-exit coefficient. The first band's lower exit is killed. Exact rational witnesses satisfy

g=b_term+Kg, g>0,
v=1+Kv, v>=1.

The second identity proves strict contraction in the weighted v norm. Within each band set h to the exact left and right exit columns multiplied by their neighboring interface values g; the terminal upper value is one and the floor value is zero. The outward interface comparisons dominate each actual continuation. Direct checks give h>=1 below 512 and h(a,0)>=h(a,1)>0.

This reference comparison is valid for the actual shared-fuel chemistry: T is increasing on [0,N], so the actual nuisance consumption is at most off(a). Its generator difference is the nonpositive product of that rate difference and u(a,0)−u(a,1). No independence of the two nuisance histories is used. The concrete rational constructors are band_exit_certificate.py and band_profile_core.py; their unchanged independently audited equations specify the finite witness completely.

### 4.2. Positive tail and actual generator inequality

Above 512, the construction uses the positive tail

f(a)=(980−a)(981−a)(982−a)/[(a−10)(a−9)(a−8)] for a<=768,
f(a)=f(768)(10/11)^(a−768) for a>768,

and set h(a,R)=f(a)[1−delta(a)R]/f(512). For 512<=a<768 use

k(a)=s(a)[f(a+1)/f(a)−1]+m(a)[f(a−1)/f(a)−1],
delta(a)=[258+k(a)]/beta.

For a>=768 use

delta(a)=[258+5647a/56320−6/11]/beta.

The finite exact checks establish 0<=delta(a)<1/10000 for every tail count 512<=a<=2048. They establish h(a,0)>=h(a,1)>0 on ALL counts 16<=a<=2048, and h(a,R)>=1 for 16<=a<=511 and both R in {0,1}. The tail remains positive even when both values are below one. The conservative junction at 768 is included explicitly. The uneliminated generator rows for every 16<=a<=2048 and both fuels, including the 511/512 interface and high-count returns, establish

G h <= −258h+1/4700.

Let U=sum_(i,j)h(a_ij,R_i). Shared fuel creates no difficulty for this sum: the full generator acts linearly on each actual coordinate function. On a live nonReady state U>=1. Removing resets as killing contributes at least 4, and original Ready/floor killing only decreases U. Therefore

Q U <= −(262−12/4700)U.

The finite maximum over a in {16,...,2048} and R in {0,1} is bounded by 112990484353/500000. Consequently the uniform initial bound for U is

M=12*(112990484353/500000)=338971453059/125000.

### 4.3. The actual paired reset inequality

For the reset, define

p(a,R)=1+R(2+a/2048),
M_h(a)=E[h(K,0)1{16<=K<=a−16}], K~Bin(a,1/2).

For a fixed retained site, each of the other three potential parents leaves it retained with victim probability 2/3. Each parental rate is at most 4. Thus its retained gain coefficient is at most (2/3)*3*4=8, and the total retained coordinate potential is at most 8U. Complementary-binomial symmetry and the pointwise fuel-zero envelope bound the daughter source by sum 2p(a,R)M_h(a). The full prestate fuel is retained in p; no independent daughters are substituted.

Because a live state has a count at most 511, a finite exact row check establishes

max_(16<=a<=511, R in {0,1})[2p(a,R)M_h(a)−d h(a,R)]
 +11 max_(16<=a<=2048, R in {0,1})[2p(a,R)M_h(a)−d h(a,R)] <= 0

with d=93867565097/200000000. Choosing the actual deficient coordinate as the first witness proves

B U <= C U,
C=8+d=95467565097/200000000.

For a<32 the moment M_h(a) is zero. For 32<=a<=2048 the checker sums every integer k from 16 through a−16 with its exact binomial weight. It rounds h upward to the grid 10^(-18) for the moment and uses that upper value minus 10^(-18), clipped below by zero, as a lower bound for each denominator term h(a,R). It verifies the displayed sum of the two finite maxima using these outward bounds. Thus the computed residual dominates the exact residual in every stated row. These finite assertions prove the local operator inequality; the proof does not assume recovery or infer it from sampled states.

Only the intrinsic count cap 2048 is used here. The profile and reset inequalities are time homogeneous and hold for any deterministic duration. None of the intermediate caps at times 0.02, 0.04, or 0.07, nor their cap-risk budget, is extended beyond 0.1 or used in this theorem.

## 5. Verifying the shared-fuel clock

Set

F=sum_i R_i,
z_i=sum_j a_ij/N,
Z=sum_i R_i z_i.

Then 0<=F<=4, Z<=3F, and nu=4+Z while live. Let

A_active=sum_(i,j) R_i[800a_ij(1−a_ij/N)+400a_ij].

The literal event rates give

LF=beta(4−2F−Z)−A_active−D_fuel,

where D_fuel>=0 is the physical division fuel-loss drift. Since A_active>=400N Z,

LF<=beta[4−2F−(689/625)Z].

With c=1875/3317 and a=20768/3317, the relation Z<=3F gives

nu−a <= −(c/beta)LF,
kappa=c/beta=3/42457600.

Stopping retains the terminal fuel configuration. There is no artificial jump to a zero-fuel cemetery state. Every physical fuel jump has absolute value at most 2.

The predictable quadratic-variation rate is bounded channel by channel:

- recharge: at most 4beta;
- discharge and ordinary jobs: at most 16beta;
- active events: at most 12*450N=5400N, since 1200a−800a^2/N is maximized at a=3N/4;
- division: at most 4nu<=64;
- seed and passive jumps: zero contribution.

Thus V=20beta+5400N+64=171059264. This pays arbitrary initial fuel, every chemical consuming channel, and both basal and triggered division fuel losses.

The network therefore satisfies every hypothesis of the general theorem, uniformly over admissible physical restart states and marked histories.

## 6. Main numerical corollary

Use

T=1/5, K=9, delta=3/1000, theta=1/640.

The deterministic comparison clock and Bernstein exponent are

aT+delta=4163551/3317000,
theta(delta/kappa−4)−VT theta^2/[2(1−2theta/3)]
 =18817641/767200.

The exact rational checker gives separate outward component ceilings:

- words 0 through 8: 0.000008858008362762;
- Poisson count at least 9: 0.000006934993643584;
- clock exception: 0.000000000022272099.

Adding the exact rational expressions before the final ceiling yields

P(H>0.2,D>0.2)
 <=3948256069611/250000000000000000
 =0.000015793024278444 <1/50000.

The separately rounded component values are not used to assert a smaller rounded sum. The cutoff includes all words: 0 through 8 are handled by the potential, and at least 9 by the actual physical clock. No recovery sector is omitted.

The actual recurrence theorem is uniform at admissible stopping-time restarts. Starting already Ready is an immediate recovery. The result does not bound P(H>0.2) by itself: the separate floor-protection event must still be paid in a success statement.

## 7. Mission composition with the original wait cap

The pinned mission interface supplied by the local source review is

failure <=1/500+11q(h)+10exp(−4w)+3exp(−20),
tau10 <=30+11h+10w.

The 1/500 term keeps its original separately proved global good-event/failure scope, including the required floor protection. It is not narrowed to a floor-only event, reallocated, or counted twice. The three exp(−20) terms and all original initialization, service-credit and resource hypotheses are retained.

Insert the proved q(0.2)<=1/50000 and the ORIGINAL wait cap w=2. The resulting exact mission arithmetic is

tau10 <=261/5=52.2,
failure <=2787316231242993/500000000000000000
        =0.005574632462485986 <0.01.

Tau10 is completion of the ten-division/recovery sequence. It is not the completion time of all three million credited jobs. Those remain on the unchanged 0.1 service grid through time 60. The intended headline is still three million jobs within 60 with at least 99% success, with the original 7,372,800 copy slots, 1200-division budget, and other original stock caps. The separately available 527-division resource improvement is not substituted.

The recovery deadline has changed to 0.2, exactly two original service blocks. The wait cap stays 2. No physical reaction rate or fuel channel is switched at recovery/service boundaries.

The source bridge is pinned in RECOVERY_DEADLINE_DECISION_20261013.md in the parent's local handoff directory, with the supplied composition, stopped-restart, and service/resource hashes. Exact source identities and final local parameter integration are to be attached to this section when the local review completes. This section invokes those existing source theorems; it does not assume the recovery gate, which is proved above.

## 8. Alternative evaluated points and the open sharper deadline

Two other deliberately evaluated points remain valid:

- h=0.175, K=7: q(h)<=0.000164617431183082<1/2500. With w=2, tau10<=51.925 and the supplied risk expression is below 0.01.
- h=0.158, K=6: q(h)<=0.000632876226290382<1/1500. With w=2.5, tau10<=56.738 and the supplied risk expression is below 0.01.

All job credits remain on the time-60 service grid. These are transparent deadline/risk tradeoffs, not claims of an optimized parameter. The proposed main point is h=0.2 with the original wait cap 2 and the stronger 1/50000 recovery allowance.

The original h=0.1, 1/2500 recovery gate is OPEN. The accepted partial certificates for that sharper problem remain valid, but are not silently substituted for the completed longer-deadline proof.

## 9. Exact-arithmetic proof supplement and status

The rational witness and every finite assertion in Section 4 are specified by the five-script proof supplement. Its files and exact SHA-256 digests are listed in SHA256SUMS.txt. All five source files are retained byte for byte; the proof does not rely on an assertion that a profile was previously accepted in place of its defining equations and verified inequalities.

The executable dependency and reproduction order is:

1. band_exit_certificate.py supplies the exact two-fuel Dirichlet equations and their independently rechecked uneliminated rows; band_profile_core.py supplies the rational interface witnesses and interior construction.
2. Run joint_prefix_profile_certificate.py, which imports those two constructors and verifies all positivity, fuel-order, barrier, generator and uniform-maximum assertions. For this theorem retain its first, intrinsic-2048 profile.
3. Run stagewise_q1_reset_certificate.py, which uses the identical constructor and checks the complete finite reset/witness maxima with outward rational rounding. Its first generated stage constant is C=95467565097/200000000.
4. Run recovery_clock_two_corollaries.py against the generated stagewise_q1_reset_constants.json. It proves the displayed numerical bounds by positive Taylor lower estimates and geometric-remainder upper estimates for the exponential; every operation and final ceiling is rational. Its expected output is recovery_clock_two_corollaries_results.json.

The unchanged generator and reset scripts also check three later cap stages. Those additional checks are not hypotheses or inputs of the time-homogeneous .2 proof. No earlier low-parent sector, occupation, product-hierarchy, clipped-kernel or .1 endpoint certificate is required. The manifest and README_MAIN_PROOF_20261013.md make this dependency boundary explicit.

The general theorem and physical fuel proof are analytic; numerical assertions alone are not their substitutes. PARAMETERIZED_RECOVERY_CLOCK_LEMMA_20261013.md and FUEL_CLOCK_RECOVERY_0158_THEOREM_20261013.md preserve the complete standalone lemma and literal clock derivation. The latter's .158 example is a historical alternative, not the primary deadline here. The relevant independent mathematical and exact-rational audits accompany the supplement. Both short numerical corollaries and the consolidated manuscript's scope/dependencies have been independently reviewed; the final standalone clarifications above leave every checker byte and number unchanged.

The final mission-source integration remains pending and separate. This manuscript does not claim that pending integration is already complete. No compiler, simulation, large CTMC enumeration, or user-computer mutation was used for the cloud mathematical certificates.
