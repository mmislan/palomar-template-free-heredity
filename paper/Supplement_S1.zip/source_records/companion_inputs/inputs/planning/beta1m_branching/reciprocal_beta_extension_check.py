#!/usr/bin/env python3
"""Certify this same potential family for EVERY beta>=1,000,000.

This is an affine endpoint proof, not a beta sweep. The limiting residual is
derived with beta*fuel_gap retained, never by substituting equal fuel weights.
"""
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import json
import fixed_beta1m_branching_check as fixed

N, ALPHA, EPSILON, THETA = fixed.N, fixed.ALPHA, fixed.EPSILON, fixed.THETA
X_MAX = F(1, fixed.BETA)


@lru_cache(None)
def g(a):
    return fixed.A(a) * (F(-1, 2) if a == 0 else min(6*a, 70))


@lru_cache(None)
def expectations(a):
    ea, ef = fixed.bin_weights(a)
    # By linearity, W(false)=A+X_MAX*g at the fixed endpoint.
    eg = (ef-ea) / X_MAX
    return ea, eg


def affine_residual(a, fuel, Uf, v):
    """Return exact (R_infinity, slope) with R_beta=R_infinity+slope/beta."""
    u, down = F(a, N), max(a-1, 0)
    A, ga = fixed.A, g(a)
    ea, eg = expectations(a)
    seed_A = EPSILON*(1-u)*(A(a+1)-A(a))
    passive_A = a*(A(down)-A(a))
    if fuel:
        constant = (seed_A + ALPHA*a*(1-u)*(A(a+1)-A(a))
                    + F(ALPHA, 2)*a*(A(down)-A(a)) + passive_A
                    + (1+u+Uf)*ga + 2*ea-2*A(a)
                    + (u+Uf)*(2*ea-A(a)) + THETA*A(a))
        slope = (ALPHA*a*(1-u)*g(a+1) + F(ALPHA, 2)*a*g(down)
                 + v*ga + eg + 2*(u+Uf)*eg)
    else:
        constant = seed_A + passive_A - ga + 2*ea-2*A(a) + THETA*A(a)
        slope = (EPSILON*(1-u)*(g(a+1)-ga) + a*(g(down)-ga)
                 + 2*eg-2*ga + THETA*ga)
    return constant, slope


def main():
    global_max, corner_maxima, rows, failures_old = None, [], 0, []
    for fuel in (False, True):
        for Uf in (F(0), fixed.U_MAX):
            for v in (F(0), fixed.V_MAX):
                best = None
                for a in range(N+1):
                    constant, slope = affine_residual(a, fuel, Uf, v)
                    literal_fixed = sum(fixed.siteop_terms(a, fuel, fixed.BETA*Uf+v, Uf).values(), F(0)) + THETA*fixed.W(a, fuel)
                    assert constant+X_MAX*slope == literal_fixed, ("Affine identity", a, fuel, Uf, v)
                    assert constant <= fixed.CORRECTED_B, ("Limit endpoint", a, fuel, Uf, v)
                    assert literal_fixed <= fixed.CORRECTED_B, ("Finite endpoint", a, fuel, Uf, v)
                    rows += 1
                    if constant > fixed.TARGET_B:
                        failures_old.append([a, fuel, str(Uf), str(v)])
                    cand = (constant, a, fuel, Uf, v, slope)
                    if best is None or constant > best[0]:
                        best = cand
                    if global_max is None or constant > global_max[0]:
                        global_max = cand
                value, a, fuel, Uf, v, slope = best
                corner_maxima.append({"a": a, "fuel": fuel, "Uf": str(Uf), "v": str(v),
                                      "limiting_residual": fixed.ratio_record(value),
                                      "reciprocal_beta_slope": fixed.ratio_record(slope)})
    value, a, fuel, Uf, v, slope = global_max
    limit_bound = F(8, 10**7)
    assert value < limit_bound
    beta_old_b_threshold = 1020000
    threshold_mixture = limit_bound + F(fixed.BETA, beta_old_b_threshold)*(fixed.CORRECTED_B-limit_bound)
    assert threshold_mixture == fixed.TARGET_B
    beta_4m5_mixture = limit_bound + F(fixed.BETA, 4500000)*(fixed.CORRECTED_B-limit_bound)
    assert beta_4m5_mixture == F(137, 150000000) < fixed.TARGET_B
    # Extra independent full-binomial verification for limiting maxima.
    for count in sorted({r["a"] for r in corner_maxima}):
        ea, eg = expectations(count)
        assert ea == fixed.bin_direct(fixed.A, count)
        assert eg == fixed.bin_direct(g, count)
    report = {
        "status": "PASS",
        "statement": "For every real beta>=1000000, this W_beta satisfies SiteCert p_beta 16 W_beta (1/2) (131/10^8) 80 and the prepared bound 6/10^8.",
        "formalization_status": "Exact numerical/analytical proof; no theorem prover or compiler was run",
        "checked_limiting_endpoint_rows": rows,
        "checked_affine_identity_rows": rows,
        "limiting_endpoint_violations_of_old_b": failures_old,
        "limiting_global_maximum": {"a": a, "fuel": fuel, "Uf": str(Uf), "v": str(v),
                                   "value": fixed.ratio_record(value),
                                   "slope": fixed.ratio_record(slope)},
        "coarse_limiting_bound": str(limit_bound),
        "original_b_valid_for_every_beta_at_least": beta_old_b_threshold,
        "beta4500000_interpolated_bound": fixed.ratio_record(beta_4m5_mixture),
        "limiting_corner_maxima": corner_maxima,
    }
    target = Path(__file__).with_name("reciprocal_beta_extension_results.json")
    target.write_text(json.dumps(report, indent=2) + "\n")
    print("All beta >= 1000000 endpoint certificate: PASS")
    print("Exact affine identity and limit rows:", rows)
    print("Limit maximum row:", a, fuel, str(Uf), str(v))
    print("Limit maximum outward:", fixed.decimal_enclosure(value))
    print("Limit rows failing old b:", len(failures_old))
    print("All-beta bound: b=131/100000000, theta=1/2, K16, Wmax80, prepared <=6/100000000")
    print("Original b=13/10000000 restored for EVERY beta>=1020000 by interpolation")
    print("At beta4500000, interpolation bounds residual by", str(beta_4m5_mixture))


if __name__ == "__main__":
    main()
