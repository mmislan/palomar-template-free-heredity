#!/usr/bin/env python3
"""One fixed beta1m full branching SiteCert; exact rational arithmetic only.

Run with Python's standard library. No solver, simulation, parameter search,
compiler, desktop source read, or accepted-packet modification is performed.
The literal upstream siteOp is transcribed below. Output is deterministic.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import comb, prod
from pathlib import Path
import hashlib
import json

N, BETA, ALPHA, EPSILON = 2048, 1000000, 800, 6
K, THETA, TARGET_B, TARGET_WMAX = 16, F(1, 2), F(13, 10**7), F(80)
CORRECTED_B = F(131, 10**8)
V_MAX, U_MAX = F(1843200), F(2)
TAIL_D, FALSE_TAIL_FACTOR = F(1860480), F(1000070, 1000000)
PREPARED_TARGET = F(6, 10**8)


def hh(a):
    assert isinstance(a, int) and a >= 0
    return F(1, prod(range(a + 1, a + 6)))


CC = TAIL_D * hh(12) / F(3, 4)**12


@lru_cache(None)
def A(a):
    return CC * F(3, 4)**a if a <= 12 else TAIL_D * hh(a)


@lru_cache(None)
def W(a, fuel):
    if fuel:
        return A(a)
    if a == 0:
        return CC * (1 - F(1, 2000000))
    return A(a) * (1 + F(min(6 * a, 70), 1000000))


def ehh_closed(a):
    # Literal formula in the task, with powers of two represented as integers.
    remainder = sum(
        (F((-1)**j * comb(4, j), (2**(a + j + 1)) * (a + j + 1))
         for j in range(5)), F(0)
    )
    return 32 * hh(a) - F(32, 24) * remainder


def bin_direct(g, a):
    # Used only for independent spot verification, not the 2049-row evaluation.
    return sum((comb(a, k) * g(k) for k in range(a + 1)), F(0)) / 2**a


PREFIX_A = tuple(A(k) - TAIL_D * hh(k) for k in range(13))
PREFIX_FALSE = tuple(W(k, False) - FALSE_TAIL_FACTOR * A(k)
                     for k in range(12))


@lru_cache(None)
def bin_weights(a):
    et = TAIL_D * ehh_closed(a) + sum(
        (comb(a, k) * PREFIX_A[k] for k in range(min(a, 12) + 1)), F(0)
    ) / 2**a
    ef = FALSE_TAIL_FACTOR * et + sum(
        (comb(a, k) * PREFIX_FALSE[k] for k in range(min(a, 11) + 1)), F(0)
    ) / 2**a
    return et, ef


def siteop_terms(a, fuel, Hf, Uf):
    """Literal upstream siteOp, including natural subtraction at zero."""
    u = F(a, N)
    down = max(a - 1, 0)
    et, ef = bin_weights(a)
    if fuel:
        return {
            "seed": EPSILON * (1-u) * (W(a+1, True)-W(a, True)),
            "active_birth": ALPHA * a * (1-u) * (W(a+1, False)-W(a, True)),
            "active_death": F(ALPHA, 2) * a * (W(down, False)-W(a, True)),
            "passive_death": a * (W(down, True)-W(a, True)),
            "fuel_loss": (BETA * (1+u)+Hf) * (W(a, False)-W(a, True)),
            "basal_daughters": et + ef - 2*W(a, True),
            "triggered_daughters": (u+Uf) * (2*ef-W(a, True)),
        }
    return {
        "seed": EPSILON * (1-u) * (W(a+1, False)-W(a, False)),
        "passive_death": a * (W(down, False)-W(a, False)),
        "recharge": BETA * (W(a, True)-W(a, False)),
        "basal_daughters": 2*ef - 2*W(a, False),
    }


def decimal_enclosure(x, digits=18):
    """Outward decimal strings computed using integer division, never float."""
    scale = 10**digits
    lo = (x.numerator * scale) // x.denominator
    hi = -((-x.numerator * scale) // x.denominator)
    def fmt(n):
        sign = "-" if n < 0 else ""
        n = abs(n)
        return f"{sign}{n // scale}.{n % scale:0{digits}d}"
    return [fmt(lo), fmt(hi)]


def ratio_record(x):
    return {"fraction": str(x), "decimal_outward": decimal_enclosure(x)}


def row_record(a, fuel, Uf, v, value):
    Hf = BETA * Uf + v
    return {
        "a": a, "fuel": fuel, "Uf": str(Uf), "v": str(v), "Hf": str(Hf),
        "siteOp_plus_half_W": ratio_record(value),
        "slack_to_target_b": ratio_record(TARGET_B-value),
        "slack_to_corrected_b": ratio_record(CORRECTED_B-value),
        "W": ratio_record(W(a, fuel)),
        "operator_terms": {k: ratio_record(x) for k, x in siteop_terms(a, fuel, Hf, Uf).items()},
    }


def main():
    # Independent, direct full-binomial comparisons before use of the formula.
    moment_points = list(range(65)) + [127, 128, 255, 256, 511, 512, 1024, 2048]
    for a in moment_points:
        assert ehh_closed(a) == bin_direct(hh, a), ("hh formula", a)
    assert PREFIX_A[12] == 0
    weight_points = [0, 1, 11, 12, 13, 15, 16, 127, 512, 2048]
    for a in weight_points:
        et, ef = bin_weights(a)
        assert et == bin_direct(lambda k: W(k, True), a), ("true expectation", a)
        assert ef == bin_direct(lambda k: W(k, False), a), ("false expectation", a)

    # Infinite-domain obligations reduce analytically to these finite seams:
    # A is geometric up to 12, then hh(a+1)/hh(a)=(a+1)/(a+6)<1.
    # B=W(false) has a small increasing multiplier until 12, constant afterward.
    assert A(12) == TAIL_D * hh(12)
    assert CC > 0 and CC <= TARGET_WMAX
    for a in range(13):
        for fuel in (False, True):
            assert 0 < W(a+1, fuel) < W(a, fuel)
    assert W(0, False) < W(0, True)
    barrier_min = min((W(a, fuel), a, fuel) for a in range(K) for fuel in (False, True))
    assert barrier_min == (F(1), 15, True)
    prepared_max = W(512, False)
    assert W(512, True) < prepared_max <= PREPARED_TARGET

    corner_maxima, global_max = [], None
    violation_count, rows, violation_rows = 0, 0, []
    # Enumerate four affine corners for both fuels, even though false ignores Hf,Uf.
    for fuel in (False, True):
        for Uf in (F(0), U_MAX):
            for v in (F(0), V_MAX):
                best = None
                for a in range(N + 1):
                    Hf = BETA * Uf + v
                    value = sum(siteop_terms(a, fuel, Hf, Uf).values(), F(0)) + THETA*W(a, fuel)
                    rows += 1
                    violation_count += int(value > TARGET_B)
                    if value > TARGET_B:
                        violation_rows.append({"a": a, "fuel": fuel, "Uf": str(Uf), "v": str(v),
                                               "residual_decimal_outward": decimal_enclosure(value)})
                    assert value < CORRECTED_B, ("Corrected b fails", a, fuel, Uf, v)
                    candidate = (value, a, fuel, Uf, v)
                    if best is None or value > best[0]:
                        best = candidate
                    if global_max is None or value > global_max[0]:
                        global_max = candidate
                value, a, R, U, V = best
                corner_maxima.append(row_record(a, R, U, V, value))

    # Independently compare the complete sums at every maximizing count.
    maximizing_counts = sorted({r["a"] for r in corner_maxima})
    for a in maximizing_counts:
        et, ef = bin_weights(a)
        assert et == bin_direct(lambda k: W(k, True), a)
        assert ef == bin_direct(lambda k: W(k, False), a)

    value, a, fuel, Uf, v = global_max
    decisive_rows = []
    for count in [0, 1, 11, 12, 13, 15, 16, 512, 2048]:
        candidates = []
        for R in (False, True):
            for U in (F(0), U_MAX):
                for V in (F(0), V_MAX):
                    val = sum(siteop_terms(count, R, BETA*U+V, U).values(), F(0)) + THETA*W(count, R)
                    candidates.append((val, count, R, U, V))
        val, count, R, U, V = max(candidates)
        decisive_rows.append(row_record(count, R, U, V, val))
    report = {
        "status_requested_b": "PASS" if violation_count == 0 else "FAIL",
        "status_corrected_b": "PASS",
        "corrected_b": str(CORRECTED_B),
        "scope": "Exact numerical/analytical SiteCert witness; not a Lean-compiled theorem or full mission",
        "parameters": {"beta": BETA, "M": 4, "c": 3, "N": N, "alpha": ALPHA, "epsilon": EPSILON,
                       "K": K, "theta": str(THETA), "b": str(TARGET_B), "Wmax": str(TARGET_WMAX)},
        "foreign_rectangle": {"Uf_max": str(U_MAX), "v_max": str(V_MAX)},
        "CC_and_global_Wmax": ratio_record(CC),
        "barrier_minimum": {"a": 15, "fuel": True, **ratio_record(barrier_min[0])},
        "prepared_global_maximum": {"a": 512, "fuel": False, **ratio_record(prepared_max)},
        "prepared_slack": ratio_record(PREPARED_TARGET-prepared_max),
        "checked_endpoint_rows": rows,
        "endpoint_rows_above_target_b": violation_count,
        "violating_rows_at_requested_b": violation_rows,
        "minimal_necessary_b_at_fixed_theta": row_record(a, fuel, Uf, v, value),
        "corner_maxima": corner_maxima,
        "diagnostic_seam_rows": decisive_rows,
        "direct_hh_formula_checks": moment_points,
        "direct_weight_sum_checks": sorted(set(weight_points + maximizing_counts)),
        "source_files": {},
    }
    source_root = Path(__file__).resolve().parent.parent
    for name in ("ORIGINAL_G60_SOURCE_PROOF_EXCERPTS_20261013.md", "EXACT_SERVICE_AND_BRANCHING_SOURCE_20261013.md"):
        report["source_files"][name] = hashlib.sha256((source_root/name).read_bytes()).hexdigest()
    target = Path(__file__).with_name("fixed_beta1m_branching_results.json")
    target.write_text(json.dumps(report, indent=2) + "\n")
    print("Requested b status:", report["status_requested_b"])
    print("Corrected b status:", report["status_corrected_b"], "; b =", str(CORRECTED_B))
    print("Exact endpoint rows:", rows, "; violations:", violation_count)
    print("Global W maximum:", str(CC), decimal_enclosure(CC))
    print("Barrier minimum:", barrier_min)
    print("Prepared maximum:", str(prepared_max), decimal_enclosure(prepared_max))
    print("Minimum b at theta=1/2 attained at:", (a, fuel, str(Uf), str(v)))
    print("b minimum outward:", decimal_enclosure(value))
    print("Target b slack outward:", decimal_enclosure(TARGET_B-value))
    print("Corrected b slack outward:", decimal_enclosure(CORRECTED_B-value))
    for row in corner_maxima:
        print("Corner maximum:", row["fuel"], row["Uf"], row["v"], row["a"], row["siteOp_plus_half_W"]["decimal_outward"])
    print("Full exact fractions saved to", target.name)
    assert value <= CORRECTED_B


if __name__ == "__main__":
    main()
