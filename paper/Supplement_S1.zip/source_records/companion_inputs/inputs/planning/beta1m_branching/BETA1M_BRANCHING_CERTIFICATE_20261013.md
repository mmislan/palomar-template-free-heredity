# Full branching floor16 certificate and a reciprocal-beta family

## Result and scope

The specified beta=1,000,000 candidate fails the exact requested drift source
b0=13/10^7, but only narrowly. It satisfies every other SiteCert obligation.
Its smallest possible b at theta=1/2 is the exact rational maximum b* recorded
in `fixed_beta1m_branching_results.json`, attained at

- a=868, fuel=true;
- Uf=2, v=Hf-beta*Uf=1,843,200, hence Hf=3,843,200;
- 0.000001307564869391 < b* < 0.000001307564869392.

The SAME FIXED CANDIDATE, without any shape or scale change, satisfies

SiteCert p_beta1m 16 W (1/2) (131/10^8) 80,

and W(a,R)<=6/10^8 for every a>=512. The exact below-16 barrier minimum is 1,
at a=15,fuel=true. All 16,392 count/fuel/foreign-corner rows were compared as
rational numbers. The corrected source b'=131/10^8 is only 1/130, or about
0.76924 percent, above the requested b0. The actual minimal increase is less.

There is a structural extension, proved below without a rate sweep. The
reciprocal-beta family defined here satisfies the same certificate with b'
for EVERY real beta>=1,000,000. It satisfies the original b0 for EVERY
beta>=1,020,000. In particular beta=4,500,000 retains all the original local
floor/acquisition constants theta=1/2, b0, Wmax80 and prepared 6/10^8.

This is an exact mathematical and finite-arithmetic certificate for the
literal full branching operator. No compiler or theorem prover was run, and
no claim of a compiled Lean theorem is made. It supplies local floor and
acquisition inputs and, through the source SiteCert.toRet theorem, a retention
certificate. It does not establish fixed-grid service, G60, the changed-rate
resource/feed ledger, or a full mission theorem. The accepted beta8m mission
and accepted beta1m recovery-only packet remain untouched.

## 1 Literal candidate and unchanged parameters

Throughout, M=4,c=3,N=2048,alpha=800,epsilon=6, and K=16. Let

hh(a)=1/[(a+1)(a+2)(a+3)(a+4)(a+5)], D=1860480,

C=D*hh(12)/(3/4)^12=1275068416/16120377.

Define A(a)=C*(3/4)^a for 0<=a<=12 and A(a)=D*hh(a) for a>=13.
At beta=1,000,000 define

W(a,true)=A(a),
W(0,false)=C*(1-1/2000000),
W(a,false)=A(a)*(1+min(6a,70)/1000000) for a>=1.

Both fuel states are present, including the deliberately negative fuel gap
at a=0. No zero boundary is imposed at 16, and there is no recovery/Ready
killing in this operator. At a=0 the predecessor is max(a-1,0)=0. At a=N,
birth coefficients vanish, although W(N+1,R) is still well defined.

## 2 Closed binomial formula, proved independently before use

The beta integral is

hh(k)=(1/24) integral_0^1 t^k(1-t)^4 dt.

For B~Bin(a,1/2), substitute s=(1+t)/2 to obtain

E[hh(B)]
 =(1/24) integral_0^1 ((1+t)/2)^a(1-t)^4 dt
 =(32/24) integral_(1/2)^1 s^a(1-s)^4 ds
 =32hh(a)-(32/24) sum_(j=0)^4
       (-1)^j binom(4,j) 2^(-a-j-1)/(a+j+1).

This holds for every integer a>=0. It is not an asymptotic approximation.
The checker independently compares it with complete rational binomial sums
for a=0..64 and a=127,128,255,256,511,512,1024,2048.

Write eA(a)=binE(A)(a), eF(a)=binE(W(false))(a), and t=1+70/10^6.
The exact short-correction expressions are

eA(a)=D*E[hh(B)]
 +2^(-a) sum_(k=0)^min(a,12) binom(a,k)[A(k)-D*hh(k)],

eF(a)=t*eA(a)
 +2^(-a) sum_(k=0)^min(a,11) binom(a,k)[W(k,false)-t*A(k)].

The k=12 term in the first correction is zero. The second correction stops
at 11 because min(6a,70) saturates at 12. Thus computing a row uses five
closed-form moment terms and at most 25 prefix terms, not a binomial sum
over all daughters. Complete independent binomial sums additionally verify
both expectations at the splices, representative counts, the upper endpoint,
and every maximizing count reported below.

## 3 All-natural weight, barrier and prepared obligations

A(a+1)/A(a)=3/4 for 0<=a<=11, and equals(a+1)/(a+6) for a>=12,
including the splice. Both ratios are below 1. All values are positive.

The false branch also decreases strictly. Its ratio at 0->1 is
6000036/7999996<1. For1<=a<=11, if its multiplier numerator is m>=10^6
and the next increment is delta<=6, its ratio is3(m+delta)/(4m)<1.
For a>=12 its multiplier is constant and its ratio is(a+1)/(a+6)<1.

Consequently the global maximum over ALL natural counts and both fuels is

max W=C=1275068416/16120377<80,
80-C=14561744/16120377>0.

This is an infinite-domain proof of SiteCert.le_max, not an assertion based
only on the drift rows a<=N. Positivity gives SiteCert.nonneg likewise.

A(15)=1. On1<=a<16, W(a,false)>=A(a)>=1. At0,
W(0,false)=19922934038528/251880890625>1. Thus SiteCert.ge_one holds for
every a<16, and its exact minimum is 1 at a=15,true.

For every a>=512, monotonicity and the positive false-branch multiplier give

W(a,R)<=W(512,false)=1700119/33101820056250,

0.000000051360287655 < W(512,false) < 0.000000051360287656 <6/10^8.

The exact prepared-bound margin is
2287921627/264814560450000000>0.

## 4 Every admissible foreign load and the literal branching operator

The source SiteCert allows

0<=Uf<=c-1=2,
beta*Uf<=Hf<=beta*Uf+alpha*N*(9/16)*(c-1).

Put v=Hf-beta*Uf. This is exactly the rectangle
0<=Uf<=2,0<=v<=1843200. For fixed a and fuel, siteOp+theta*W is affine
in Uf and v. Its value is a convex combination of the four corner values,
using weights formed from Uf/2 and v/1843200. Hence checking all four
corners proves the required bound for EVERY admissible foreign-load pair.
No monotonicity of W across fuels is presumed at a=0.

The checker transcribes the literal source siteOp term by term. For true fuel
it retains seed, active birth, active death, passive death, fuel loss,
eA+eF-2W(true), and (a/N+Uf)*(2eF-W(true)). For false fuel it retains seed,
passive death, recharge, and 2eF-2W(false). These include both daughters and
both fuel branches. The recovery-only killed generator is not used.

It checks every a=0..2048, both fuels, and the four corners:2049*2*4=16,392
exact row comparisons. False rows do not depend on the foreign corner;
they are nevertheless checked at all four corners for transparency.

## 5 Decisive finite results and the minimal b

The exact maximum of R=siteOp+(1/2)W at each corner is enclosed as follows.
Each displayed interval is outward-rounded by integer division at 18 decimal
places. No floating-point calculation enters any comparison or assertion.

| Fuel | Uf | v | Maximizing a | Exact maximum lies strictly between |
|---|---:|---:|---:|---|
| false | either | either |2048| -0.000000000127913281 and -0.000000000127913280 |
| true |0|0|1112|0.000000486890320061 and0.000000486890320062|
| true |0|1843200|1032|0.000000655098218333 and0.000000655098218334|
| true |2|0|948|0.000000921283342091 and0.000000921283342092|
| true |2|1843200|868|0.000001307564869391 and0.000001307564869392|

The requested b0 fails exactly 42 endpoint rows: a=849..890 inclusive, all
with fuel=true,Uf=2,v=1843200. All other checked endpoint rows pass b0.
The failure is in the high-count tail, not an absent-count, floor or splice
problem. The full list of failing rows is recorded in the result JSON.

Let eA=eA(868),eF=eF(868). A compact exact specification of the minimal b is

b*=1671370317/3284797732744000
    +eA+(1497/256)*eF-(2009/512)*(2584/696234302049).

Here eA,eF have the exact finite expressions in section 2. The JSON also
records b* as a single reduced rational fraction, all seven operator terms
at the decisive row, and the exact slack to each proposed bound. The
finite maximum proves b* is necessary and sufficient for THIS FIXED W and
theta=1/2, not a lower bound over all possible architectures.

The counterexample exceeds b0 by a number strictly between
0.000000007564869391 and0.000000007564869392.
The corrected b'=131/10^8 exceeds b* by a number strictly between
0.000000002435130608 and0.000000002435130609.

A separate direct-binomial reconstruction, without importing either checker
or using the closed moment formula, reproduced the decisive beta1m row and
its two exact comparisons b0<b*<b'. It also reproduced the limiting a=979
row and its strict upper bound 8/10^7. These are independent spot checks,
not a claim of a separate complete theorem-prover audit.

Thus the correction is rigorously sufficient without changing the candidate.

## 6 A continuum of beta values from two algebraic endpoints

Let x=1/beta and define

g(0)=-A(0)/2,
g(a)=A(a)*min(6a,70) for a>=1,
W_beta(a,true)=A(a), W_beta(a,false)=A(a)+x*g(a).

This is exactly the fixed candidate at beta=1,000,000. Write
u=a/N,U=Uf, A=A(a), Aplus=A(a+1), Aminus=A(max(a-1,0)),
gplus=g(a+1),gminus=g(max(a-1,0)),B=binE(A)(a),G=binE(g)(a).

After substituting Hf=beta*U+v, the fueled residual is Tinf+x*T1, where

Tinf=(epsilon+alpha*a)*(1-u)*(Aplus-A)
 +a*(1+alpha/2)*(Aminus-A)
 +(1+u+U)*g(a)+2B-2A+(u+U)*(2B-A)+theta*A,

T1=alpha*a*(1-u)*gplus+(alpha*a/2)*gminus
 +v*g(a)+[1+2*(u+U)]*G.

The unfueled residual is Finf+x*F1, where

Finf=epsilon*(1-u)*(Aplus-A)+a*(Aminus-A)
 -g(a)+2B-2A+theta*A,

F1=epsilon*(1-u)*(gplus-g(a))+a*(gminus-g(a))
 +2G+(theta-2)*g(a).

Crucially the fueled loss term becomes(1+u+U)*g(a)+x*v*g(a), and recharge
becomes-g(a). Those terms survive as x tends to zero. The endpoint is the
continuous extension of these residual formulas; simply setting equal fuel
weights in the original operator would incorrectly erase these constants.

The extension checker verifies the affine identity against the literal
beta1m residual in all 16,392 rows, then verifies all 16,392 limiting rows.
An independent analytical calculation also derives the same formulas.

The limiting global maximum is at a=979,true,Uf=2; v is irrelevant. It is
strictly between0.000000798423197269 and0.000000798423197270, hence below
8/10^7. Limiting false rows have maximum at 2048, below zero. Full rational
binomial sums independently check B and G at all limiting maximizing counts.

For beta>=1,000,000 put lambda=1,000,000/beta in(0,1]. Every residual obeys

R_beta=(1-lambda)*R_infinity+lambda*R_1m
 <=(1-lambda)*(8/10^7)+lambda*(131/10^8)
 =8/10^7+lambda*(51/10^8).

Therefore b'=131/10^8 works for every beta>=1,000,000. This is one affine
endpoint proof, not a numerical beta sweep. The false weights themselves
are convex combinations of A and W_1m(false), so the all-natural positivity,
Wmax80, below-16 barrier and prepared 6/10^8 bounds also extend immediately.

When beta>=1,020,000, lambda<=50/51, and the displayed envelope is<=13/10^7.
This restores the original b0 throughout that interval. At the parent's
prospective beta=4,500,000 value, lambda=2/9 and the residual bound is

137/150000000 <13/10^7.

This last statement is a direct interpolation consequence; no additional
candidate architecture or numerical rate check is needed.

## 7 What transfers to source composition, and what does not

At beta1m the new local floor/acquisition inputs are theta=1/2,b',Wmax80,
K16 and prepared 6/10^8. Thus the source acquisition upper input remains
M*Wmax=320 and the old30-time-unit decay exponent remains 15. The original
eight prepared-founder contribution is still bounded by 8*(6/10^8).
The source SiteCert.toRet implication is applicable because theta>=0.
Any retention term using b must use b' at beta1m; b0 is not certified there
by this candidate.

For every beta>=1.02m, including the proposed beta4.5m point, the same NEW
family restores b0 as well. This is a reusable local analytical input. It
does not alter the W0 or certificate in the immutable accepted beta8m paper.

The floor16 service inequalities and their source credit/quota tilt remain
separate. A floor/acquisition SiteCert does not establish a service rate,
does not upgrade the beta1m recovery-only theorem to a full G60 theorem,
and does not prove stock/feed or mission composition. No floor128 statement
is made. Those distinctions are essential because the full branching
operator here includes physical daughter gains and low-count barriers that
the accepted recovery-only killed potential deliberately does not have.

## 8 Reproduction, finite-proof trust and preservation

Run these two standard-library scripts in this additive directory:

1. `python fixed_beta1m_branching_check.py`
2. `PYTHONDONTWRITEBYTECODE=1 python reciprocal_beta_extension_check.py`

The first reports FAIL for the originally requested b0 and PASS for b',
then exits successfully after every corrected-bound assertion passes.
The second reports the all-beta endpoint certificate and the b0 restoration.
The result JSON files contain exact reduced fractions, outward decimal
enclosures, maxima, diagnostic splice/end rows, and source-file SHA-256 pins.
The stdout files are convenient compact receipts. `SHA256SUMS.txt` pins the
packet. All proof obligations beyond the finite interval are justified
analytically above; arbitrary foreign loads follow by convexity.

The source definitions used are the parent's two immutable cloud excerpts:
`ORIGINAL_G60_SOURCE_PROOF_EXCERPTS_20261013.md` and
`EXACT_SERVICE_AND_BRANCHING_SOURCE_20261013.md`. The latter identifies
Defs.SiteCert, the literal siteOp, RetCert and SiteCert.toRet, and the
separate service and mission gates. Their recorded upstream source excerpt
digest is 6fae9db69186e9d3eeda259666428be6da65dedb8f00b0c7ca7267348616bb6b.
No desktop source, Git operation, simulator, optimizer, compiler or public
action was used. Every deliverable is additive under beta1m_branching.
