# General credit tilt and an additive beta4m mission candidate

## Result and status

**PROVED analytical candidate, pending independent review; no canonical edit:** changing the service proof's exponential credit tilt, while changing no physical channel or mission event, certifies the unchanged mission at constant beta=4,000,000. Both old species start at least512 at each of four sites; candidate counts and fuels remain arbitrary.

The candidate retains all600 fixed0.1 blocks,500 credits per required site/species/block, candidate establishment at30, floors16, post30 initiating-division requirements, ten actual division/Ready512 renewals by55.5, and all3,000,000 service credits by60. Its accepted-feed cap is800,000,000 rather than900,000,000. A source-compatible failure allowance is the same0.005464632462485986; keeping the newly computed smaller G60 allowance improves the displayed bound to0.004517975690072193.

This is an intermediate improvement from the proof architecture's credit tilt. It does not settle beta1m; the separate count-dependent occupation lemma is the substantive route beyond the pointwise-floor barrier. The canonical beta4.5m packet is unchanged.

## 1. General ordinary-credit service lemma

Let Q be the selected coordinate's ordinary credits since its actual block start. Set

Y=z^Q*(rho if fueled else1), 0<z<=rho<=1.

All ordinary jobs remain active. Ignoring division-coupled credits makes the proved event stronger than the source quota event.

The physical-channel argument in `OCCUPATION_SERVICE_LEMMA_20261013.md`, Section1, gives for Hs=alpha*c*N*(9/16)+beta*c+8:

L Y / z^Q <= -beta*(1-rho) when fuel is off,
L Y / z^Q <= beta*(a/N)*(z-rho)+Hs*(1-rho) when fuel is on.

Seed/passive events preserve Y. Every touching division, including incoming victim replacement, is bounded by its actual fuel change and the total touching intensity at most8. Other-site jobs and chemistry do not affect the selected potential except through those already included division marks. Neither independent sisters nor a fixed donor state is used.

On the original required-floor-live domain a>=K, suppose

theta<=beta*(1-rho),
beta*(K/N)*(z-rho)+Hs*(1-rho)+theta*rho<=0.        (S)

Because z-rho<=0, the count coefficient can be replaced by K/N in the upper bound. Killing on the original floor exit only lowers the nonnegative potential. Thus the killed physical generator satisfies

L^D Y<=-theta Y.

The finite-state marked semigroup or its elementary exponential supermartingale gives, uniformly from every live state,

P(D>w,Q_w<m) <= z^(-m)*rho^(-1)*exp(-theta*w).    (T)

As always, this is an intersection probability. At every actual exposed block start it holds conditional on the complete past. Multiplying by the successful-prefix indicator and averaging is valid; conditioning the physical law on a future good event is not needed.

The source uses z=1/2 and can additionally use its division-coupled selected credit, yielding beta+1. Formula(S) uses only beta and is proved directly for the full physical law. It is therefore not an unsupported invocation of the fixed-half-tilt source theorem.

## 2. One exact beta4m witness

Take beta=4,000,000 and

z=3/4, rho=79967/80000, theta=1650, K=16.

Then Hs=14,764,808, cf3Rate=93,515,864 and theta=beta*(1-rho). The fueled residual in(S) is exactly

-598067/10000=-59.8067.

For at most12 required coordinate quotas in a block of length0.1,

S_block <= (12/rho)*(4/3)^500*exp(-165)
         < 1948303823/250000000000000000
         < 10^(-8).

The checker replaces exp(165) in the denominator by its positive200-term rational Taylor lower polynomial. No numerical exponential enters the asserted comparison.

## 3. Branching, acquisition and the complete fixed-grid event

The already-proved reciprocal-beta full branching family gives, at beta4m,

siteOp+(1/2)W
 <= 8/10^7+(1/4)*(131/10^8-8/10^7)
 =371/400000000 < b0=13/10^7.

Its other SiteCert properties are unchanged: nonnegative weights on all natural counts, Wmax80, the below16 barrier, and W<=6/10^8 at counts>=512. This uses the proved family, not the old beta8m W0 certificate transplanted without proof. The parameter is valid and the displayed uniformization rate is positive.

The original generic `mission_lower` cannot literally be invoked with z=3/4 because its service lemma and `blockErr` hard-code the half-credit tilt. Instead repeat the same finite-block induction with(T) replacing that one local service bound. All retention, candidate, initiating-division and prepared-founder terms are unaffected; their proofs depend on the full branching certificate and the unchanged marked physical law. This is a new analytical service-lemma instantiation, not a claim that the original Lean statement has changed.

Concretely, for an exposed live block start:

- the source guard/retention contribution remains nreq*(4b0)*0.1;
- the pre-acquisition auxiliary candidate contribution remains4b0*0.1;
- the new missed-service contribution is at most10^(-8), uniformly in that start;
- the post-acquisition auxiliary source term is zero, and its separate division-deficit contribution remains5184*exp(-25).

Thus both pre and post block guard allocations equal(6/5)b0. Multiply the new service estimate by each exposed-prefix indicator and apply the tower property, exactly as with the source service estimate. No successful-prefix distribution is assumed prepared. This yields the complete source G60 event with

P(G60^c)
 <=48/10^8+320/2900000
   +600*((6/5)*b0+10^(-8))+5184/10^10
 =9545923/9062500000
 <0.001053343227587 <1/500.

Every fixed-grid quota remains individual, at its source site and species. There are2400 such quotas before30 and3600 afterward. Ordinary credits alone furnish the same3,000,000 source credits. This proof does not replace per-block requirements by a total quota.

## 4. Ready renewals and full physical stopping histories

The already-proved uniform recovery theorem applies at every finite beta>=1m, hence at4m:

P(H512>1/2,D16>1/2 | admissible physical start history)
 <=8622092430140/10^18 <1/100000.

The source successful-prefix construction uses11 recoveries and10 first-actual-division waits. Each wait has tail at mostexp(-8) for deadline2 because the four basal clocks remain active. All reset marks are completed before a new local recovery is defined. The terminal physical fuel is retained.

The same source event inclusion and conditional tower argument give

P(full mission failure)
 <= P(G60^c)+11/100000+10exp(-8)+3exp(-20).

The sequence finishes by30+11/2+20=55.5, leaving every selected recovery within the source60-time floor interval. Service still finishes on its original grid at60. Recovery intervals do not restart service ledgers or replenish stocks, and G60 is not used to condition the future physical law.

Using the new G60 fraction and exact rational Taylor exponential bounds gives

P(full mission failure) <=4517975690072193/10^18
                        =0.004517975690072193.

Keeping instead the source-compatible G60 allowance1/500 gives the familiar upper bound0.005464632462485986. Both are valid candidate inequalities; neither is a new formal compiler receipt or canonical acceptance.

## 5. The800million accepted-feed certificate

At beta4m the literal combined-consuming envelope is

Cstar=4beta+2457603=18,457,603.

The endpoint-regime requirement beta+1>=819200 holds. Apply the existing SR3 bound, which separately includes basal and triggered victim-fuel losses:

P(A_60>B) <= exp[s*(4-F0)+240*kappa(theta,s)-theta*B],
kappa=max{beta*(exp(theta-s)-1),
          (Cstar+1+3exp(s))*(exp(s)-1)}.

Choose theta=1/10000, s=400/22457607 and B=800,000,000. For0<=x<1, exp(x)<=1/(1-x). Hence the two entries are at most

k1=beta*(theta-s)/(1-theta+s)=73830428000000/224557612393,
k2=(Cstar+1+3/(1-s))*s/(1-s).

Exact cross multiplication gives k1>=k2. Paying arbitrary initial fuel by4s gives the upper exponent

4s+240k1-800000000*theta
 =-5508991479342664251200/5043026607980323551
 <-1092 < -20.

The unchanged seed and division tails remain respectively belowexp(-20) at5000 seed entries and belowexp(-20) at1200 actual marked divisions. These are dependent accepted-event counts; no independence claim is made.

The source gross conservation identities, including complete terminal jumps, give the following cumulative ceilings on the common resource-good event:

- accepted feed800,000,000;
- consumed fuel800,000,004, including at most4 initially occupied sites;
- accepted seeds5000;
- catalytic births plus seeds800,005,004;
- actual marked divisions1200;
- discarded/restored catalyst slots7,372,800;
- discarded victim fuel at most1200, already included in gross fuel supply.

The source identical-clock finite-stock coupling applies up to the first attempted excess and subtracts the three global resource tails once. The triggered split's fuel loss is1 plus the victim's old fuel, not merely1. No resource is replenished at recovery boundaries.

## 6. Exact obstruction for the pointwise-floor proof architecture at beta1m

This is an obstruction to the count-independent service certificate, not to actual service.

Let r=beta*K/N, delta=1-rho and H=Hs. Any positive theta satisfying(S) obeys

theta*(1-delta)+(H+r)*delta <= r*(1-z),
delta>=theta/beta.

First theta<=r: otherwise replacing theta by r on the nonnegative1-delta side gives a left-minus-right at least r*z+H*delta>0, a contradiction. Therefore H+r-theta>=H. Substitution of delta>=theta/beta into

theta+(H+r-theta)*delta<=r*(1-z)

gives

theta <= [beta*r/(beta+H)]*(1-z).

At beta1m,K16,H=5,764,808, the bracket is exactly

976562500/845601 <1155 <5000.

For a0.1 block it is consequently below500 after multiplying by time. Since log(z)<=-(1-z),

theta*0.1+500log(z)
 <=[(976562500/845601)*0.1-500]*(1-z) <0

for z<1. Thus rho^(-1) z^(-500) exp(-theta*0.1)>1: optimizing the credit tilt cannot make this particular worst-floor architecture even nontrivial at beta1m. Using the selected division-coupled +1 changes this constant negligibly and cannot bridge the gap.

The occupation-dependent potential in the separate frozen note escapes this obstruction by retaining min(a,512) in the decay. It does not replace16 by a higher permanently retained floor.

## 7. Reproduction and trust boundary

Run `python general_credit_tilt_certificate.py`. Its outputs are `general_credit_tilt_results.json` and the separately captured stdout. The script checks every new numerical claim as a rational inequality and verifies the unchanged source-file hashes. It imports no author checker and conducts no parameter sweep, simulation, solver, compiler, Git operation, desktop access or publication.

The full branching and uniform recovery families are already-proved analytical dependencies, not freshly re-proved finite tables in this small checker. The new generator/channel argument and repeated block induction above are essential to the candidate mission; the arithmetic alone is not a theorem. This packet is additive and does not modify the accepted beta4.5m or original beta8m artifacts.
