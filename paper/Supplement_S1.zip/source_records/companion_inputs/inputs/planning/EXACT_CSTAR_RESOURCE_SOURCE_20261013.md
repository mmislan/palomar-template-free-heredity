Verified in [SERVICE_RESOURCE_PROOF.md:58](../../../PROOF_NAVIGATION.md). Its literal definition is:

```text
At an occupied site the combined consuming-event intensity is

h_i = beta + sum_j [
  alpha*N*(3*u_ij/2-u_ij^2) + (beta+1)*u_ij
].

The +1 inside beta+1 includes the division-coupled job,
not merely ordinary jobs. For A0=alpha*N>0 and b=beta+1 set

g_star = A0/2+b                  if b >= A0/2,
         (3*A0/2+b)^2/(4*A0)     if b < A0/2;
C_star = beta+c*g_star.

For alpha=0 set g_star=b.
```

The accompanying source explanation is:

> This is the exact continuous-envelope maximum of the combined concave quadratic on [0,1], rather than summing incompatible separate maxima. For integer counts it is an upper bound; a sharper exact lattice maximum uses the nearest admissible integers to N*(3*A0/2+b)/(2*A0), clipped at N. In the witness the continuous maximum is achieved by the admissible integer a=N, so C_star is exact:

```text
alpha=800, N=2048, beta=8,000,000, c=3,
b=8,000,001 >= A0/2=819,200,
C_star=8,000,000+3*(819,200+8,000,001)=34,457,603.
```

Specializing this **existing definition** to the retained alpha/N/c gives

\[
C_\star=\beta+3(819200+\beta+1)=4\beta+2457603.
\]

The literal endpoint-regime condition is **\(\beta+1\ge819200\)**, equivalently \(\beta\ge819199\). Your stated \(\beta\ge819200\) is sufficient.

The source keeps victim losses separately:

```text
Consuming-event intensity is <=C_star*F.
Basal victim-fuel loss intensity is exactly F.

Trigger victim-fuel loss intensity is
W_t(x)=sum_i R_i*sum_j u_ij*(F-R_i)/(M-1) <= c*F.
```

Accordingly, LemmaSR3 uses:

```text
theta>=s>=0,

kappa(theta,s)=max{
  beta*(exp(theta-s)-1),
  (C_star+1+c*exp(s))*(exp(s)-1)
}.

P_x(A_T>B)
 <= exp(s*(M-F0)+M*T*kappa(theta,s)-theta*B).
```

Recorded source SHA-256: `dcf8181bcfcb402a5ca401a8333d3799766e1b464de8b281fe7658493329c5ac`.

No proposed900million feed-cap evaluation, execution, or source edit was performed.
