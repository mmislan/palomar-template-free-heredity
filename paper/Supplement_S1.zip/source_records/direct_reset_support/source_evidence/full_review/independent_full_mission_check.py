#!/usr/bin/env python3
"""Independent analytical-audit arithmetic. Standard library only; no author code import.
All inequality decisions are exact. This does not compile formal theorems.
"""
from fractions import Fraction as R
from pathlib import Path
from math import comb, factorial, prod
import hashlib, json

OUT=Path(__file__).resolve().parent
SRC=Path('ARCHIVE_PATH_003')
AUTHOR=OUT.parent/'seed_withdrawal'
PROOF=AUTHOR/'SEED_WITHDRAWAL_HEREDITY_COROLLARY_20261013.md'
PIN='78d24151b403781f272fc1d0995acf5629878565d9b1f843bf5e169aa31249a9'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(PROOF)==PIN
assert sha(OUT/'REVIEWED_SOURCE_SNAPSHOT_20261013.md')==PIN
sources={str(p):sha(p) for p in sorted(AUTHOR.rglob('*')) if p.is_file()}
declared={}
for manifest in AUTHOR.rglob('SOURCE_DEPENDENCIES_SHA256.json'):
    for path,digest in json.loads(manifest.read_text()).items():
        source_path=Path(path) if Path(path).is_absolute() else SRC/path
        key=str(source_path)
        assert sha(source_path)==digest, key
        if key in declared: assert declared[key]==digest
        declared[key]=digest
        sources[key]=digest
packet=json.loads((AUTHOR/'FROZEN_PACKET_MANIFEST_20261013.json').read_text())
assert packet['proof_sha256']==PIN
for entry in packet['files']:
    p=AUTHOR/entry['path']
    assert sha(p)==entry['sha256'] and len(p.read_bytes())==entry['bytes']
sha_list_count=0
for line in (AUTHOR/'SHA256SUMS.txt').read_text().splitlines():
    digest,path=line.split(None,1)
    assert sha(AUTHOR/path)==digest
    sha_list_count+=1
PROFILE=SRC/'reciprocal_beta_recovery/base_beta8m_profile_upper.json'
assert sha(PROFILE)=='1cbf7592037531b0c61ca9c5c01f40e418bf5932b291c25273490e535fb12542'
N=2048; beta=4000000; b0=R(13,10**7); grid=10**18

def ceiling(x,d=grid): return R(-(-x.numerator*d//x.denominator),d)
def floor(x,d=grid): return R(x.numerator*d//x.denominator,d)
def bracket(x): return [str(floor(x)),str(ceiling(x))]
def exp_bounds(x,n=200):
    assert x>=0 and x<n+2
    terms=[R(1)]
    for k in range(1,n+1): terms.append(terms[-1]*x/k)
    lo=sum(terms); hi=lo+terms[-1]*x/(n+1)/(1-x/(n+2))
    return lo,hi

# Branching profile on ALL counts is defined explicitly. The finite exceptional
# ratio checks below, followed by ratio (a+1)/(a+6), prove all-natural shape.
def reciprocal5(a): return R(1,prod(range(a+1,a+6)))
D=1860480; c=D*reciprocal5(12)/R(3,4)**12
A=[c*R(3,4)**a if a<=12 else D*reciprocal5(a) for a in range(N+2)]
g=[-A[0]/2]+[A[a]*min(6*a,70) for a in range(1,N+2)]
W=[[A[a]+g[a]/beta,A[a]] for a in range(N+2)]
assert c==R(1275068416,16120377)<80
assert W[15][1]==1 and min(min(x) for x in W[:16])==1
assert all(W[a+1][r]<W[a][r] for a in range(13) for r in (0,1))
assert all(W[a][r]>0 for a in range(N+2) for r in (0,1))
assert max(W[512])<R(6,10**8)
# Beta-integral moment plus finite prefix correction, derived from expansion of (1-t)^4.
EA=[]; EG=[]
for a in range(N+1):
    base=32*reciprocal5(a)-R(4,3)*sum(R((-1)**j*comb(4,j),(a+j+1)*2**(a+j+1)) for j in range(5))
    aa=D*base+sum(R(comb(a,k),2**a)*(A[k]-D*reciprocal5(k)) for k in range(min(a,12)+1))
    gg=70*aa+sum(R(comb(a,k),2**a)*(g[k]-70*A[k]) for k in range(min(a,11)+1))
    EA.append(aa); EG.append(gg)
spots=sorted(set([0,1,11,12,13,15,16,17,31,32,511,512,768,951,979,1024,2048]))
for a in spots:
    for r in (0,1):
        direct=sum(R(comb(a,k),2**a)*W[k][r] for k in range(a+1))
        assert direct==EA[a]+(EG[a]/beta if r==0 else 0)

# Literal chemistry followed by the basal aggregate identity and trigger upper gain.
def site(a,r,U,v,seed):
    u=R(a,N); current=W[a][r]; am=max(0,a-1)
    ans=seed*(1-u)*(W[a+1][r]-current)+a*(W[am][r]-current)
    m0=EA[a]+EG[a]/beta; m1=EA[a]
    if r:
        ans+=800*a*(1-u)*(W[a+1][0]-current)
        ans+=400*a*(W[am][0]-current)
        ans+=(beta*(1+u+U)+v)*(W[a][0]-current)
        ans+=m0+m1-2*current
        ans+=(u+U)*(2*m0-current)
    else:
        ans+=beta*(W[a][1]-current)+2*m0-2*current
    return ans
max_on=None; max_off=None; max_ret=None; onrows=offrows=0
for a in range(N+1):
    for r in (0,1):
        for U in (0,2):
            for v in (0,1843200):
                off=site(a,r,U,v,0); on=site(a,r,U,v,6)
                assert on-off==6*(1-R(a,N))*(W[a+1][r]-W[a][r])
                rr=on+W[a][r]/2; assert rr<=b0
                row=(a,r,U,v); onrows+=1
                if max_on is None or rr>max_on[0]:max_on=(rr,row)
                if a>=16:
                    rr=off+W[a][r]/2; assert rr<=b0 and off<=b0; offrows+=1
                    if max_off is None or rr>max_off[0]:max_off=(rr,row)
                    if max_ret is None or off>max_ret[0]:max_ret=(off,row)
# This explicit counterexample prevents a silent seed-free all-count SiteCert.
zero_off=site(0,0,0,0,0)
assert zero_off==c/2 and zero_off>b0

# Recovery profile: use export literally below512, reconstruct old tail independently.
HU=[[R(v) for v in row] for row in json.loads(PROFILE.read_text())]
assert all(row==[0,0] for row in HU[:16]) and len(HU)>=N+2
f={a:R((980-a)*(981-a)*(982-a),(a-10)*(a-9)*(a-8)) for a in range(511,769)}
for a in range(769,N+2): f[a]=f[a-1]*R(10,11)
old=[x.copy() for x in HU]
for a in range(512,N+2):
    kk=6*(1-R(a,N))*(f[a+1]/f[a]-1)+a*(f[a-1]/f[a]-1) if a<768 else R(5647*a,56320)-R(6,11)
    old[a]=[f[a]/f[512],f[a]/f[512]*(1-(258+kk)/8000000)]
    assert 0<=(258+kk)/8000000<R(1,10000)
    for r in (0,1): assert HU[a][r]-R(1,grid)<=old[a][r]<=HU[a][r]
RA=[x[0] for x in old]; gap=[R(11,8)*(x[0]-x[1]) for x in old]
h=[[a,a-d] for a,d in zip(RA,gap)]
l=R(9997,10000); ucomp=R(10000,9999); M=R(338971453059,125000)
recrows=0; seed_signs={'positive':0,'negative':0,'zero':0}; mins={0:None,1:None}
for a in range(16,N+1):
    assert h[a][0]>=h[a][1]>0
    if a<512: assert min(h[a])>=1
    for r in (0,1):
        oldlow=old[a][r]-(R(1,grid) if a<512 else 0)
        assert l*old[a][r]<=h[a][r]<=ucomp*oldlow
    # Expanded physical destination-fuel algebra, independently of event-list scripts.
    pa=a*(RA[a-1]-RA[a]); bd=800*a*(1-R(a,N)); ad=400*a
    G0=pa-beta*gap[a]
    G1=pa-a*(gap[a-1]-gap[a])+bd*(RA[a+1]-RA[a])+ad*(RA[a-1]-RA[a])
    G1+=(bd+ad+beta*(3+R(a,N))+800*N)*gap[a]
    source=R(0) if a<512 else R(1,4700)
    for r,G in enumerate((G0,G1)):
        assert G+150*h[a][r]<=source
        seedterm=6*(1-R(a,N))*(h[a+1][r]-h[a][r])
        assert G+seedterm+150*h[a][r]<=source
        seed_signs['positive' if seedterm>0 else 'negative' if seedterm<0 else 'zero']+=1
        decay=(source-G)/h[a][r]
        if mins[r] is None or decay<mins[r][0]:mins[r]=(decay,a)
        recrows+=1
assert 12*max(max(x) for x in h[16:N+1])<=M
assert R(beta,N)-400>0

# Recompute the OLD intrinsic2048 paired-reset inequality from outward enclosure
# integers. No band equations are resolved; their enclosure is an inherited input.
scaled=[]
for row in HU[:N+1]:
    assert all((x*grid).denominator==1 for x in row)
    scaled.append([int(x*grid) for x in row])
d=R(93867565097,200000000); C_old=d+8
max_def=None; max_all=None; resetrows=0
for a in range(16,N+1):
    moment_integer=0
    if a>=32:
        ck=comb(a,16)
        for k in range(16,a-15):
            moment_integer+=ck*scaled[k][0]
            ck=ck*(a-k)//(k+1)
    moment=R(moment_integer,2**a*grid)
    for r in (0,1):
        pp=1+r*(2+R(a,N))
        residual=2*pp*moment-d*max(R(0),R(scaled[a][r]-1,grid))
        item=(residual,(a,r))
        if max_all is None or residual>max_all[0]:max_all=item
        if a<512 and (max_def is None or residual>max_def[0]):max_def=item
        resetrows+=1
assert max_def[0]+11*max_all[0]<=0
assert C_old==R(95467565097,200000000)
assert ucomp*C_old/l<478

# Resource-clock constants and all numerical probability components.
gamma=150+4-R(12,4700); C=478
kappa=R(3,5*beta+1200*N); arate=4+4*beta*kappa; V=20*beta+5400*N+64
T=R(1,2); delta=R(1,100); theta_clock=R(1,640)
actual_clock=theta_clock*(delta/kappa-4)-V*T*theta_clock**2/(2*(1-2*theta_clock/3))
assert actual_clock==R(28228801,460320)
assert arate*T+delta==R(1080309,350900)<=R(321,100)
assert delta>4*kappa and theta_clock<R(3,2)
assert actual_clock>=R(9141301,460320)
# Prove affine residual equality for clock bound at endpoint F,Z combinations.
for F in range(5):
    for Z in (R(0),R(3*F)):
        lhs=kappa*(beta*(2*F+Z-4)+400*N*Z)-((4+Z)-arate)
        assert lhs==R(2,3)*beta*kappa*(3*F-Z)>=0
low_words=M*sum((C*T)**j/factorial(j) for j in range(14))/exp_bounds(gamma*T)[0]
mu=R(321,100)
poisson=1-sum(mu**j/factorial(j) for j in range(14))/exp_bounds(mu)[1]
clockterm=1/exp_bounds(R(9141301,460320))[0]
q=low_words+poisson+clockterm
assert ceiling(q)==R(8622092430140,grid)<R(1,100000)

# Ordinary credit service, all floor-live counts and both fuels.
z=R(3,4); rho=R(79967,80000); theta=1650
Hs=800*3*N*R(9,16)+3*beta+8
assert Hs==14764808 and beta*(1-rho)==theta
service_rows=0
for a in range(16,N+1):
    for r in (0,1):
        drift=-beta*(1-rho) if r==0 else beta*R(a,N)*(z-rho)+Hs*(1-rho)
        assert drift+theta*(rho if r else 1)<=0
        service_rows+=1
assert beta*R(16,N)*(z-rho)+Hs*(1-rho)+theta*rho==R(-598067,10000)
service=12/rho*z**(-500)/exp_bounds(R(165))[0]
assert service<R(1,10**8)
assert exp_bounds(R(15))[0]>2900000 and exp_bounds(R(25))[0]>10**10
Gdirect=R(48,10**8)+R(320,2900000)+608*b0+R(600,10**8)+R(5184,10**10)
Gadvert=R(9545923,9062500000)
assert Gdirect==R(8226423,9062500000) and Gadvert-Gdirect==112*b0
risk=Gadvert+R(11,100000)+10/exp_bounds(R(8))[0]+3/exp_bounds(R(20))[0]
assert ceiling(risk)==R(4517975690072193,grid)
assert 30+11*T+10*2==R(111,2)<60
assert 300*4*2*500+300*4*3*500==3000000

# Uniform all-state feed tilt, switched seed intensity and gross stock arithmetic.
assert beta+1>=R(800*N,2)
Cstar=beta+3*(400*N+beta+1)
t=R(1,10000); s=R(400,22457607)
k1=beta*(t-s)/(1-t+s); k2=(Cstar+1+3/(1-s))*s/(1-s)
assert 0<s<t<1 and k1>=k2
feed_exp=4*s+240*k1-800000000*t
assert feed_exp==R(-5508991479342664251200,5043026607980323551)<-1092
seed_exp=2160*R(1,9)-500
assert seed_exp==-260
assert exp_bounds(R(1,5))[1]-1<R(31,140)
div_exp=960*R(31,140)-240
assert div_exp==R(-192,7)<-20
assert 4*(3*(6+800*N+400*N+N+beta)+beta+4)==93515864
assert 4*(3*(0+800*N+400*N+N+beta)+beta+4)==93515792
caps={'accepted_feed':800000000,'initial_fuel_at_most':4,'consumed_fuel':800000004,'accepted_seeds':5000,'birth_plus_seed_precursors':800005004,'actual_marked_divisions':1200,'discarded_catalyst_slots':3*N*1200,'discarded_victim_fuel':1200}
assert caps['discarded_catalyst_slots']==7372800
# Deterministic complementary inheritance implication for every physically allowed split.
inheriting_splits=0
for a in range(N+1):
    for k in range(a+1):
        if k>=16 and a-k>=16:
            assert a>=32 and 16<=k<=a-16
            inheriting_splits+=1

for path,digest in sources.items(): assert sha(Path(path))==digest, ('source changed',path)
result={
 'status':'PASS', 'proof_sha256':PIN,'author_source_manifest_verified':True,
 'frozen_packet_files_verified':len(packet['files']), 'author_sha_list_entries_verified':sha_list_count,'distinct_source_dependency_pins_verified':len(declared),
 'independent_counts':{'seed_on_all_count_branching_rows':onrows,'seed_free_live_branching_rows':offrows,'direct_daughter_moment_counts':len(spots),'recovery_rows':recrows,'old_reset_enclosure_rows':resetrows,'service_rows':service_rows,'enumerated_valid_complementary_splits':inheriting_splits},
 'branching':{'seed_on_max':{'row':max_on[1],'interval':bracket(max_on[0])},'seed_free_contraction_max':{'row':max_off[1],'interval':bracket(max_off[0])},'seed_free_retention_max':{'row':max_ret[1],'interval':bracket(max_ret[0])},'seed_free_zero_unfueled_counterexample':str(zero_off)},
 'recovery':{'min_decay':{str(r):{'count':mins[r][1],'interval':bracket(mins[r][0])} for r in (0,1)},'seed_term_signs':seed_signs,'M':str(M),'gamma':str(gamma),'C':C,'old_reset_deficient_max':{'row':max_def[1],'interval':bracket(max_def[0])},'old_reset_global_max':{'row':max_all[1],'interval':bracket(max_all[0])},'old_reset_combined_upper':str(ceiling(max_def[0]+11*max_all[0])),'reset_transfer_upper':str(ceiling(ucomp*C_old/l)),'actual_clock_exponent':str(actual_clock),'actual_clock_mean':str(arate*T+delta),'low_words_upper':str(ceiling(low_words)),'poisson_upper':str(ceiling(poisson)),'clock_upper':str(ceiling(clockterm)),'q_once_rounded':str(ceiling(q))},
 'mission':{'service_block_upper':str(ceiling(service)),'Gdirect':str(Gdirect),'Gadvertised':str(Gadvert),'complete_failure_upper':str(ceiling(risk)),'success_lower':str(1-ceiling(risk)),'renewals_deadline':str(R(111,2)),'service_credits':3000000,'service_deadline':60},
 'resources':{'Cstar':Cstar,'feed_exponent_upper':str(feed_exp),'seed_exponent_upper':str(seed_exp),'division_exponent_upper':str(div_exp),'caps':caps},
 'trust_boundary':'Exact-profile band-solve enclosures and supplied upstream-source transcriptions are inherited accepted inputs; no new compiler, theorem prover, full physical state enumeration or experiment was performed.',
 'source_hashes':sources
}
(OUT/'SOURCE_DEPENDENCIES_SHA256.json').write_text(json.dumps(sources,indent=2)+'\n')
(OUT/'independent_full_mission_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='source_hashes'},indent=2))
