# Legacy beta8m support: private proposed disclosure

The specific missing source premise is now included in this **private proposed package**. This is source disclosure preparation; it is not public release or a new formal verification receipt. The original 37-file companion is preserved byte for byte under `../companion_inputs`. The two added local mathematical files are:

- `proofs/FunctionalCapacity/Cert.lean`: 32,445 bytes, SHA256 `1d3c0f327d1c2d1ab5606f10b7ff31d2146883176d6a0a08efd68355c59428d3`.
- `proofs/FunctionalCapacity/Defs.lean`: 9,769 bytes, SHA256 `4849c8f8a8012dbe63a22f9819bdd3e4b6cc478d001f55c36144d95549ee72c6`.

Both are exact copies from `ARCHIVE_PATH_001`, matching the independent v2.1 review's pins. Module paths and source bytes are preserved. `Cert.lean` imports only `proofs.FunctionalCapacity.Defs`; `Defs.lean` imports Mathlib. Thus these are the complete local import closure for this omitted certificate, with the pinned public Mathlib dependency remaining external.

## What the certificate supplies

At Cert.lean line 708, `cert0 : SiteCert p0 16 W0 (1 / 2) b0 80` provides the explicit site potential and branching-drift certificate for the original **continuously seeded beta8m** operating point. The parameter definition is M=4, c=3, N=2048, catalytic coefficient800, fuel rate8,000,000 and seed coefficient6. `b0=13/10^7`. The complete file includes the glued potential, binomial moment estimates, piecewise exact residual arguments, nonnegativity, maximum and floor-barrier bounds. `Defs.lean` supplies the literal operator/model and `SiteCert` statement.

This source support does not replace the P161 population/service/recovery/finite-stock proof, which remains in the existing attributed manuscript support. Nor does it silently establish the beta4m seed-free mission or every table row. The intrinsic2048 attempt concerns profile/reset support, not a fresh Lean compilation of `cert0`.

## Environment provenance

The exact canonical `lean-toolchain` and `lake-manifest.json` are included unchanged here. They pin Lean `leanprover/lean4:v4.30.0`, Mathlib revision `c5ea00351c28e24afc9f0f84379aa41082b1188f` (input tag v4.30.0), and all eight other locked packages. `SOURCE_AND_LICENCE_PROVENANCE.json` records their revisions, source paths, hashes, import closure and copied licences.

The larger canonical Lake configuration contains unrelated project targets and is not copied into this minimal proposed package. These files provide the exact proof sources and dependency identities; they do not claim that a new standalone build recipe or scoped compilation has been tested. An eventual formal-verification claim must retain an independently checkable build/receipt scope. No Lake, Lean, dependency fetch or Git command was run in this preparation.

## Licence and attribution review

The two local proof files have no copyright, SPDX or licence grant in their headers. No LICENSE/LICENCE/COPYING/NOTICE file was found in the inspected project root, `proofs` or `proofs/FunctionalCapacity` directories. This establishes **no explicit grant located in that bounded source review**, rather than a legal conclusion about ownership or an assertion that no other agreement exists. Private copying here is within Michael's preparation instruction. Public attribution and a licence/grant for these local sources remain an owner decision; author metadata stays blank.

Mathlib and seven other locked packages have local Apache-2.0 licence texts; the locked `Cli` package has an MIT licence, including its copyright notice. The nine exact licence files are preserved under `third_party_licences`, with package/revision mapping in the provenance JSON. No third-party implementation is vendored here. Those dependency licences do **not** assign a licence to the local Cert/Defs files. Preserve the actual notices and source provenance if a public package is later approved.

The missing-file disclosure omission is closed in this proposed private package. Public release rights, stable public references and any fresh scoped formal verification remain distinct, unresolved release matters. No proof citation has been removed.
