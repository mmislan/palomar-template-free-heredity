import proofs.FunctionalCapacity.Defs

/-!
# Functional capacity: an explicit site certificate

Witness parameters `p0 = (M, c, N, α, β, ε) = (4, 3, 2048, 800, 8·10⁶, 6)`, floor `K = 16`.
The potential `W0` is glued from three pieces (zero piece, geometric piece `C q^a`, factorial
piece `A · a!/(a+5)!`) with small fuel weights.  `cert0` proves the branching-drift inequality
`siteOp ≤ -(1/2) W0 + b0` with `b0 = 13/10^7`.
-/

namespace FunctionalCapacity

noncomputable section
open Finset

/-! ### Elementary real lemmas -/

theorem lin_le (m n lo hi x : ℝ) (h1 : m * lo + n ≤ 0) (h2 : m * hi + n ≤ 0)
    (hlo : lo ≤ x) (hhi : x ≤ hi) : m * x + n ≤ 0 := by
  rcases le_total 0 m with h | h
  · have := mul_nonneg h (sub_nonneg.2 hhi)
    linarith
  · have := mul_nonneg (neg_nonneg.2 h) (sub_nonneg.2 hlo)
    linarith

/-- a convex quadratic is nonpositive on an interval as soon as it is at both endpoints -/
theorem quad_le (c2 c1 c0 lo hi x : ℝ) (hc2 : 0 ≤ c2) (hlo : lo ≤ x) (hhi : x ≤ hi)
    (e1 : c2 * lo ^ 2 + c1 * lo + c0 ≤ 0) (e2 : c2 * hi ^ 2 + c1 * hi + c0 ≤ 0) :
    c2 * x ^ 2 + c1 * x + c0 ≤ 0 := by
  have hl := lin_le (c1 + c2 * (lo + hi)) (c0 - c2 * lo * hi) lo hi x (by linarith) (by linarith)
    hlo hhi
  have := mul_nonneg hc2 (mul_nonneg (sub_nonneg.2 hlo) (sub_nonneg.2 hhi))
  linarith

/-! ### The binomial half -/

theorem binE_mono {g g' : ℕ → ℝ} {a : ℕ} (h : ∀ k, k ≤ a → g k ≤ g' k) :
    binE g a ≤ binE g' a := by
  unfold binE
  apply Finset.sum_le_sum
  intro k hk
  have hk' : k ≤ a := Nat.lt_succ_iff.mp (Finset.mem_range.mp hk)
  exact mul_le_mul_of_nonneg_left (h k hk') (by positivity)

theorem binE_const_mul (c : ℝ) (g : ℕ → ℝ) (a : ℕ) :
    binE (fun k => c * g k) a = c * binE g a := by
  unfold binE
  rw [Finset.mul_sum]
  exact Finset.sum_congr rfl (fun k _ => by ring)

theorem binE_pow (r : ℝ) (a : ℕ) : binE (fun k => r ^ k) a = ((1 + r) / 2) ^ a := by
  unfold binE
  rw [div_pow, add_comm 1 r, add_pow, Finset.sum_div]
  refine Finset.sum_congr rfl (fun k _ => ?_)
  simp only [one_pow, mul_one]
  ring

theorem binE_zero (g : ℕ → ℝ) : binE g 0 = g 0 := by
  simp [binE]

/-- `a!/(a+5)!` -/
def hh (a : ℕ) : ℝ :=
  1 / (((a : ℝ) + 1) * ((a : ℝ) + 2) * ((a : ℝ) + 3) * ((a : ℝ) + 4) * ((a : ℝ) + 5))

theorem hh_pos (a : ℕ) : 0 < hh a := by
  unfold hh; positivity

theorem hh_succ (a : ℕ) : hh (a + 1) = hh a * (((a : ℝ) + 1) / ((a : ℝ) + 6)) := by
  unfold hh
  push_cast
  rw [div_mul_div_comm, div_eq_div_iff (by positivity) (by positivity)]
  ring

theorem hh_pred (a : ℕ) (h : 1 ≤ a) : hh (a - 1) = hh a * (((a : ℝ) + 5) / (a : ℝ)) := by
  cases a with
  | zero => omega
  | succ b =>
    simp only [Nat.add_sub_cancel]
    unfold hh
    push_cast
    rw [div_mul_div_comm, div_eq_div_iff (by positivity) (by positivity)]
    ring

theorem hh_anti {a b : ℕ} (h : a ≤ b) : hh b ≤ hh a := by
  unfold hh
  have h' : (a : ℝ) ≤ b := by exact_mod_cast h
  apply one_div_le_one_div_of_le (by positivity)
  gcongr

theorem hh_fact (k : ℕ) : hh k = (k.factorial : ℝ) / ((k + 5).factorial : ℝ) := by
  have h5 : (k + 5).factorial
      = (k + 5) * ((k + 4) * ((k + 3) * ((k + 2) * ((k + 1) * k.factorial)))) := by
    simp only [Nat.factorial_succ]
  have hk : (0 : ℝ) < k.factorial := by exact_mod_cast k.factorial_pos
  rw [h5]
  unfold hh
  push_cast
  rw [div_eq_div_iff (by positivity) (by positivity)]
  ring

theorem choose_mul_hh {a k : ℕ} (h : k ≤ a) :
    ((a.choose k : ℕ) : ℝ) * hh k = hh a * (((a + 5).choose (k + 5) : ℕ) : ℝ) := by
  rw [hh_fact, hh_fact, Nat.cast_choose ℝ h, Nat.cast_choose ℝ (show k + 5 ≤ a + 5 by omega),
    show a + 5 - (k + 5) = a - k by omega]
  have h1 : (0 : ℝ) < k.factorial := by exact_mod_cast k.factorial_pos
  have h2 : (0 : ℝ) < (k + 5).factorial := by exact_mod_cast (k + 5).factorial_pos
  have h3 : (0 : ℝ) < a.factorial := by exact_mod_cast a.factorial_pos
  have h4 : (0 : ℝ) < (a + 5).factorial := by exact_mod_cast (a + 5).factorial_pos
  have h5 : (0 : ℝ) < (a - k).factorial := by exact_mod_cast (a - k).factorial_pos
  rw [div_mul_div_comm, div_mul_div_comm, div_eq_div_iff (by positivity) (by positivity)]
  ring

theorem sum_choose_shift (a : ℕ) :
    ∑ k ∈ range (a + 1), (a + 5).choose (k + 5) ≤ 2 ^ (a + 5) := by
  rw [← Nat.sum_range_choose (a + 5), show a + 5 + 1 = 5 + (a + 1) by omega,
    Finset.sum_range_add _ 5 (a + 1)]
  refine le_trans (le_of_eq ?_) (Nat.le_add_left _ _)
  exact Finset.sum_congr rfl (fun k _ => by rw [add_comm k 5])

theorem binE_hh (a : ℕ) : binE hh a ≤ 32 * hh a := by
  unfold binE
  have h1 : ∀ k ∈ range (a + 1), ((a.choose k : ℕ) : ℝ) / 2 ^ a * hh k
      = hh a / 2 ^ a * (((a + 5).choose (k + 5) : ℕ) : ℝ) := by
    intro k hk
    have hk' : k ≤ a := Nat.lt_succ_iff.mp (Finset.mem_range.mp hk)
    rw [div_mul_eq_mul_div, choose_mul_hh hk']
    ring
  rw [Finset.sum_congr rfl h1, ← Finset.mul_sum]
  have h2 : (∑ k ∈ range (a + 1), (((a + 5).choose (k + 5) : ℕ) : ℝ)) ≤ 2 ^ (a + 5) := by
    exact_mod_cast sum_choose_shift a
  have h3 : 0 ≤ hh a / 2 ^ a := by
    have := hh_pos a
    positivity
  have h4 : (2 : ℝ) ^ a ≠ 0 := by positivity
  calc hh a / 2 ^ a * (∑ k ∈ range (a + 1), (((a + 5).choose (k + 5) : ℕ) : ℝ))
      ≤ hh a / 2 ^ a * 2 ^ (a + 5) := mul_le_mul_of_nonneg_left h2 h3
    _ = 32 * hh a := by
        rw [pow_add, div_mul_eq_mul_div, div_eq_iff h4]
        ring

/-! ### Monotonicity of `siteOp` in the target values -/

/-- witness parameters -/
def p0 : Par := ⟨4, 3, 2048, 800, 8000000, 6⟩

theorem siteOp_true_le (W : ℕ → Bool → ℝ) (a : ℕ) (Hf Uf P1t P1f M1f M1t Wf Bt Bf : ℝ)
    (ha : a ≤ 2048) (hH : 0 ≤ Hf) (hU : 0 ≤ Uf)
    (h1 : W (a + 1) true ≤ P1t) (h2 : W (a + 1) false ≤ P1f)
    (h3 : W (a - 1) false ≤ M1f) (h4 : W (a - 1) true ≤ M1t)
    (h5 : W a false ≤ Wf)
    (h6 : binE (fun k => W k true) a ≤ Bt) (h7 : binE (fun k => W k false) a ≤ Bf) :
    siteOp p0 W a true Hf Uf ≤
      6 * (1 - (a : ℝ) / 2048) * (P1t - W a true)
      + 800 * (a : ℝ) * (1 - (a : ℝ) / 2048) * (P1f - W a true)
      + 800 / 2 * (a : ℝ) * (M1f - W a true)
      + (a : ℝ) * (M1t - W a true)
      + (8000000 * (1 + (a : ℝ) / 2048) + Hf) * (Wf - W a true)
      + (Bt + Bf - 2 * W a true)
      + ((a : ℝ) / 2048 + Uf) * (2 * Bf - W a true) := by
  have hx : (0 : ℝ) ≤ a := Nat.cast_nonneg a
  have hx2 : (a : ℝ) ≤ 2048 := by exact_mod_cast ha
  have hu : 0 ≤ 1 - (a : ℝ) / 2048 := by linarith
  have hu' : 0 ≤ (a : ℝ) / 2048 := by positivity
  simp only [siteOp, p0, ↓reduceIte]
  push_cast
  have c1 := mul_nonneg (mul_nonneg (by norm_num : (0 : ℝ) ≤ 6) hu) (sub_nonneg.2 h1)
  have c2 := mul_nonneg (mul_nonneg (mul_nonneg (by norm_num : (0 : ℝ) ≤ 800) hx) hu)
    (sub_nonneg.2 h2)
  have c3 := mul_nonneg (mul_nonneg (by norm_num : (0 : ℝ) ≤ 800 / 2) hx) (sub_nonneg.2 h3)
  have c4 := mul_nonneg hx (sub_nonneg.2 h4)
  have c5 := mul_nonneg (show 0 ≤ 8000000 * (1 + (a : ℝ) / 2048) + Hf by positivity)
    (sub_nonneg.2 h5)
  have c7 := mul_nonneg (show 0 ≤ (a : ℝ) / 2048 + Uf by positivity) (sub_nonneg.2 h7)
  linarith

theorem siteOp_false_le (W : ℕ → Bool → ℝ) (a : ℕ) (Hf Uf P1f M1f Wt Bf : ℝ)
    (ha : a ≤ 2048)
    (h1 : W (a + 1) false ≤ P1f) (h2 : W (a - 1) false ≤ M1f) (h3 : W a true ≤ Wt)
    (h4 : binE (fun k => W k false) a ≤ Bf) :
    siteOp p0 W a false Hf Uf ≤
      6 * (1 - (a : ℝ) / 2048) * (P1f - W a false)
      + (a : ℝ) * (M1f - W a false)
      + 8000000 * (Wt - W a false)
      + (2 * Bf - 2 * W a false) := by
  have hx : (0 : ℝ) ≤ a := Nat.cast_nonneg a
  have hx2 : (a : ℝ) ≤ 2048 := by exact_mod_cast ha
  have hu : 0 ≤ 1 - (a : ℝ) / 2048 := by linarith
  simp only [siteOp, p0, Bool.false_eq_true, ↓reduceIte]
  push_cast
  have c1 := mul_nonneg (mul_nonneg (by norm_num : (0 : ℝ) ≤ 6) hu) (sub_nonneg.2 h1)
  have c2 := mul_nonneg hx (sub_nonneg.2 h2)
  linarith

/-! ### Residual inequalities in real variables -/

theorem geoF_real (x L s : ℝ) (hx1 : 1 ≤ x) (hx12 : x ≤ 12) (hL : L ≤ 32 / 5) (hs : 0 ≤ s) :
    6 * (1 - x / 2048) * (s * (1 + 2 / 10 ^ 6) * (3 / 4) - s * (1 + 2 / 10 ^ 6))
      + x * (s * (1 + 2 / 10 ^ 6) * (4 / 3) - s * (1 + 2 / 10 ^ 6))
      + 8000000 * (s - s * (1 + 2 / 10 ^ 6))
      + (2 * (s * (1 + 2 / 10 ^ 6) * L) - 2 * (s * (1 + 2 / 10 ^ 6)))
      ≤ -(1 / 2) * (s * (1 + 2 / 10 ^ 6)) := by
  have f1 := mul_nonneg hs (sub_nonneg.2 hx1)
  have f2 := mul_nonneg hs (sub_nonneg.2 hx12)
  have f3 := mul_nonneg hs (sub_nonneg.2 hL)
  linarith

theorem geoT_real (x L s Hf Uf : ℝ) (hx1 : 1 ≤ x) (hx12 : x ≤ 12) (hL1 : 1 ≤ L)
    (hL : L ≤ 7 / 6 + 6 * (x - 1)) (hs : 0 ≤ s) (hU2 : Uf ≤ 2)
    (hH : Hf ≤ 8000000 * Uf + 1843200) :
    6 * (1 - x / 2048) * (s * (3 / 4) - s)
      + 800 * x * (1 - x / 2048) * (s * (1 + 2 / 10 ^ 6) * (3 / 4) - s)
      + 800 / 2 * x * (s * (1 + 2 / 10 ^ 6) * (4 / 3) - s)
      + x * (s * (4 / 3) - s)
      + (8000000 * (1 + x / 2048) + Hf) * (s * (1 + 2 / 10 ^ 6) - s)
      + (s * L + s * (1 + 2 / 10 ^ 6) * L - 2 * s)
      + (x / 2048 + Uf) * (2 * (s * (1 + 2 / 10 ^ 6) * L) - s)
      ≤ -(1 / 2) * s := by
  have key : 6 * (1 - x / 2048) * ((3 / 4) - 1)
      + 800 * x * (1 - x / 2048) * ((1 + 2 / 10 ^ 6) * (3 / 4) - 1)
      + 800 / 2 * x * ((1 + 2 / 10 ^ 6) * (4 / 3) - 1)
      + x * ((4 / 3) - 1)
      + (8000000 * (1 + x / 2048) + Hf) * ((1 + 2 / 10 ^ 6) - 1)
      + (L + (1 + 2 / 10 ^ 6) * L - 2)
      + (x / 2048 + Uf) * (2 * ((1 + 2 / 10 ^ 6) * L) - 1)
      ≤ -(1 / 2) := by
    have f1 := mul_nonneg (show (0 : ℝ) ≤ x by linarith) (sub_nonneg.2 hx12)
    have f2 := mul_nonneg (show (0 : ℝ) ≤ L by linarith) (sub_nonneg.2 hx12)
    have f3 := mul_nonneg (sub_nonneg.2 hU2) (show (0 : ℝ) ≤ L by linarith)
    linarith
  have := mul_le_mul_of_nonneg_left key hs
  linarith

theorem facF_real (x s : ℝ) (hx13 : 13 ≤ x) (hx : x ≤ 2048) (hs : 0 ≤ s) :
    6 * (1 - x / 2048) * (s * (1 + 9 / 10 ^ 6) * ((x + 1) / (x + 6)) - s * (1 + 9 / 10 ^ 6))
      + x * (s * (1 + 9 / 10 ^ 6) * ((x + 5) / x) - s * (1 + 9 / 10 ^ 6))
      + 8000000 * (s - s * (1 + 9 / 10 ^ 6))
      + (2 * (32 * (s * (1 + 9 / 10 ^ 6))) - 2 * (s * (1 + 9 / 10 ^ 6)))
      ≤ -(1 / 2) * (s * (1 + 9 / 10 ^ 6)) := by
  have hx6 : 0 < x + 6 := by linarith
  have hx0 : x ≠ 0 := by linarith
  have hup1 : (x + 1) / (x + 6) ≤ 1 := by
    rw [div_le_one hx6]; linarith
  have hdn' : x * ((x + 5) / x) = x + 5 := by field_simp
  generalize (x + 1) / (x + 6) = up at *
  generalize (x + 5) / x = dn at *
  have hu0 : 0 ≤ 1 - x / 2048 := by linarith
  have t1 := mul_nonneg (mul_nonneg hu0 (mul_nonneg hs (by norm_num : (0 : ℝ) ≤ 1 + 9 / 10 ^ 6)))
    (sub_nonneg.2 hup1)
  have t2 : x * (s * (1 + 9 / 10 ^ 6) * dn - s * (1 + 9 / 10 ^ 6)) = 5 * (s * (1 + 9 / 10 ^ 6)) := by
    linear_combination (s * (1 + 9 / 10 ^ 6)) * hdn'
  linarith

theorem facT_real (x s Hf Uf Tb : ℝ) (hx13 : 13 ≤ x) (hx : x ≤ 2048) (hs : 0 ≤ s)
    (hU2 : Uf ≤ 2) (hH : Hf ≤ 8000000 * Uf + 1843200)
    (hq : (2430 - Tb + 7 / 100 * x) * (x + 6) ≤ 4000 * (x * (1 - x / 2048))) :
    6 * (1 - x / 2048) * (s * ((x + 1) / (x + 6)) - s)
      + 800 * x * (1 - x / 2048) * (s * (1 + 9 / 10 ^ 6) * ((x + 1) / (x + 6)) - s)
      + 800 / 2 * x * (s * (1 + 9 / 10 ^ 6) * ((x + 5) / x) - s)
      + x * (s * ((x + 5) / x) - s)
      + (8000000 * (1 + x / 2048) + Hf) * (s * (1 + 9 / 10 ^ 6) - s)
      + (32 * s + 32 * (s * (1 + 9 / 10 ^ 6)) - 2 * s)
      + (x / 2048 + Uf) * (2 * (32 * (s * (1 + 9 / 10 ^ 6))) - s)
      ≤ -(1 / 2) * s + Tb * s := by
  have hx6 : 0 < x + 6 := by linarith
  have hx0 : x ≠ 0 := by linarith
  have hup1 : (x + 1) / (x + 6) ≤ 1 := by
    rw [div_le_one hx6]; linarith
  have hup' : (x + 1) / (x + 6) * (x + 6) = x + 1 := by field_simp
  have hdn' : x * ((x + 5) / x) = x + 5 := by field_simp
  generalize (x + 1) / (x + 6) = up at *
  generalize (x + 5) / x = dn at *
  have hu0 : 0 ≤ 1 - x / 2048 := by linarith
  have hy0 : 0 ≤ x * (1 - x / 2048) := mul_nonneg (by linarith) hu0
  have hy512 : x * (1 - x / 2048) ≤ 512 := by nlinarith [sq_nonneg (x - 1024)]
  have hP0 : 0 ≤ x * (1 - x / 2048) * (1 - up) := mul_nonneg hy0 (by linarith)
  have hP6 : x * (1 - x / 2048) * (1 - up) * (x + 6) = 5 * (x * (1 - x / 2048)) := by
    linear_combination (-(x * (1 - x / 2048))) * hup'
  have hQ : 2430 - Tb + 7 / 100 * x ≤ 800 * (x * (1 - x / 2048) * (1 - up)) := by
    have h : (2430 - Tb + 7 / 100 * x) * (x + 6)
        ≤ 800 * (x * (1 - x / 2048) * (1 - up)) * (x + 6) := by
      have e : 800 * (x * (1 - x / 2048) * (1 - up)) * (x + 6)
          = 800 * (x * (1 - x / 2048) * (1 - up) * (x + 6)) := by ring
      rw [e, hP6]; linarith
    exact le_of_mul_le_mul_right h hx6
  have a1 := mul_nonneg hu0 (sub_nonneg.2 hup1)
  have key : 6 * (1 - x / 2048) * (up - 1)
      + 800 * x * (1 - x / 2048) * ((1 + 9 / 10 ^ 6) * up - 1)
      + 800 / 2 * x * ((1 + 9 / 10 ^ 6) * dn - 1)
      + x * (dn - 1)
      + (8000000 * (1 + x / 2048) + Hf) * ((1 + 9 / 10 ^ 6) - 1)
      + (32 + 32 * (1 + 9 / 10 ^ 6) - 2)
      + (x / 2048 + Uf) * (2 * (32 * (1 + 9 / 10 ^ 6)) - 1)
      ≤ -(1 / 2) + Tb := by
    linarith
  have := mul_le_mul_of_nonneg_left key hs
  linarith

/-! ### The potential -/

def CC : ℝ := 1860480 * hh 12 / (3 / 4) ^ 12

def C0 : ℝ := CC / (1 + 1 / 10 ^ 7)

def zgR (R : Bool) : ℝ := if R then 1 else 1 + 2 / 10 ^ 6

def zfR (R : Bool) : ℝ := if R then 1 else 1 + 9 / 10 ^ 6

/-- the certificate potential -/
def W0 (a : ℕ) (R : Bool) : ℝ :=
  if a = 0 then C0 * (if R then 1 + 1 / 10 ^ 7 else 1)
  else if a ≤ 12 then CC * zgR R * (3 / 4) ^ a
  else 1860480 * zfR R * hh a

/-- the drift slack -/
def b0 : ℝ := 13 / 10 ^ 7

theorem zgR_true : zgR true = 1 := by simp [zgR]
theorem zgR_false : zgR false = 1 + 2 / 10 ^ 6 := by simp [zgR]
theorem zfR_true : zfR true = 1 := by simp [zfR]
theorem zfR_false : zfR false = 1 + 9 / 10 ^ 6 := by simp [zfR]

theorem zgR_bd (R : Bool) : 1 ≤ zgR R ∧ zgR R ≤ 1 + 2 / 10 ^ 6 := by
  cases R
  · rw [zgR_false]; norm_num
  · rw [zgR_true]; norm_num

theorem zfR_bd (R : Bool) : 1 ≤ zfR R ∧ zfR R ≤ 1 + 9 / 10 ^ 6 := by
  cases R
  · rw [zfR_false]; norm_num
  · rw [zfR_true]; norm_num

theorem zgR_le_zfR (R : Bool) : zgR R ≤ zfR R := by
  cases R
  · rw [zgR_false, zfR_false]; norm_num
  · rw [zgR_true, zfR_true]

theorem CC_lo : 79 < CC := by unfold CC hh; norm_num
theorem CC_hi : CC < 791 / 10 := by unfold CC hh; norm_num
theorem CC_pos : 0 < CC := by linarith [CC_lo]
theorem hCC : CC = C0 * (1 + 1 / 10 ^ 7) := by unfold C0; field_simp
theorem C0_lo : 78 < C0 := by
  have := hCC; have := CC_lo
  nlinarith
theorem C0_pos : 0 < C0 := by linarith [C0_lo]

theorem W0_zero_true : W0 0 true = C0 * (1 + 1 / 10 ^ 7) := by simp [W0]
theorem W0_zero_false : W0 0 false = C0 := by simp [W0]

theorem W0_geo {a : ℕ} (h1 : 1 ≤ a) (h12 : a ≤ 12) (R : Bool) :
    W0 a R = CC * zgR R * (3 / 4) ^ a := by
  unfold W0
  rw [if_neg (by omega), if_pos h12]

theorem W0_fac {a : ℕ} (h13 : 13 ≤ a) (R : Bool) : W0 a R = 1860480 * zfR R * hh a := by
  unfold W0
  rw [if_neg (by omega), if_neg (by omega)]

theorem W0_one_true : W0 (0 + 1) true = CC * (3 / 4) := by
  rw [W0_geo (by norm_num) (by norm_num)]
  simp only [zgR_true, mul_one, zero_add, pow_one]

theorem W0_one_false : W0 (0 + 1) false = CC * (1 + 2 / 10 ^ 6) * (3 / 4) := by
  rw [W0_geo (by norm_num) (by norm_num)]
  simp only [zgR_false, zero_add, pow_one]

/-- on `[0, 13]` the potential is below the geometric piece -/
theorem le_geo (k : ℕ) (R : Bool) (hk : k ≤ 13) : W0 k R ≤ CC * zgR R * (3 / 4) ^ k := by
  have hC := CC_pos
  have hC0 := C0_pos
  have hcc := hCC
  rcases Nat.eq_zero_or_pos k with rfl | h1
  · cases R
    · rw [W0_zero_false, zgR_false]; nlinarith
    · rw [W0_zero_true, zgR_true]; linarith
  · rcases Nat.lt_or_ge k 13 with h12 | h13
    · rw [W0_geo h1 (by omega)]
    · have : k = 13 := by omega
      subst this
      rw [W0_fac (by norm_num)]
      cases R
      · rw [zgR_false, zfR_false]; unfold CC hh; norm_num
      · rw [zgR_true, zfR_true]; unfold CC hh; norm_num

/-- everywhere the potential is below the factorial piece -/
theorem le_fac (k : ℕ) (R : Bool) : W0 k R ≤ 1860480 * zfR R * hh k := by
  have hC := CC_pos
  have hC0 := C0_pos
  have hcc := hCC
  have hchi := CC_hi
  obtain ⟨hz1, hz2⟩ := zfR_bd R
  rcases Nat.eq_zero_or_pos k with rfl | h1
  · have h0 : (1860480 : ℝ) * hh 0 = 15504 := by unfold hh; norm_num
    have : (15504 : ℝ) ≤ 1860480 * zfR R * hh 0 := by nlinarith
    cases R
    · rw [W0_zero_false]; linarith
    · rw [W0_zero_true]; linarith
  · rcases Nat.lt_or_ge k 13 with h12 | h13
    · rw [W0_geo h1 (by omega)]
      have hk : CC * (3 / 4 : ℝ) ^ k ≤ 1860480 * hh k := by
        interval_cases k <;> (unfold CC hh; norm_num)
      have hzz := zgR_le_zfR R
      have hz0 : 0 ≤ zgR R := by linarith [(zgR_bd R).1]
      have hp : 0 ≤ CC * (3 / 4 : ℝ) ^ k := by positivity
      have hq : 0 ≤ (1860480 : ℝ) * hh k := by
        have := hh_pos k
        positivity
      calc CC * zgR R * (3 / 4) ^ k = zgR R * (CC * (3 / 4) ^ k) := by ring
        _ ≤ zfR R * (1860480 * hh k) := mul_le_mul hzz hk hp (by linarith)
        _ = 1860480 * zfR R * hh k := by ring
    · rw [W0_fac h13]

theorem geo_binE (a : ℕ) (ha : a ≤ 13) (R : Bool) :
    binE (fun k => W0 k R) a ≤ CC * zgR R * ((3 / 4) ^ a * (7 / 6) ^ a) := by
  have e : ((1 + 3 / 4 : ℝ) / 2) = (3 / 4) * (7 / 6) := by norm_num
  calc binE (fun k => W0 k R) a ≤ binE (fun k => (CC * zgR R) * (3 / 4) ^ k) a :=
        binE_mono (fun k hk => le_geo k R (by omega))
    _ = CC * zgR R * ((3 / 4) ^ a * (7 / 6) ^ a) := by
        rw [binE_const_mul, binE_pow, e, mul_pow]

theorem fac_binE (a : ℕ) (R : Bool) :
    binE (fun k => W0 k R) a ≤ 32 * (1860480 * zfR R * hh a) := by
  have hz0 : 0 ≤ 1860480 * zfR R := by
    have := (zfR_bd R).1
    positivity
  calc binE (fun k => W0 k R) a ≤ binE (fun k => (1860480 * zfR R) * hh k) a :=
        binE_mono (fun k _ => le_fac k R)
    _ = 1860480 * zfR R * binE hh a := binE_const_mul _ _ _
    _ ≤ 1860480 * zfR R * (32 * hh a) := mul_le_mul_of_nonneg_left (binE_hh a) hz0
    _ = 32 * (1860480 * zfR R * hh a) := by ring

theorem geo_targets (a : ℕ) (h1 : 1 ≤ a) (h12 : a ≤ 12) (R : Bool) :
    W0 a R = CC * (3 / 4) ^ a * zgR R ∧
    W0 (a + 1) R ≤ CC * (3 / 4) ^ a * zgR R * (3 / 4) ∧
    W0 (a - 1) R ≤ CC * (3 / 4) ^ a * zgR R * (4 / 3) ∧
    binE (fun k => W0 k R) a ≤ CC * (3 / 4) ^ a * zgR R * (7 / 6) ^ a := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [W0_geo h1 h12]; ring
  · refine (le_geo (a + 1) R (by omega)).trans (le_of_eq ?_)
    rw [pow_succ]; ring
  · refine (le_geo (a - 1) R (by omega)).trans (le_of_eq ?_)
    cases a with
    | zero => omega
    | succ b =>
      simp only [Nat.add_sub_cancel]
      rw [pow_succ]; ring
  · refine (geo_binE a (by omega) R).trans (le_of_eq ?_)
    ring

theorem fac_targets (a : ℕ) (h13 : 13 ≤ a) (R : Bool) :
    W0 a R = 1860480 * hh a * zfR R ∧
    W0 (a + 1) R ≤ 1860480 * hh a * zfR R * (((a : ℝ) + 1) / ((a : ℝ) + 6)) ∧
    W0 (a - 1) R ≤ 1860480 * hh a * zfR R * (((a : ℝ) + 5) / (a : ℝ)) ∧
    binE (fun k => W0 k R) a ≤ 32 * (1860480 * hh a * zfR R) := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [W0_fac h13]; ring
  · refine (le_fac (a + 1) R).trans (le_of_eq ?_)
    rw [hh_succ]; ring
  · refine (le_fac (a - 1) R).trans (le_of_eq ?_)
    rw [hh_pred a (by omega)]; ring
  · refine (fac_binE a R).trans (le_of_eq ?_)
    ring

theorem lam_bd (a : ℕ) (h1 : 1 ≤ a) (h12 : a ≤ 12) :
    (7 / 6 : ℝ) ^ a ≤ 7 / 6 + 6 * ((a : ℝ) - 1) ∧ (7 / 6 : ℝ) ^ a ≤ 32 / 5 := by
  interval_cases a <;> norm_num

/-! ### Drift, piece by piece -/

theorem zero_false (Hf Uf : ℝ) : siteOp p0 W0 0 false Hf Uf ≤ -(1 / 2) * W0 0 false := by
  have h := siteOp_false_le W0 0 Hf Uf (CC * (1 + 2 / 10 ^ 6) * (3 / 4)) C0
    (C0 * (1 + 1 / 10 ^ 7)) C0 (by norm_num) W0_one_false.le
    (show W0 (0 - 1) false ≤ C0 from W0_zero_false.le) W0_zero_true.le
    (by rw [binE_zero]; exact W0_zero_false.le)
  rw [W0_zero_false] at h ⊢
  norm_num at h
  linarith [hCC, C0_pos]

theorem zero_true (Hf Uf : ℝ) (hU0 : 0 ≤ Uf) (hU2 : Uf ≤ 2) (hH1 : 8000000 * Uf ≤ Hf) :
    siteOp p0 W0 0 true Hf Uf ≤ -(1 / 2) * W0 0 true := by
  have h := siteOp_true_le W0 0 Hf Uf (CC * (3 / 4)) (W0 (0 + 1) false) C0
    (C0 * (1 + 1 / 10 ^ 7)) C0 (C0 * (1 + 1 / 10 ^ 7)) C0 (by norm_num) (by linarith) hU0
    W0_one_true.le le_rfl
    (show W0 (0 - 1) false ≤ C0 from W0_zero_false.le)
    (show W0 (0 - 1) true ≤ C0 * (1 + 1 / 10 ^ 7) from W0_zero_true.le)
    W0_zero_false.le
    (by rw [binE_zero]; exact W0_zero_true.le)
    (by rw [binE_zero]; exact W0_zero_false.le)
  rw [W0_zero_true] at h ⊢
  norm_num at h
  have f1 := mul_nonneg C0_pos.le (sub_nonneg.2 hH1)
  have f2 := mul_nonneg C0_pos.le hU0
  have f3 := mul_nonneg C0_pos.le (sub_nonneg.2 hU2)
  linarith [hCC, C0_pos]

theorem geo_false (a : ℕ) (h1 : 1 ≤ a) (h12 : a ≤ 12) (Hf Uf : ℝ) :
    siteOp p0 W0 a false Hf Uf ≤ -(1 / 2) * W0 a false := by
  obtain ⟨e0, e1, e2, e3⟩ := geo_targets a h1 h12 false
  obtain ⟨t0, -, -, -⟩ := geo_targets a h1 h12 true
  simp only [zgR_false] at e0 e1 e2 e3
  simp only [zgR_true, mul_one] at t0
  obtain ⟨-, hL⟩ := lam_bd a h1 h12
  have hs : 0 ≤ CC * (3 / 4 : ℝ) ^ a := by
    have := CC_pos
    positivity
  have hx1 : (1 : ℝ) ≤ a := by exact_mod_cast h1
  have hx12 : (a : ℝ) ≤ 12 := by exact_mod_cast h12
  generalize CC * (3 / 4 : ℝ) ^ a = s at *
  generalize (7 / 6 : ℝ) ^ a = L at *
  have h := siteOp_false_le W0 a Hf Uf _ _ _ _ (by omega) e1 e2 t0.le e3
  rw [e0] at h ⊢
  have := geoF_real a L s hx1 hx12 hL hs
  linarith

theorem geo_true (a : ℕ) (h1 : 1 ≤ a) (h12 : a ≤ 12) (Hf Uf : ℝ) (hH0 : 0 ≤ Hf)
    (hU0 : 0 ≤ Uf) (hU2 : Uf ≤ 2) (hH : Hf ≤ 8000000 * Uf + 1843200) :
    siteOp p0 W0 a true Hf Uf ≤ -(1 / 2) * W0 a true := by
  obtain ⟨e0, e1, e2, e3⟩ := geo_targets a h1 h12 false
  obtain ⟨t0, t1, t2, t3⟩ := geo_targets a h1 h12 true
  simp only [zgR_false] at e0 e1 e2 e3
  simp only [zgR_true, mul_one] at t0 t1 t2 t3
  obtain ⟨hL, -⟩ := lam_bd a h1 h12
  have hL1 : (1 : ℝ) ≤ (7 / 6 : ℝ) ^ a := one_le_pow₀ (by norm_num)
  have hs : 0 ≤ CC * (3 / 4 : ℝ) ^ a := by
    have := CC_pos
    positivity
  have hx1 : (1 : ℝ) ≤ a := by exact_mod_cast h1
  have hx12 : (a : ℝ) ≤ 12 := by exact_mod_cast h12
  generalize CC * (3 / 4 : ℝ) ^ a = s at *
  generalize (7 / 6 : ℝ) ^ a = L at *
  have h := siteOp_true_le W0 a Hf Uf _ _ _ _ _ _ _ (by omega) hH0 hU0 t1 e1 e2 t2 e0.le t3 e3
  rw [t0] at h ⊢
  have := geoT_real a L s Hf Uf hx1 hx12 hL1 hL hs hU2 hH
  linarith

theorem fac_false (a : ℕ) (h13 : 13 ≤ a) (ha : a ≤ 2048) (Hf Uf : ℝ) :
    siteOp p0 W0 a false Hf Uf ≤ -(1 / 2) * W0 a false := by
  obtain ⟨e0, e1, e2, e3⟩ := fac_targets a h13 false
  obtain ⟨t0, -, -, -⟩ := fac_targets a h13 true
  simp only [zfR_false] at e0 e1 e2 e3
  simp only [zfR_true, mul_one] at t0
  have hs : 0 ≤ 1860480 * hh a := by
    have := hh_pos a
    positivity
  have hx13 : (13 : ℝ) ≤ a := by exact_mod_cast h13
  have hx : (a : ℝ) ≤ 2048 := by exact_mod_cast ha
  generalize 1860480 * hh a = s at *
  have h := siteOp_false_le W0 a Hf Uf _ _ _ _ ha e1 e2 t0.le e3
  rw [e0] at h ⊢
  have := facF_real a s hx13 hx hs
  linarith

theorem fac_true_band (lo hi : ℕ) (Tb : ℝ) (hlo : 13 ≤ lo) (hhi : hi ≤ 2048) (hTb : 0 ≤ Tb)
    (q1 : (7 / 100 + 4000 / 2048) * (lo : ℝ) ^ 2 + (2430 - Tb + 42 / 100 - 4000) * (lo : ℝ)
      + 6 * (2430 - Tb) ≤ 0)
    (q2 : (7 / 100 + 4000 / 2048) * (hi : ℝ) ^ 2 + (2430 - Tb + 42 / 100 - 4000) * (hi : ℝ)
      + 6 * (2430 - Tb) ≤ 0)
    (a : ℕ) (h1 : lo ≤ a) (h2 : a ≤ hi) (Hf Uf : ℝ) (hH0 : 0 ≤ Hf)
    (hU0 : 0 ≤ Uf) (hU2 : Uf ≤ 2) (hH : Hf ≤ 8000000 * Uf + 1843200) :
    siteOp p0 W0 a true Hf Uf ≤ -(1 / 2) * W0 a true + Tb * (1860480 * hh lo) := by
  have h13 : 13 ≤ a := by omega
  have ha : a ≤ 2048 := by omega
  obtain ⟨e0, e1, e2, e3⟩ := fac_targets a h13 false
  obtain ⟨t0, t1, t2, t3⟩ := fac_targets a h13 true
  simp only [zfR_false] at e0 e1 e2 e3
  simp only [zfR_true, mul_one] at t0 t1 t2 t3
  have hs : 0 ≤ 1860480 * hh a := by
    have := hh_pos a
    positivity
  have hmono : 1860480 * hh a ≤ 1860480 * hh lo :=
    mul_le_mul_of_nonneg_left (hh_anti h1) (by norm_num)
  have hx13 : (13 : ℝ) ≤ a := by exact_mod_cast h13
  have hx : (a : ℝ) ≤ 2048 := by exact_mod_cast ha
  have hxlo : (lo : ℝ) ≤ a := by exact_mod_cast h1
  have hxhi : (a : ℝ) ≤ hi := by exact_mod_cast h2
  have hquad := quad_le (7 / 100 + 4000 / 2048) (2430 - Tb + 42 / 100 - 4000) (6 * (2430 - Tb))
    (lo : ℝ) (hi : ℝ) (a : ℝ) (by norm_num) hxlo hxhi q1 q2
  have hq : (2430 - Tb + 7 / 100 * (a : ℝ)) * ((a : ℝ) + 6)
      ≤ 4000 * ((a : ℝ) * (1 - (a : ℝ) / 2048)) := by linarith
  generalize 1860480 * hh a = s at *
  have h := siteOp_true_le W0 a Hf Uf _ _ _ _ _ _ _ ha hH0 hU0 t1 e1 e2 t2 e0.le t3 e3
  rw [t0] at h ⊢
  have := facT_real a s Hf Uf Tb hx13 hx hs hU2 hH hq
  have := mul_le_mul_of_nonneg_left hmono hTb
  linarith

theorem drift0 (a : ℕ) (R : Bool) (Hf Uf : ℝ) (ha : a ≤ 2048) (hU0 : 0 ≤ Uf) (hU2 : Uf ≤ 2)
    (hH1 : 8000000 * Uf ≤ Hf) (hH2 : Hf ≤ 8000000 * Uf + 1843200) :
    siteOp p0 W0 a R Hf Uf ≤ -(1 / 2) * W0 a R + b0 := by
  have hb : 0 ≤ b0 := by unfold b0; norm_num
  have hH0 : 0 ≤ Hf := by linarith
  cases R
  · rcases Nat.eq_zero_or_pos a with rfl | h1
    · linarith [zero_false Hf Uf]
    · rcases Nat.lt_or_ge a 13 with h12 | h13
      · linarith [geo_false a h1 (by omega) Hf Uf]
      · linarith [fac_false a h13 ha Hf Uf]
  · rcases Nat.eq_zero_or_pos a with rfl | h1
    · linarith [zero_true Hf Uf hU0 hU2 hH1]
    · rcases Nat.lt_or_ge a 13 with h12 | h13
      · linarith [geo_true a h1 (by omega) Hf Uf hH0 hU0 hU2 hH2]
      · rcases Nat.lt_or_ge a 766 with c1 | c1
        · exact (fac_true_band 13 766 0 (by norm_num) (by norm_num) (by norm_num)
            (by norm_num) (by norm_num) a h13 (by omega) Hf Uf hH0 hU0 hU2 hH2).trans
            (by have : (0 : ℝ) * (1860480 * hh 13) ≤ b0 := by rw [zero_mul]; exact hb
                linarith)
        rcases Nat.lt_or_ge a 860 with c2 | c2
        · exact (fac_true_band 766 860 186 (by norm_num) (by norm_num) (by norm_num)
            (by norm_num) (by norm_num) a c1 (by omega) Hf Uf hH0 hU0 hU2 hH2).trans
            (by have : (186 : ℝ) * (1860480 * hh 766) ≤ b0 := by unfold hh b0; norm_num
                linarith)
        rcases Nat.lt_or_ge a 934 with c3 | c3
        · exact (fac_true_band 860 934 334 (by norm_num) (by norm_num) (by norm_num)
            (by norm_num) (by norm_num) a c2 (by omega) Hf Uf hH0 hU0 hU2 hH2).trans
            (by have : (334 : ℝ) * (1860480 * hh 860) ≤ b0 := by unfold hh b0; norm_num
                linarith)
        rcases Nat.lt_or_ge a 1019 with c4 | c4
        · exact (fac_true_band 934 1019 504 (by norm_num) (by norm_num) (by norm_num)
            (by norm_num) (by norm_num) a c3 (by omega) Hf Uf hH0 hU0 hU2 hH2).trans
            (by have : (504 : ℝ) * (1860480 * hh 934) ≤ b0 := by unfold hh b0; norm_num
                linarith)
        rcases Nat.lt_or_ge a 1156 with c5 | c5
        · exact (fac_true_band 1019 1156 778 (by norm_num) (by norm_num) (by norm_num)
            (by norm_num) (by norm_num) a c4 (by omega) Hf Uf hH0 hU0 hU2 hH2).trans
            (by have : (778 : ℝ) * (1860480 * hh 1019) ≤ b0 := by unfold hh b0; norm_num
                linarith)
        rcases Nat.lt_or_ge a 1496 with c6 | c6
        · exact (fac_true_band 1156 1496 1461 (by norm_num) (by norm_num) (by norm_num)
            (by norm_num) (by norm_num) a c5 (by omega) Hf Uf hH0 hU0 hU2 hH2).trans
            (by have : (1461 : ℝ) * (1860480 * hh 1156) ≤ b0 := by unfold hh b0; norm_num
                linarith)
        · exact (fac_true_band 1496 2048 2574 (by norm_num) (by norm_num) (by norm_num)
            (by norm_num) (by norm_num) a c6 ha Hf Uf hH0 hU0 hU2 hH2).trans
            (by have : (2574 : ℝ) * (1860480 * hh 1496) ≤ b0 := by unfold hh b0; norm_num
                linarith)

/-! ### Size of the potential -/

theorem W0_nonneg (a : ℕ) (R : Bool) : 0 ≤ W0 a R := by
  have h1 := C0_pos
  have h2 := CC_pos
  have h3 := hh_pos a
  have h4 : 0 < zgR R := by linarith [(zgR_bd R).1]
  have h5 : 0 < zfR R := by linarith [(zfR_bd R).1]
  unfold W0
  split_ifs <;> positivity

theorem W0_fac_le (lo a : ℕ) (h13 : 13 ≤ lo) (h : lo ≤ a) (R : Bool) :
    W0 a R ≤ 1860480 * (1 + 9 / 10 ^ 6) * hh lo := by
  rw [W0_fac (by omega)]
  exact mul_le_mul (mul_le_mul_of_nonneg_left (zfR_bd R).2 (by norm_num)) (hh_anti h)
    (hh_pos a).le (by norm_num)

theorem W0_le (a : ℕ) (R : Bool) : W0 a R ≤ 80 := by
  have hC := CC_pos
  have hchi := CC_hi
  have hcc := hCC
  have hC0 := C0_pos
  rcases Nat.eq_zero_or_pos a with rfl | h1
  · cases R
    · rw [W0_zero_false]; nlinarith
    · rw [W0_zero_true]; linarith
  · rcases Nat.lt_or_ge a 13 with h12 | h13
    · rw [W0_geo h1 (by omega)]
      obtain ⟨hz1, hz2⟩ := zgR_bd R
      have hp : (3 / 4 : ℝ) ^ a ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
      have hp0 : (0 : ℝ) ≤ (3 / 4 : ℝ) ^ a := by positivity
      have hcz : CC * zgR R ≤ 791 / 10 * (1 + 2 / 10 ^ 6) :=
        mul_le_mul hchi.le hz2 (by linarith) (by norm_num)
      have hcz0 : 0 ≤ CC * zgR R := by nlinarith
      calc CC * zgR R * (3 / 4) ^ a ≤ CC * zgR R * 1 := mul_le_mul_of_nonneg_left hp hcz0
        _ ≤ 80 := by linarith
    · refine (W0_fac_le 13 a le_rfl h13 R).trans ?_
      unfold hh; norm_num

theorem W0_ge_one (a : ℕ) (R : Bool) (ha : a < 16) : 1 ≤ W0 a R := by
  have hC := CC_pos
  have hC0 := C0_lo
  rcases Nat.eq_zero_or_pos a with rfl | h1
  · cases R
    · rw [W0_zero_false]; linarith
    · rw [W0_zero_true]; nlinarith
  · rcases Nat.lt_or_ge a 13 with h12 | h13
    · rw [W0_geo h1 (by omega)]
      have hz1 := (zgR_bd R).1
      have h12v : (1 : ℝ) ≤ CC * (3 / 4) ^ 12 := by unfold CC hh; norm_num
      have hpow : (3 / 4 : ℝ) ^ 12 ≤ (3 / 4) ^ a :=
        pow_le_pow_of_le_one (by norm_num) (by norm_num) (by omega)
      have hp0 : (0 : ℝ) ≤ CC * (3 / 4 : ℝ) ^ a := by positivity
      calc (1 : ℝ) ≤ CC * (3 / 4) ^ 12 := h12v
        _ ≤ CC * (3 / 4) ^ a := mul_le_mul_of_nonneg_left hpow hC.le
        _ ≤ zgR R * (CC * (3 / 4) ^ a) := le_mul_of_one_le_left hp0 hz1
        _ = CC * zgR R * (3 / 4) ^ a := by ring
    · rw [W0_fac h13]
      have hz1 := (zfR_bd R).1
      have h15 : (1860480 : ℝ) * hh 15 = 1 := by unfold hh; norm_num
      have hm : hh 15 ≤ hh a := hh_anti (by omega)
      have hp0 : (0 : ℝ) ≤ 1860480 * hh a := by
        have := hh_pos a
        positivity
      calc (1 : ℝ) = 1860480 * hh 15 := h15.symm
        _ ≤ 1860480 * hh a := mul_le_mul_of_nonneg_left hm (by norm_num)
        _ ≤ zfR R * (1860480 * hh a) := le_mul_of_one_le_left hp0 hz1
        _ = 1860480 * zfR R * hh a := by ring

/-! ### The certificate -/

theorem cert0 : SiteCert p0 16 W0 (1 / 2) b0 80 where
  nonneg := W0_nonneg
  le_max := W0_le
  ge_one := W0_ge_one
  drift := by
    intro a R Hf Uf ha hU0 hU hH1 hH2
    have ha' : a ≤ 2048 := ha
    have hU2 : Uf ≤ 2 := by
      have h : Uf ≤ ((3 : ℕ) : ℝ) - 1 := hU
      norm_num at h
      linarith
    have hH1' : (8000000 : ℝ) * Uf ≤ Hf := hH1
    have hH2' : Hf ≤ 8000000 * Uf + 1843200 := by
      have h : Hf ≤ (8000000 : ℝ) * Uf + 800 * ((2048 : ℕ) : ℝ) * (9 / 16) * (((3 : ℕ) : ℝ) - 1) :=
        hH2
      norm_num at h
      linarith
    exact drift0 a R Hf Uf ha' hU0 hU2 hH1' hH2'

theorem W0_ready : ∀ a R, 512 ≤ a → W0 a R ≤ 6 / 10 ^ 8 := by
  intro a R h
  refine (W0_fac_le 512 a (by norm_num) h R).trans ?_
  unfold hh; norm_num

theorem b0_le : b0 ≤ 5 / 10 ^ 6 := by
  unfold b0; norm_num

end

end FunctionalCapacity
