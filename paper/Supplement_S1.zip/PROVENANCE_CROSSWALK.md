# Mathematical source crosswalk

The research article presents the complete catalytic-population and majority-restoration arguments as its contributions. Their earlier private development manuscripts are provenance, not external prior literature. The retained citations ref9/ref10 resolve explicitly to S1.1/S1.2.

- S1.1: internal P161 v4; original SHA256 731042cdc927f7af7d6c11d9d6f559f8be66944d5e9d61bcc5e511e346b8624f; supplied mathematical source edition SHA256 504067023fdfadc29b2419f49293dcc81fa76344618497a33b20713e51444fe0. Its previously reviewed edits concern navigation/optional schematic links. Full comparison proof support remains supplied.
- S1.2: internal P118; original and supplied source SHA256 e2532ee3239290bffb9a4d09af06cde5b65fd74f347ff2cf68bcce7d31eec796. The complete conventional proof is integrated in Appendix D.
- The contextual random-division proposition is a self-contained restricted form of the independent-unit, symmetry/erasure converse developed in Reliable inheritance under random division (internal P113). The article includes its complete assumptions and proof, including conditional daughter/branch independence. No broader material-ranking, arbitrary-partition or deadline theorem is imported. The broader companion need not be published to support the displayed proof.

The fixed public formal source is identified in README.md. It supports the central full beta4m finite-stock theorem; it does not turn all restoration, operating-comparison or programme claims into newly formalized results. No indispensable mathematical input is hidden behind provenance redaction, and no accepted source or historical receipt is changed.
