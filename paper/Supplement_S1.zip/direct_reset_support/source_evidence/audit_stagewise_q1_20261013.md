# Independent audit: four-stage complete q1 bound

Status: ACCEPTED. This is a bound for the ENTIRE exactly-one-division cap-killed contribution at T=.1, not just one time lane. It may replace both earlier q1 allocations. The high-last-parent multi-division sector and original full gate remain open.

## Result and completed independent run

The exact four-stage reset/witness calculation, profile comparisons, integrated constants, and final rational pricing were frozen and independently rerun. Every assertion passed. All four rebuilt stage-profile exports, reset constants, and final result hashes match the worker's manifest byte for byte.

The accepted bound is

q1_cap(.1)≤30656075057/10^15=0.000030656075057.

It covers all division times in[0,.1], basal and triggered division channels, every permitted initial floor16 count state, and arbitrary initial shared fuels. Original first Ready and first floor failure remain absorbing throughout.

The stage-profile constructor is byte-identical to the earlier independently audited joint-profile certificate. This was checked directly. Its original physical generator inequalities are reused; rounded profile exports are not substituted as new generator supersolutions.

## Actual stage reset operator

Fix a stage cap C. All three counts of a parent are at most C. Its true total rate is d_i=1+R_iΣ_j a_ij/N. For a selected coordinate a,

d_i≤p_C(a,R_i)=1+R_i(2C+a)/N,
and d_i≤1+3C/N.

The two complementary daughter values for a coordinate have expectation at most2M_C(a), where

M_C(a)=E[h_C(K,0)1{16≤K≤a−16}], K~Bin(a,1/2).

Fuel0 dominates either actual daughter fuel pointwise. The paired-floor interval retains complementarity. Dropping the other species' floor conditions and postdivision Ready killing only increases the nonnegative bound. No independent sister or coordinate-dynamics assumption is introduced.

A fixed retained site has three other possible parents, with victim avoidance probability2/3 for each. Thus its retained coefficient is at most

r_C=(2/3)·3·(1+3C/N)=2+6C/N.

The true positive division operator on cap-live prestates therefore satisfies

B_C U_C≤r_C U_C+Σ_ij y_C(a_ij,R_i),
y_C(a,R)=2p_C(a,R)M_C(a).

Parent rates remain prestate/fuel dependent until these pointwise bounds. Shared fuel within a site is not replaced by independent coordinate fuel. Daughter counts cannot exceed the parent's counts, so an above-cap daughter cannot be produced from an in-cap parent at that absolute time. Floor/Ready-killed poststates contribute zero; ignoring their killing in the upper calculation is conservative.

## NonReady witness and rounding direction

Every original live nonReady prestate has at least one coordinate≤511. This witness applies BEFORE the division; it does not assert that poststates remain nonReady without killing.

For each count/fuel row the script uses an upper y and x=max(0,h_upper−10^−18)≤actual h. Exact binomial sums on upward18-decimal h values upper-bound M_C. It verifies, after rounding d_C upward at10^−9,

max_(a≤511,R)(y−d_C x)+11max_(a≤C,R)(y−d_C x)≤0.

Choose any actual deficient coordinate for the first term and the other11 for the second. Then Σy≤d_CΣx≤d_CU_C, since d_C≥0. The relaxation allows more count/fuel combinations than physically possible, which can only make the upper bound larger.

The finite active-row iteration is not itself an assumption: the final all-row residual inequality is checked with exact rational arithmetic. No pointwise one-coordinate inequality y≤d_Ch is incorrectly claimed; the global nonReady witness is essential.

The resulting full reset constants C_s=r_C+d_C are:

- cap2048: 95467565097/200000000=477.337825485;
- cap1600: 207495662441/500000000=414.991324882;
- cap1504: 79789186207/200000000=398.945931035;
- cap1408: 96165604259/250000000=384.662417036.

These are true B_sU_s≤C_sU_s bounds on each original live cap domain. The active rows511/fuel1 and788 or789/fuel1 are constraints of the relaxation, not claims of equality for the physical full state or reset law.

## Exactly-one-word composition and one profile jump charge

Let P_j(0,t) be the actual cap-killed law with exactly j divisions and m_j(t)=P_j(0,t)U_t. The absolute cap times are.02,.04,.07; they are not reset at a division. On each stage,

m0'≤−γ_t m0,
m1'≤−γ_t m1+C_t m0,
γ_t=ρ_t+4−12/4700.

At a cap/profile transition both m0 and m1 satisfy the SAME comparison m_j(t+)≤J_t m_j(t−). States excluded by the tighter cap are killed. There is no division-gain term at a deterministic cap change.

Define k(t)=exp(−∫_0^t γ_s ds) times the product of already-crossed profile factors. Then m0/k≤U_initial, and between transitions

(m1/k)'≤C_t(m0/k)≤C_t U_initial.

Neither normalized quantity jumps upward at a transition. Since m1(0)=0,

m1(T)≤U_initial k(T)∫_0^T C_s ds.

The sole factor J1=1001764506893/10^12 is therefore paid ONCE along the entire one-division word. It is not separately charged to a restarted prefix and suffix. The proof is equivalently a positive Duhamel integral whose prefix and suffix cross disjoint sets of stage boundaries.

Because U_T≥1 on every live terminal nonReady state, q1_cap(T)≤m1(T). This is a potential-valued bound; it does not multiply the actual scalar q0 probability by a reset rate.

## Exact numerical pricing

The independently reproduced constants are

Gamma=679849/23500,
∫_0^.1 C_s ds=4135483344947/10^11=41.35483344947,
U_initial≤338971453059/125000,
J_total=1001764506893/10^12.

The bound J_total·Umax·(∫C)/exp(Gamma) is evaluated using the positive121-term rational Taylor LOWER bound for exp(Gamma), followed by an upward ceiling at10^−15. This gives30656075057/10^15. There is no floating arithmetic in the certificate, apart from diagnostic elapsed time.

## Scope of replacement and global cap risk

The separately confirmed global cap theorem covers the full marked process, including divisions, with the same absolute schedule and P(Kcap^c)<1/200000000. Therefore

P(bad)≤P(Kcap^c)+Σ_n P(bad, exactly n divisions, Kcap).

The new theorem directly bounds the ENTIRE n1 summand. It replaces BOTH old q1 time lanes and their within-q1 comparison allowances; they are not added to the new q1 result. The single global cap charge and unrelated error allocations remain untouched.

Using the parent-supplied old combined q1 allowance19/80000=.0002375, the exact released allowance is206843924943/10^15=.000206843924943. Adding this to the previously certified remaining allowance8068741291/10^15 gives214912666234/10^15=.000214912666234 for the remaining early-first high-last-parent sector after the accepted complete low-parent bound. The subtraction/addition were checked exactly. The original old-lane allocation is supplied by the parent; its old source proof need not be reused to establish this new theorem.

No change is made to the physical model, T=.1, floor16, Ready threshold512, or target1/2500. No bound for the remaining high-parent2…5-division sector is claimed here.

## Frozen reproducibility

Directory: `audit_frozen_q1_20261013/`.

- Theorem SHA-256: `714dd6d12d46624ed83959a071ef0a2c996bc4e321bf86748d9914b8d328637e`.
- Exact script SHA-256: `73acc0c43cee75b6c3b5ef495fc5139e029023e6d97500a56855164d149b537b`.
- Rebuilt reset constants SHA-256: `bd7a5b38df771cce413bec381176f0c068a2946b44b3176a16f76aa4f003b829`.
- Rebuilt final result SHA-256: `ef9951b692cb7bc186bd0584495768b781cea89359937ce614586d959533cecd`.

The complete manifest, all four rebuilt stage profile exports, and original band dependencies are frozen alongside these files. All output hashes match the manifest.
