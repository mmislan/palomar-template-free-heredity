# Independent audit of the complete seed withdrawal mission

## Decision

**ACCEPTED as a complete additive analytical corollary for the stated switched physical model.** The deterministic seed withdrawal, seed-on acquisition, postwithdrawal retention, fixed-grid service, actual division and whole-population recovery sequence, state-dependent reset clock, all resource ceilings, and finite-stock coupling compose correctly. No mathematical correction to the final candidate's constants or theorem is required.

Acceptance applies specifically to `SEED_WITHDRAWAL_HEREDITY_COROLLARY_20261013.md`, SHA-256 `78d24151b403781f272fc1d0995acf5629878565d9b1f843bf5e169aa31249a9`. Its byte-identical snapshot is retained with this review. The final frozen author manifest, SHA-256 `f4763679fc9be896bf9cb40b224b1009842bac484143989a2deee3dff179e772`, and its file hashes are independently verified.

**Status restriction:** this is an independent mathematical and exact-arithmetic review of the complete corollary, relying on the accepted source model and original exact-profile enclosures. It is not a new Lean compilation, producer acceptance, canonical adoption, or empirical demonstration. This review changes no producer artifact.

**Scientific restriction:** the inheritance result is finite-horizon transmission and maintenance of a categorical catalyst repertoire. It is not compositional-ratio fidelity, molecular genealogy, open-ended heredity, selection among variants, or ten generations along a named lineage.

## The accepted statement

Use four fixed spatial sites, three catalyst species, count cap 2048 per coordinate, alpha 800, and beta 4,000,000 simultaneously for recharge, discharge, and every ordinary consuming job. The two old species initially have at least 512 copies at every site. Candidate counts may be arbitrary from zero through 2048; fuel bits are arbitrary. Service and resource counters begin at zero without changing those physical inventories.

Change exactly one physical coefficient: each coordinate's seed intensity is `6(1-a/2048)` for `t<30` and zero for `t>=30`. This cutoff is deterministic and occurs on every realization, whether or not acquisition succeeded. All other literal propensities, the uniform distinct victim, full complementary split law, fuel allocation, and actual marked-division counting are retained.

With probability at least

`995482024309927807 / 10^18 = 0.995482024309927807`, 

all of the following hold jointly in the finite-stock switched realization:

- Both old species stay at least 16 at every site through time 60.
- The candidate is at least 16 at every site at time 30 and stays so through time 60.
- Every original individual quota of 500 credits per required site/species in every fixed 0.1 block is met. There are 2,400 old-species quotas before 30 and 3,600 all-species quotas afterward, totaling 3,000,000 credits by time 60.
- Every spatial site initiates at least five actual divisions during the established phase.
- The source's ten successive actual-division/whole-population Ready512 renewals finish by 55.5, using eleven recovery allowances of 0.5 and ten first-division waits of 2.
- Every complete established-phase division gives both actual daughters at least 16 copies of each required catalyst by partition of the parental predivision inventory. Each parent therefore has at least 32 copies of each species before that division.
- Accepted feed is at most 800,000,000, accepted seeds at most 5,000, and actual marked divisions at most 1,200. All stated gross resource ceilings below hold without replenishment at the cutoff, grid boundaries, or recovery starts.

The complement is bounded by the advertised complete failure allowance

`4517975690072193 / 10^18 = 0.004517975690072193`.

The renewal deadline 55.5 and the service deadline 60 have different meanings and must remain distinct in the paper.

## Provenance and scope of independent work

The source audit directly read the literal `siteOp`, `SiteCert`, `RetCert`, service and mission extractions; the full G60 event; the validity/resource and exact Cstar/SR3 extractions; the generic composition and stopping-time source; the historical physical/recovery manuscript; the accepted lower-rate audit; the reciprocal branching and recovery proofs; and the generalized ordinary-credit tilt proof and independent review. Their local hashes are in `SOURCE_DEPENDENCIES_SHA256.json`.

I also read the independent retention/G60 and recovery/resource reports in the submitted packet, including their assembly readbacks. Those reports are corroboration, not a substitute for the derivations below. The new checker imports or executes none of the author or component-review code. It separately implements:

- 16,392 seed-on all-count branching rows;
- 16,264 seed-free live-region full branching rows;
- direct binomial daughter-sum crosschecks at 17 counts;
- 4,066 seed-free recovery rows and the corresponding seed-on inequalities;
- pointwise exact-profile comparisons and all new reset-transfer constants;
- a fresh 4,066-row reconstruction of the original intrinsic2048 paired-reset inequality from its outward profile enclosure;
- 4,066 ordinary-credit service-envelope rows;
- all clock, probability, deadline, resource and gross-stock arithmetic;
- all allowed complementary count splits as an additional finite check of the immediate-inheritance implication.

The original band Dirichlet solves and the provenance of their accepted sub512 exact-profile enclosure are inherited inputs, not recomputed here. The exact old tail is reconstructed and independently checked against the enclosure. The supplied upstream Lean/source excerpts are read as the source contracts; no desktop retrieval or compiler run is represented by this review.

The initially requested proof digest `7a744d2a703fc9d31bdcbded34af9c0a8efbf590909683ea88dd95a58b8c4349` was superseded while the author assembled the packet. This review initially read `0c6e76755a1896e43c3d425339a846c78497d73de3556664e3c4897d436a24ee`, then pinned and reread the final `78d24151...` version. The final proof expressly includes deterministic unconditional withdrawal and the two important assembly clarifications: recovery is proved first on the unlimited-stock switched law, and each restart estimate is restricted by a currently admissible completed-start indicator as well as preceding success and prior floor survival. Acceptance is attached only to the final pinned version.

## Literal physical law and the deterministic switch

At selected count `a` and shared fuel `R`, the physical channels remain:

- seeds at `epsilon(t)(1-a/N)`, preserving fuel;
- passive death at `a`, preserving fuel;
- active birth at `800 R a(1-a/N)`, clearing fuel;
- active death at `400 R a`, clearing fuel;
- ordinary job at `beta R a/N`, clearing fuel;
- recharge at `beta` when fuel is empty and discharge at `beta` when occupied;
- basal division at rate one per parent site;
- triggered division at rate `R_i a_ij/N` for each triggering species.

All ordinary jobs remain active during acquisition and recovery. External service counters are spatial ledgers; a division does not overwrite or partition them.

A division selects a different victim uniformly, draws the source joint split mark, and replaces parent and victim by `K` and `a_parent-K`. The species splits have the source conditional binomial law, and the fair fuel-allocation bit is independent of the complete split vector. The two sisters themselves are complementary. A basal division conserves the parent's total fuel across its daughters and loses the victim's previous fuel. A triggered division first consumes parental fuel; both daughters then have zero fuel and total loss is `1+R_v`. State-null marked divisions still count.

Both phases satisfy the written parameter-validity conditions. Their uniformization envelopes are 93,515,864 and 93,515,792. A common rate 93,515,864 and time-dependent channel thinning constructs the switched process without ambiguity. The deterministic cutoff has no physical mark almost surely, changes no inventory or counter, and has no boundary atom to charge. Its convention at the single time 30 does not change the law. The process agrees exactly with the accepted seed-on law through time 30; it is not coupled monotonically with that law afterward.

## Full branching retention and acquisition

The candidate uses the accepted beta-dependent weight, not the old fixed-beta8m weight. With

`A(a)=C(3/4)^a` through 12 and `A(a)=1860480/[(a+1)...(a+5)]` afterward,

`C=1275068416/16120377`, `g(0)=-A(0)/2`, and `g(a)=A(a)min(6a,70)` for positive `a`, set

`W(a,1)=A(a)`, `W(a,0)=A(a)+g(a)/4000000`.

All-natural positivity, the upper bound 80, the below16 barrier, and the prepared512 bound follow from the exact finite seam checks and the eventual successive ratio `(a+1)/(a+6)`. Thus these properties are not inferred just from the physical interval through 2048. In particular `W(15,1)=1` and `W(512,0)<6/10^8`.

The checker evaluates the literal complete branching operator with all chemical terms and full binomial daughter gains. It imposes no artificial zero boundary at 16 and no Ready killing. The daughter moments follow from the beta integral and finite prefix corrections; complete rational binomial sums provide a separate crosscheck.

The actual foreign loads satisfy `Hf=beta Uf+v`, with `0<=Uf<=2` and `0<=v<=1843200`. The operator is affine in these variables, so the four corners cover the entire admissible rectangle, including every realizable foreign state. All 16,392 seed-on rows satisfy

`siteOp_6 W <= -W/2+b0`, where `b0=13/10^7`.

All 16,264 seed-free live rows, counts 16 through 2048, satisfy the same stronger contraction. The seed-free maximum of `siteOp_0 W+W/2` is strictly between `0.000000899768126927` and `0.000000899768126928`, at count 951, fuel one, and the largest foreign-load corner. The maximum of `siteOp_0 W` is below `0.000000898590912646`. Both are below `b0`.

This is a legitimate post30 RetCert. It is not a seed-free all-count SiteCert: at count zero and empty fuel, `siteOp_0 W=C/2=637534208/16120377`, vastly above `b0`. A species absent from the whole population also cannot be recreated by the remaining channels. Acquisition must therefore be supplied by the seed-on phase.

To pass from site rows to the physical population, define `Phi_j=sum_i W(a_ij,R_i)`. In the sum over all basal parents, each uniform-victim loss contributes one additional copy of each site's weight. Thus the basal aggregate is exactly the two daughter gains minus `2W`. For triggers, both daughters are fuel zero; dropping the additional nonpositive victim-weight loss gives the source upper bound. This uses the correct sister marginals but no false sister independence. Consequently the population drift is at most the sum of the source site operators.

For the two old species, stop their summed potential at the first complete floor violation. Before that stop, the rate is at most `8b0` in both phases. At the violating terminal mark its value is at least one. The bounded stopped Dynkin estimate gives

`P(old floor failure by 60) <= 48/10^8+480b0`.

This is retained-terminal barrier stopping, not killing the weight at exit. No post-exit drift assertion is used. Foreign candidate counts may be arbitrary.

For the candidate, the genuine all-count seed-on contraction first gives

`E Phi_candidate(30) <= 320 exp(-15)+8b0(1-exp(-15))`.

From 30, stop on the first candidate floor violation, with stop equal to 30 if it is already belowfloor then. The live seed-free drift is at most `4b0`; the same terminal barrier gives

`P(candidate acquisition or later floor failure) <= 320 exp(-15)+128b0`.

This integrates over the actual arbitrary time30 distribution. It neither assumes Ready512 at 30 nor conditions the post30 law on successful acquisition or future G60. Both old and candidate floor costs total

`48/10^8+320 exp(-15)+608b0`.

## Fixed-grid service and the complete switched G60 event

For one ordinary-credit ledger use

`Y=z^Q[rho if fueled, otherwise 1]`, `z=3/4`, `rho=79967/80000`, `theta=1650`.

Seeds and passive events preserve this potential. In empty fuel, recharge contributes `-beta(1-rho)z^Q`; incoming replacement can only preserve or decrease it. With fuel occupied, the selected ordinary job contributes `beta(a/N)(z-rho)z^Q`. Discharge, the other two jobs, all active chemistry, and every touching division have total positive envelope

`Hs(1-rho)z^Q`, `Hs=14764808`.

The touching-division bound is eight: at most four own initiations and at most four incoming-victim events. It includes arbitrary donor states and both sister/fuel laws. The active pair is bounded by `800N(9/16)` per species. No division-coupled credit is used, making the ordinary-credit event stronger than the source's quota event.

Exactly,

`beta(1-rho)=1650`,

`beta(16/N)(z-rho)+Hs(1-rho)+theta rho=-598067/10000<0`.

Since `z-rho<0`, the fueled inequality improves at larger live counts. Killing this nonnegative service potential on a complete required-floor exit only lowers its generator. The killed marked tilt therefore gives

`P(D>0.1, Q<500 | exposed live block-start history) <= rho^-1 z^-500 exp(-165)`.

The fixed physical state is finite; the external ledger is unbounded. The argument can be stated precisely as a finite-dimensional marked/tilted semigroup or as a localized additive-counter exponential supermartingale. It does not require a falsely finite augmented ledger space.

The sum over at most twelve required coordinates is below `1948303823/250000000000000000<10^-8`. Each block is wholly within one phase. Multiply at each block start by a past-measurable live-start/successful-prefix indicator and average. Only afterward use event inclusion: on the global floor-good event, every relevant start is live and the block survives. This does not condition a future law on G60. All 600 fixed blocks cost at most `600*10^-8`.

Each site's unchanged basal initiation clock has rate one during the 30-unit established interval. The deficit below five initiations is at most `6^4 exp(-25)` per site, hence `5184 exp(-25)` overall. Basal counts are dominated by actual initiation counts. No independence from chemistry, service, floors, or recovery is required.

The direct complete G60 allocation is

`48/10^8+320/2900000+608b0+600/10^8+5184/10^10`

`=8226423/9062500000`.

The advertised allowance `9545923/9062500000` is larger by exactly `112b0=91/625000`, so it remains valid. The weaker advertised number is deliberately retained. There is no unsupported application of the source's homogeneous `mission_lower` or its hard-coded half-credit tilt to the new switched law.

## Seed-free recovery and the reset operator

Use the literal rational upper export below512 to define the new profile, with the accepted exact tail reconstructed at and above512. The old exact sub512 entries are enclosed between the export minus `10^-18` and the export; they are not identified with the rounded entries. At beta4m the fueled value is `A-(11/8)Delta`. The original seed6-derived tail correction is left fixed when the physical seeds are removed.

The new checker independently expands the seed-free chemical rows, retaining the destination fuel clearing of both active birth and active death. At every count 16 through 2048 and both fuels,

`(G0+150)h<=0` below512,

`(G0+150)h<=1/4700` at and above512.

All 4,066 rows pass, including the floor, 511/512 join, 768 junction, high-count returns, and upper cap. Nuisance consumption is dominated because `T_beta(z)=800z(1-z/N)+400z+beta z/N` is increasing on `[0,N]`, and the profile is fuel ordered. This is a statewise comparison for arbitrary nuisance histories.

Seed withdrawal is not justified by profile monotonicity. The seed-generator term is positive in four rows, negative in 4,060, and zero in two. The direct rows are essential. The least source-adjusted seed-free decay ratios occur at count807/fuel0 and count16/fuel1 and exceed 152.250105916809082940 and 471.362280546028176897 respectively.

Positivity, the below512 barrier, and the maximum give `U=sum h>=1` on a live nonReady population and `U<=338971453059/125000`. On all physical counts/fuels the exact comparisons give

`(9997/10000)h_old<=h<=(10000/9999)h_old`.

The actual positive live-postdivision reset operator is pointwise unchanged: seeds are not divisions, and rates, victims, complementary split marks, prestate fuel, and global Ready/floor killing are identical. This remains true although the process visits states with a different distribution after withdrawal.

I independently reconstructed the old intrinsic2048 paired-reset bound from the outward profile grid. With `d=93867565097/200000000`, the deficient-coordinate maximum is at count511/fuel1; the unrestricted maximum is at count788/fuel1. Their combination `max_deficient+11 max_all` has an outward upper bound `-183951379/250000000000000000<0`. The retained-site contribution is at most eight. Thus the original `C_old=95467565097/200000000` bound is reverified, conditional only on the accepted profile enclosure.

By positivity of that same operator,

`B_div U <= [(10000/9999)/(9997/10000)] C_old U <478U`.

Removing resets and retaining them as killing contributes at least four. Original global boundary killing only decreases the nonnegative potential. Hence

`Q0 U <= -gamma U`, `gamma=150+4-12/4700=180947/1175`.

No individual count crossing512 restarts the recovery word. Simultaneous Ready and complete floor violation are the original boundaries.

## State-dependent fuel clock and stopping histories

Let `F=sum R_i`, `Z=sum_i R_i sum_j a_ij/N`, and actual reset intensity `nu=4+Z`. Every physical consuming channel gives

`LF=beta(4-2F-Z)-A_active-D_fuel`,

`A_active>=400NZ`, `D_fuel>=0`, `Z<=3F`, `0<=F<=4`.

Seeds have zero fuel increment, so this identity survives withdrawal. With

`kappa=3/22457600`, `a_clock=4+4beta kappa`,

`nu-a_clock<=-kappa LF`.

The conservative drift residual is exactly `(2beta kappa/3)(3F-Z)>=0`. All fuel jumps have magnitude at most two. The variation-density bound is

`V=20beta+5400N+64=91059264`.

Recharge, discharge, every ordinary job, all active pairs, and both basal/triggered victim losses are paid. Stopping retains actual terminal fuel. An artificial zero-fuel cemetery jump would invalidate this argument and is not used.

The compensated fuel martingale yields an upper bound on the random reset compensator. Bounded-jump exponential control bounds its excess. For the actual correlated time change `N_T=Y(Lambda_T)`, the inclusion

`{N_T>=K, Lambda_T<=m} subset {Y(m)>=K}`

is pathwise. It does not require independence of the clock and its Poisson primitive.

At `T=1/2`, `K=14`, `delta=1/100`, `theta_clock=1/640`, the actual clock exponent is `28228801/460320` and comparison mean `1080309/350900`. They dominate the accepted conservative exponent `9141301/460320` and mean `321/100` in the correct directions. The low words zero through thirteen and the at-least-fourteen clock sector exhaust surviving nonreturn.

Independent outward Taylor bounds reproduce

`q_off(1/2)<=8622092430140/10^18<1/100000`.

The three raw rational terms are summed before rounding. The sum of separately rounded component ceilings is one unit at `10^-18` larger and is not confused with the once-rounded total.

The whole switched process is time inhomogeneous, but the shifted process after deterministic time30 has a homogeneous seed-free generator. Conditional on the full natural marked history through30, fresh increments and unseen marks construct that process from its completed current state. The source strong Markov argument therefore applies at every subsequent finite stopping time, including all actual first-division times. Earlier history, grid position, and cumulative counters carry through. There is no future-event conditioning and no resumption of a previously absorbed local chain.

All recovery estimates are first proved on the unlimited-stock switched process. Its physical rates do not depend on cumulative resource counters. Finite stocks are handled by the later whole-mission coupling; one must not assert an unqualified physical restart law after stock exhaustion.

## Renewal composition and failure accounting

Let `tau0` be the first simultaneous Ready512 time at or after30. Let `sigma_r` be the first actual division strictly after `tau_(r-1)`, and `tau_r` the first simultaneous Ready512 time at or after the complete `sigma_r` mark. A recovery already Ready is immediate. A belowfloor start is inadmissible.

For each exposed recovery start, multiply the conditional estimate by the indicator of preceding success, no prior relevant floor failure, and current completed-state admissibility. These are measurable at the start. For a late recovery intersected with complete G60, the local floor cannot have failed before the deadline, so that intersection is contained in the local surviving-nonreturn event. This is the correct event inclusion; it does not replace `P(H>h,D>h)` by unconditional `P(H>h)`.

Successful-prefix induction puts all relevant deadlines before60, since

`tau10<=30+11(1/2)+10(2)=55.5`.

This induction is needed even when analyzing the first failed episode: its attempted deadline is still within the protected interval on the preceding-success history. The first actual division is no later than the next one of the four basal firings. Thus each wait failure has conditional probability at most `exp(-8)`. State-null marks remain counted. No independence between episodes is used.

The eleven recovery allowances and ten waits cost at most `11/100000+10 exp(-8)`. No service block or stock is reset by these stopping times. The candidate's floor acquisition at30 is not mistaken for Ready512; its first post30 recovery is explicitly charged.

## Resource bounds on the switched law

A changed seed law may alter future fuel occupancy and accepted feed. The resource proof does not assert pathwise monotonicity against the continuously seeded process.

At every state the combined consuming envelope is the source expression

`Cstar=beta+3(400N+beta+1)=18457603`.

Its endpoint condition `beta+1>=800N/2` holds. The `+1` pays the division-coupled job. Basal victim-fuel loss and triggered victim-fuel loss are retained separately. For the feed/fuel tilt `exp(tA-sF)`, seed transitions contribute exactly zero. The uniform generator upper bound is therefore identical on both sides of30:

`k=max{beta(exp(t-s)-1), [Cstar+1+3exp(s)](exp(s)-1)}`.

The factor `exp(s)` pays a triggered simultaneous two-token loss. Integrating the same bound through the deterministic switch gives the source SR3 estimate without any switch jump or extra charge.

At `t=1/10000`, `s=400/22457607`, using `exp(x)<=1/(1-x)` on the nonnegative arguments gives the independently checked exponent

`-5508991479342664251200/5043026607980323551<-1092<-20`

for `P(A60>800000000)`.

The accepted seed intensity has integrated envelope 2160, since it is at most72 before30 and zero afterward. The retained cap5000 has tail below `exp(-260)`, hence below `exp(-20)`. Actual division intensity remains at most16, giving mean-envelope960 and exponent `-192/7<-20` at cap1200. These are bounded-intensity count bounds, not independent-Poisson assumptions about accepted events.

The unchanged eventwise ledgers, including every terminal mark, give

`F0+A=F+(B+H+Q+U)+W_R`,

`B+H+Q+U<=A+4`, `B+E<=A+4+E`,

`W_R<=D`, `W_S<=3ND`.

Consequently the joint resource-good event supplies:

- feed entries: 800,000,000;
- initial occupied fuel: at most4;
- consumed fuel: 800,000,004;
- accepted seeds: 5,000, all before30 almost surely;
- catalytic-birth plus seed precursor entries: 800,005,004;
- actual marked divisions: 1,200;
- discarded/restored catalyst slots: 7,372,800;
- discarded victim fuel: at most1,200, already paid in the gross fuel ledger.

Adding victim fuel again to required gross supply would double-count it. Prepared initial catalyst counts are an explicit initial condition, separate from subsequent precursor entries. Post30 catalytic birth still consumes fuel and precursor resources.

Couple the finite-stock switched process to the unlimited-stock switched process using identical waits, channel decisions, victim choices and complementary split marks, with the same deterministic switch. Stop at the first attempted declared-resource excess. Before that mark both processes have the same state and rates. On the unlimited-stock switched resource-good event no such excess occurs through60. Transfer the entire already proved physical mission and subtract the three global resource tails once. This couples the two switched laws; it does not compare switched and continuously seeded paths after30.

The final bound is therefore

`9545923/9062500000+11/100000+10 exp(-8)+3 exp(-20)`

`<=4517975690072193/10^18`.

Every probability term refers to the same switched physical law before the final finite-stock transfer.

## Immediate inheritance and scientific interpretation

The immediate-inheritance implication is exact and already holds for the accepted continuously seeded mission. At a division mark, the two installed daughter counts for species `j` are exactly `K_j` and `a_j-K_j`. On the complete postmark floor event both are at least16, hence

`16<=K_j<=a_j-16` and `a_j>=32`.

No seed or chemical birth occurs inside this completed division update. Both daughter inventories are parental partitions. The statement covers every actual established-phase division, not just the ten selected renewals. It is an event-level implication of the joint high-probability mission, not an independent per-division success probability. The binomial split law enters the probability control, but complementarity and the floors alone prove this implication.

The deterministic withdrawal extension supplies a stronger finite experiment: after acquisition, no catalyst is imported through any seed channel, while the specified repertoire, both-daughter transmission, recurring whole-population Ready counts and contracted function persist for the certified interval. This closes the concern that later floor maintenance on successful paths could be achieved by extinction followed by reseeding.

The explanatory claim must remain bounded:

1. **Categorical repertoire:** all three specified species are inherited above the floor. No bound is proved on preservation of their relative concentrations or parent/daughter composition ratios.
2. **Immediate parental origin:** division adds no catalyst molecules, but individual molecular labels and long-term molecular genealogy are absent from the state. Subsequent catalytic production and turnover are not labeled ancestry.
3. **Population renewal:** four spatial sites are maintained by parent/victim replacement. The theorem does not describe unbounded population growth or ten generations along one persistent daughter lineage.
4. **Prepared, fed finite system:** two old species start prepared; candidate acquisition has an initial seed-supported phase; food/fuel and precursor stocks remain available within explicit finite bounds. The result is not spontaneous origin from an unprepared founder or material closure.
5. **Specified template-free model:** the model has species counts and stipulated autocatalytic and division propensities, without sequence-template copying. The theorem does not validate a particular chemical realization, estimate inherited sequence information, or prove Darwinian evolution.
6. **Finite horizon and selected mission event:** persistence is proved through60 with the stated joint probability, not indefinitely and not on every realization. Removal is deterministic even on failing realizations.

No mathematical repair remains required in the final proof. For narrative adoption, state the joint probability/event, both-daughter repertoire implication, deterministic cutoff, finite-stock scope, and these limits plainly. Do not present the local G60 allowance alone as the total mission risk or the new analytical audit as a compiler receipt.

## Reproduction and preservation

Run `PYTHONDONTWRITEBYTECODE=1 python independent_full_mission_check.py > independent_full_mission_stdout.txt` in this review directory. Only the Python standard library and exact integers/fractions are used. The result file records every finite-row count, decisive maxima, probability arithmetic, source hashes and trust boundary. The final audit manifest and SHA256SUMS pin the report, source snapshot, checker, results and stdout.

All producer files and source dependencies are rehashed at the end of the check. This work used only the cloud filesystem and interpreted exact arithmetic. No compiler, Git operation, user-desktop access, external communication/publication, security change, simulation, parameter sweep, or P079/P098 work was performed.
