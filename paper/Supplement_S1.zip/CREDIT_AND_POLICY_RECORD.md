# Contributor and existing-policy record

Recorded18October2026. In response to the question identifying the existing Apache-2.0/CC-BY-4.0 policy and the six imported-original groups, Michael Mislan stated exactly:

> I don't know of any exceptions. The only human contributor is Michael Mislan, thanks

This edition records Michael Mislan as the sole human contributor. The existing neutral AI-assistance statement is retained. No rStation handle, account identity, affiliation, additional human contributor or specific unreported contribution role is invented. Archived author fields and source bibliographies remain unchanged.

The existing policy remains Apache-2.0 for original code/proofs/configuration and CC-BY-4.0 for original prose/non-software data, within rights held by the licensors. Existing third-party notices take precedence. The statement records no exceptions known to the owner for the asked groups; it is not an independent legal-title determination, an absolute no-exceptions warranty, or a new licence grant. All nine external dependency notices and the existing Apache/CC-BY texts are retained unchanged.

The six groups remain enumerated in RIGHTS_INDEX.json: P118 prose; P161 prose; literal profile; historical direct-checking source/output; comparison constructor/family/service/retention support; and Cert/Defs. No scientific expression, certificate, historical output or proof caveat changes in this credit edition. The actual submitting account is a later operational login detail, not an unresolved manuscript-preparation requirement.
