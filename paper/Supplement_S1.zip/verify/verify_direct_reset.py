"""Exact verification of Appendix C direct reset certificate, standard library only.
Run from any directory: python verify_direct_reset.py [optional-result.json].
Reads only the supplied fixed table; no predecessor directories or imports.
This checks the finite reset certificate, not every mission inequality.
"""
from pathlib import Path
from fractions import Fraction as Q
from math import comb
import hashlib,json,sys,time

def main():
    started=time.monotonic()
    path=Path(__file__).resolve().parents[1]/'data/recovery_profile_upper.json'
    raw=path.read_bytes(); digest=hashlib.sha256(raw).hexdigest()
    assert digest=='1cbf7592037531b0c61ca9c5c01f40e418bf5932b291c25273490e535fb12542'
    P=[[Q(v) for v in row] for row in json.loads(raw)]
    N=2048; grid=10**18; delta=Q(1,grid); ell=Q(9997,10000)
    assert len(P)==N+2 and all(row==[0,0] for row in P[:16])
    integers=[]
    for row in P:
        assert len(row)==2 and all((v*grid).denominator==1 for v in row)
        integers.append([int(v*grid) for v in row])
    # C10a: reconstruct the high witness directly from the printed rational formula.
    f={a:Q((980-a)*(981-a)*(982-a),(a-10)*(a-9)*(a-8)) for a in range(511,769)}
    for a in range(769,N+2):f[a]=f[a-1]*Q(10,11)
    for a in range(512,N+2):
        k=(6*(1-Q(a,N))*(f[a+1]/f[a]-1)+a*(f[a-1]/f[a]-1)) if a<768 else Q(5647*a,56320)-Q(6,11)
        A=f[a]/f[512]; D=A*(258+k)/8000000
        assert 0<D/A<Q(1,10000)
        for r,v in enumerate((A,A-D)):assert P[a][r]-delta<=v<=P[a][r]
    # C10b: exactly 496 low-count pairs, independent of any band solve.
    for a in range(16,512):
        A=P[a][0]; D=A-P[a][1]
        assert A>0 and 0<=D<=A/1251
    d=Q(93867565097,200000000)
    bL=Q(-147104211175367700201,500000000000000000)
    bA=Q(3343277526704540851,125000000000000000)
    rows=deficient=summands=0; maxima=[None,None]
    for a in range(16,N+1):
        total=0
        if a>=32:
            choose=comb(a,16)
            for k in range(16,a-15):
                total+=choose*integers[k][0]
                choose=choose*(a-k)//(k+1)
                summands+=1
        moment=Q(total,(2**a)*grid)
        for r in (0,1):
            residual=2*(1+r*(2+Q(a,N)))*moment-d*max(Q(0),P[a][r]-delta)
            assert residual<=bA,(a,r,'all-row comparison')
            rows+=1
            if maxima[1] is None or residual>maxima[1][0]:maxima[1]=(residual,(a,r))
            if a<512:
                assert residual<=bL,(a,r,'deficient comparison')
                deficient+=1
                if maxima[0] is None or residual>maxima[0][0]:maxima[0]=(residual,(a,r))
    assert rows==4066 and deficient==992 and summands==2035153
    assert bL+11*bA==Q(-367902757,500000000000000000)<0
    direct=8+d/ell
    assert direct==Q(95467085097,199940000)<478
    def ceil18(v):return str(Q(-(-v.numerator*grid//v.denominator),grid))
    result={'status':'PASS_EXACT_RATIONAL_DIRECT_RESET','table_sha256':digest,
      'grid_integrality':True,'high_tail_enclosure':True,'low_comparison_pairs':496,
      'all_count_fuel_rows':rows,'deficient_rows':deficient,'binomial_summand_iterations':summands,
      'deficient_max_outward':ceil18(maxima[0][0]),'deficient_argmax':maxima[0][1],
      'all_max_outward':ceil18(maxima[1][0]),'all_argmax':maxima[1][1],
      'printed_bL':str(bL),'printed_bA':str(bA),'direct_constant':str(direct),
      'full_mission_replay':False,'Lean_compilation':False,'elapsed_seconds':round(time.monotonic()-started,3)}
    if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
