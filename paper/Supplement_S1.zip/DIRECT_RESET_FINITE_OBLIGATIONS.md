# Fixed-data certificate ledger for v2.2

Status: source-level mathematical integration; no new certificate execution. All numbers below are exact rational definitions or historically reported finite checks. This ledger does not turn them into unspecified assumptions or announce a fresh pass.

| Gate | Complete objects and checks | Evidence/status |
|---|---|---|
| Literal witness identity | Full two-column rational table SHA256 `1cbf7592037531b0c61ca9c5c01f40e418bf5932b291c25273490e535fb12542`; rows below16 zero; at least rows0..2049; every used10^18 P entry integral | Fixed input retained unchanged; historical independent source checks syntax/identity/integrality |
| Low comparison | A=P(a,0), D=P(a,0)-P(a,1); A>0 and0<=D<=A/1251 for a16..511 |496 literal pairs; equivalent fueled lower comparison already in retained candidate/independent sources; remains an explicit finite obligation |
| High envelope | Reconstruct exact t0=A,t1=A-D from the printed tail; P-delta<=t<=P for a512..2048, both fuels |3074 count/fuel comparisons; directly asserted in the later historical full-mission checker, which also checks auxiliary2049; no old low band needed |
| Daughter moments | Mplus(a)=0 below32; otherwise2^-a sum_(k=16)^(a-16) binom(a,k)P(k,0) | All terms; recurrence binom(a,k+1)=binom(a,k)(a-k)/(k+1);2017 parent counts and2,035,153 summand iterations |
| Deficient residual | Y=2[1+r(2+a/N)]Mplus, X=max(0,P-delta), d=93867565097/200000000; Y-dX<=bL on16..511,both fuels |992 rows; bL=-147104211175367700201/500000000000000000 |
| All-row residual | Same expressions; Y-dX<=bA on16..2048,both fuels |4066 rows; bA=3343277526704540851/125000000000000000 |
| Conventional consequence | ell X<=h; retained8U; one deficient plus11 unrestricted rows; bL+11bA<0 | Gives BU<478U with Cdirect=95467085097/199940000; analytic proof integrated |
| Other recovery requirements | h barrier>=1 below512, positivity/order, maximum M, all seed-free chemical rows and physical reference-generator comparison | Remain separately required; direct reset argument does not remove them |
| Other mission requirements | Branching/retention, source-defined good event, acquisition, fixed-grid service, restart/composition and finite-stock/scalar gates | Retained from the exact source; no new full-mission execution or theorem enlargement |

The later historical reset kernel reads the full literal table and checks the same residuals directly. It neither imports nor resolves band equations. The full historical program also reads unrelated provenance/mission inputs; it is preserved as source evidence, not relabelled as a minimal portable reset executable. The arithmetic procedure above and the manuscript define the complete direct finite-checking route without those incidental reads or a private discovery algorithm. Any future separately prepared executable requires its own review and honest execution status; none is launched here.

An alternative envelope defined by exact ceiling of the printed high tail is described in the original mathematical note. It has its own precisely stated residual certificate. A width-delta grid enclosure is not silently treated as an exact ceiling identity. V2.2 selects the complete-literal-table route because the available later source/results directly support it.

The public central proof needs the literal input, exact tail, this complete row/moment specification, conventional reset soundness, and sufficient accessible historical finite-proof support or an accepted direct verification. A bare checksum or constants table is not enough. Larger archived search, later cap stages and band-construction history need not be mathematical premises of this central step. Keep sources still required by the separate beta8m/other operating comparisons.
