The original \(G60\) allowance is backed by an explicit **count/fuel drift certificate plus two beta-dependent service inequalities**, followed by the 300+300-block mission bound. I read the cited upstream Lean statements and their proofs; this is source retrieval, with no scientific replay or beta1m evaluation.

The most direct beta-dependent service premise is:

```lean
(hθβ : θs ≤ p.β * (1 - ρ))
```

The original witness uses `θs = 7120` and `ρ = 99911/100000`. A second service premise and the separate `cert0` drift certificate also depend on beta. Their exact statements appear below.

The named source review states:

> The1/500 risk covers the COMPLETE original G60 from prepared old species512: every pre/post floor and fixed-grid500 quota, candidate establishment at30 and at least five initiating divisions per site after30. It is not generic floor failure from an arbitrary16-copy state. Full theorem and explicit certificate/budget are Section7.1.

[CANONICAL_MANUSCRIPT.md:280](../../support/P161_CANONICAL_MANUSCRIPT.md) supplies these assumptions and event conditions:

> Fix two old species and one candidate in the supplied three-species catalogue. Initially each old species has at least512 copies at each of the four sites. Candidate counts may be arbitrary, including zero everywhere; fuel bits may be arbitrary. Base the external service and resource ledgers at time zero without changing any count or fuel.

> 1. On [0,30], both old species have at least16 copies at every site at every time, including complete post-jump states. Each old job earns at least500 conversions per site in every one of the300 fixed blocks (n/10,(n+1)/10], n=0,...,299.
> 2. At time30, the candidate has at least16 copies everywhere.
> 3. On [30,60], all three species have at least16 copies everywhere at every time. Each job earns at least500 conversions per site in each of the300 fixed blocks (30+n/10,30+(n+1)/10]. Each spatial site initiates at least five actual divisions during this phase.

Seeds remain at epsilon6 throughout. Ordinary jobs, recharge and discharge use beta8m; active birth/death and the original complementary division law remain present.

The upstream theorem is [Main.lean:117](../../../PROOF_NAVIGATION.md):

```lean
theorem main_mission (jc : Fin p0.c) (x : Pop p0)
    (hx : ∀ i j, j ≠ jc → 512 ≤ ((x i).a j : ℕ)) :
    998 / 1000 ≤ mission p0_valid 16 500 5 300 300 (1 / 10) jc x := by
```

Its proof invokes the general mission bound with the literal witness:

```lean
have h := mission_lower p0_valid cert0
  (by norm_num) (by rw [hΛ]; norm_num) hb0
  (ρ := 99911 / 100000) (θs := 7120) (z := 6) (w := 1 / 10)
  ...
  500 5 300 300 jc x
```

Here `p0` is the fixed \((M,c,N,\alpha,\beta,\epsilon)=(4,3,2048,800,8000000,6)\) witness. `Root.lean` restates this as `root_mission`; its separate no-seed theorem is not used.

The count/fuel certificate is explicitly fixed at beta8m. [Cert.lean:301](../../../comparison_support/proofs/FunctionalCapacity/Cert.lean) defines:

```lean
def CC : ℝ := 1860480 * hh 12 / (3 / 4) ^ 12
def C0 : ℝ := CC / (1 + 1 / 10 ^ 7)
def zgR (R : Bool) : ℝ := if R then 1 else 1 + 2 / 10 ^ 6
def zfR (R : Bool) : ℝ := if R then 1 else 1 + 9 / 10 ^ 6

def W0 (a : ℕ) (R : Bool) : ℝ :=
  if a = 0 then C0 * (if R then 1 + 1 / 10 ^ 7 else 1)
  else if a ≤ 12 then CC * zgR R * (3 / 4) ^ a
  else 1860480 * zfR R * hh a

def b0 : ℝ := 13 / 10 ^ 7
```

The source proves `hh a = a!/(a+5)!`. Its exact drift statement, [Cert.lean:587](../../../comparison_support/proofs/FunctionalCapacity/Cert.lean), is:

```lean
theorem drift0 (a : ℕ) (R : Bool) (Hf Uf : ℝ)
    (ha : a ≤ 2048) (hU0 : 0 ≤ Uf) (hU2 : Uf ≤ 2)
    (hH1 : 8000000 * Uf ≤ Hf)
    (hH2 : Hf ≤ 8000000 * Uf + 1843200) :
    siteOp p0 W0 a R Hf Uf ≤ -(1 / 2) * W0 a R + b0 := by
```

I read its proof: it splits zero, geometric and factorial count ranges; the fueled factorial ranges are bounded separately through 2048. This feeds:

```lean
theorem cert0 : SiteCert p0 16 W0 (1 / 2) b0 80 where
  nonneg := W0_nonneg
  le_max := W0_le
  ge_one := W0_ge_one
  drift := ...
```

The corresponding quantitative properties are \(0\le W_0\le80\), \(W_0\ge1\) below16, and \(W_0\le6/10^8\) at counts at least512.

The beta dependence inside that drift obligation is literal. [Defs.lean:201](../../../comparison_support/proofs/FunctionalCapacity/Defs.lean) defines, with \(u=a/N\):

```lean
def siteOp (p : Par) (W : ℕ → Bool → ℝ)
    (a : ℕ) (R : Bool) (Hf Uf : ℝ) : ℝ :=
  let u : ℝ := (a : ℝ) / p.N
  if R then
    p.ε * (1 - u) * (W (a + 1) true - W a true)
      + p.α * a * (1 - u) * (W (a + 1) false - W a true)
      + p.α / 2 * a * (W (a - 1) false - W a true)
      + a * (W (a - 1) true - W a true)
      + (p.β * (1 + u) + Hf) * (W a false - W a true)
      + (binE (fun k => W k true) a
          + binE (fun k => W k false) a - 2 * W a true)
      + (u + Uf) * (2 * binE (fun k => W k false) a - W a true)
  else
    p.ε * (1 - u) * (W (a + 1) false - W a false)
      + a * (W (a - 1) false - W a false)
      + p.β * (W a true - W a false)
      + (2 * binE (fun k => W k false) a - 2 * W a false)
```

[SiteCF3b.lean:15](../../../PROOF_NAVIGATION.md) supplies the actual foreign loads:

```lean
def Uf ... := ∑ j', if j' = j then 0 else s.u j'

def Hf (p : Par) ... :=
  ∑ j', if j' = j then 0 else
    (p.β * s.u j'
      + p.α * ((s.a j' : ℕ) : ℝ) * (3 / 2 - s.u j'))
```

Its proved bounds are:

\[
0\le U_f\le c-1,\qquad
\beta U_f\le H_f\le\beta U_f+\alpha N(9/16)(c-1).
\]

Thus the original \(G60\) floor/acquisition input is the **`W0`/`siteOp` certificate**, distinct from the newer transported recovery potential.

The exact service assumptions occur in both [Mission.lean:200](../../../PROOF_NAVIGATION.md) and [MissionBound.lean:185](../../../PROOF_NAVIGATION.md):

```lean
(hρh : 1 / 2 ≤ ρ) (hρ1 : ρ ≤ 1)
(hθs0 : 0 ≤ θs) (hθs : θs ≤ cf3Rate p)
(hθβ : θs ≤ p.β * (1 - ρ))
(hsrv :
  (p.β + 1) * ((K : ℝ) / p.N) * (1 / 2 - ρ)
    + Hs p * (1 - ρ) + θs * ρ ≤ 0)
```

The fuel-loss bound is [SiteCF3c.lean:52](../../../PROOF_NAVIGATION.md):

```lean
def Hs (p : Par) : ℝ :=
  p.α * p.c * p.N * (9 / 16) + p.β * p.c + (2 * p.c + 2)
```

At the original witness, `Main.lean` proves `Hs p0 = 26764808`. These hypotheses yield the killed service-potential inequality:

```lean
(Kd hp K req).P (Ysrv ρ ij) x
  ≤ (1 - θs / cf3Rate p) * Ysrv ρ ij x
```

where `Ysrv = 2^(-q_ij) * (ρ if fueled else 1)`. The upstream fuel-off proof bounds its generator by \(-\beta(1-\rho)2^{-q}\); the fuel-on proof uses the second inequality above. Consequently, the original service decay is7120 and the block exponent is712 for a0.1 block. `Main.lean` proves

\[
2^{500}e^{-712}\le10^{-12},
\]

then bounds the aggregate per-block service contribution by \(10^{-10}\).

The exact final budget is copied from manuscript §7.1:

```text
P(G60^c)
 <=48/10^8+320/2900000
   +600*((6/5)*b0+1/10^10)+5184/10^10
 <1/500.
```

Its stated accounting is:

> Here exp(-15)<=1/2900000 pays arbitrary initial candidate counts, exp(-25)<=1/10^10 pays the division deficit, and the per-block service contribution is at most1/10^10. The exact source proof Main.lean establishes these comparisons and the same 300+300-block induction. The initialization bound 48/10^8 uses only the eight prepared old coordinates.

The `Main.lean` proof separately bounds the pre-phase by
\(300(2(4b_0/10)+4b_0/10+10^{-10})\), and the post-phase by
\(5184/10^{10}+300(3(4b_0/10)+10^{-10})\).
`MissionBound.lean` combines the candidate decay, guard, service and division potentials through `pre_lower`, `post_lower`, and `mission_lower`; I read those proofs.

The manuscript explicitly identifies its probability operator with the complete marked-path event:

> At a live block start the killed tick is P(1_live f), so its nth power checks every complete post-tick state. Independent Poisson weights identify all-time floor survival. … Applying the deterministic Markov property at grid boundaries gives precisely the original iterated mission operator. Thus the source's root_mission bound and G60 are the same event on the constructed marked law.

Fresh SHA-256 pins for the newly retrieved upstream files under `ARCHIVE_PATH_001`:

| File | SHA-256 |
|---|---|
| Defs.lean | `4849c8f8a8012dbe63a22f9819bdd3e4b6cc478d001f55c36144d95549ee72c6` |
| Cert.lean | `1d3c0f327d1c2d1ab5606f10b7ff31d2146883176d6a0a08efd68355c59428d3` |
| SiteCF3b.lean | `369c96c68bc9d571258f63fce33bdd2502514e33d350e18f93636478b25fc0c1` |
| SiteCF3c.lean | `3f3127e879aab0253f963980c6685df07a9fc98a644c2176d42d02ac1627795d` |
| Mission.lean | `6ffe47a1fccbc5963bb1b2ba237ab3db58548e196055a8c8d3264ee961d715a8` |
| MissionBound.lean | `46bf87d7b280e6a7fa53371d4faa871cc61b7e42b6fd9eabc624163af603c6c0` |
| Main.lean | `721fa9694bdc85239456fe11e64d9f64932ebf5c32481c83ff5fbdf0e6b36b38` |
| Root.lean | `20d586b56ae0fef35bc9dc180e72afcdb8c0d61f6231b9b94c6a9cefd7c7ddb8` |

[Internal workflow chronology omitted; mathematical excerpts retained.]

No beta1m \(G60\) conclusion was derived. The retrieved beta-dependent inputs are precisely **the `cert0` drift obligation and service premises `hθβ`/`hsrv`**, whose constants feed the displayed joint budget. No files were written, earlier seven-file hashes rerun, or proof/compiler/checker execution performed.
