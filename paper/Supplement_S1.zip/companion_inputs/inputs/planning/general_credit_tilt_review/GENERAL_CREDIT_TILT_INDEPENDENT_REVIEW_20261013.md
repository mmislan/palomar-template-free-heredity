# Independent review: generalized ordinary-credit tilt and beta4m mission

## Decision

**ACCEPTED as a complete additive analytical beta=4,000,000 mission corollary, within the already independently accepted full-branching and uniform-recovery dependencies.** The generalized service lemma, exact numerical witness, complete fixed-grid event, stopping-history composition, occupancy-sensitive accepted-feed bound, all gross resource ceilings, and identical-mark finite-stock coupling match the physical source model.

**Restricted status:** this is an analytical proof review and exact rational computation, not a new Lean theorem or compiler receipt, producer acceptance, or canonical adoption. Canonical paper161 v2 at beta4.5m remains unchanged. No producer file was edited. The full beta1m service/mission question remains open.

**No mathematical correction is required to the candidate's claimed beta4m bounds.** Two precision notes should accompany any later presentation: the reduced G60 allowance is only one part of the complete mission failure allowance; and the finite-state semigroup argument is most precisely phrased as a marked/tilted semigroup on the finite physical state space, since an uncapped external credit ledger itself is unbounded. Neither issue invalidates the submitted proof.

The accepted candidate numbers are:

- Ordinary-credit tilt z=3/4, fuel weight rho=79967/80000, service decay theta=1650.
- Full physical fueled service residual: -598067/10000=-59.8067.
- Aggregate service-miss/floor-survival intersection bound per block: less than 1948303823/250000000000000000=0.000000007793215292, hence less than 10^-8.
- Conservative complete G60 failure allowance: 9545923/9062500000, less than 0.001053343227587.
- Complete mission failure ceiling, including recovery, division waits, and all three resource tails: 4517975690072193/10^18=0.004517975690072193.
- Accepted-feed ceiling: 800,000,000; the SR3 upper exponent is less than -1092.
- Ten division/Ready renewals finish by 55.5; all 3,000,000 service credits finish on the unchanged grid by 60.

The improvement over the accepted beta4.5m point is a new analytical service tilt that permits beta4m with an 800m accepted-feed cap rather than 900m. It is not an optimized beta threshold and supplies no beta1m occupation lower-tail result.

## 1. Objects reviewed and provenance

The submitted note, checker, results, and stdout were independently hashed. They match exactly:

| Candidate object | SHA-256 |
|---|---|
| GENERAL_CREDIT_TILT_AND_BETA4M_CANDIDATE_20261013.md | 9adf869a363b3142fc56e51ca278d2f9a05208de50688977ae9bb2750f5dddf7 |
| general_credit_tilt_certificate.py | b6e6e340af442ce69faf937b2c38c3ae127a3f39cdcf4cb839fe8621f27d6280 |
| general_credit_tilt_results.json | d839b53e55167ea93df3922e238c236d979bff20fbcbba4b2f2cce887fef7ea4 |
| general_credit_tilt_stdout.txt | d839b53e55167ea93df3922e238c236d979bff20fbcbba4b2f2cce887fef7ea4 |

The producer manifest matches these four files, and results/stdout are byte-identical. The new independent checker imports no producer code and never executes the producer checker.

The review reads the physical model in the historical recovery manuscript, the literal SiteCert/siteOp/service definitions, the fuller G60 event retrieval, Par.Valid/cf3Rate/resource-ledger retrieval, exact Cstar/SR3 source, complete generic mission and composition retrieval, the accepted beta4.5m audit, and the full-branching/uniform-recovery packets. Their exact local digests are in `SOURCE_DEPENDENCIES_SHA256.json` and in the independent result JSON. Restored-source digests were compared with the recovered manifest where entries exist.

The full original source files remain upstream; this review uses the supplied pinned source extractions and previously accepted analytical audits. It does not represent a fresh retrieval or compilation of upstream Lean. The submitted occupation note was read for its channel description; the present service argument is independently reconstructed below and does not depend on accepting its separate beta1m occupation claim.

## 2. Physical assumptions and exact parameter validity

Use M=4, c=3, N=2048, alpha=800, epsilon=6, beta=4,000,000. The same beta enters recharge, discharge, and every ordinary consuming job. All channels remain active, including outside a required service window and during recovery.

The source Par.Valid requires M>=2, N>0, alpha>=0, beta>=0, and epsilon>=0. These all hold. Its literal uniformization envelope gives

Lambda=4[3(6+800*2048+400*2048+2048+4000000)+4000000+4]
      =93,515,864.

It exceeds both 1/2 and 1650 and is at least one. No hidden large-beta requirement is supplied by Par.Valid. The SR3 endpoint condition is checked separately in Section 8.

At each site the physical counts are capped at 2048. Seed/passive events preserve fuel. Active birth/death and ordinary jobs clear fuel. Basal divisions occur at rate one per spatial site; triggered divisions have rate R_i sum_j(a_ij/N), at most three per site. The victim is uniformly selected from the other three sites. The daughter molecule vectors are complementary binomial halves, and basal daughter fuel bits sum to parental fuel. A trigger first consumes its one fuel token, then both daughters have zero fuel. The victim's old state is overwritten. State-null marked divisions still count as actual divisions.

The selected credit counter is an external spatial ledger. An ordinary selected job increments it at the selected spatial site; a division does not split or overwrite that ledger. At a service boundary it is rebased to zero without altering any physical count, fuel, or stock. Ignoring division-coupled credits gives a stronger service event than the original quota event.

## 3. Independent full marked-generator service proof

Fix a required coordinate (i,j), let a be its physical count, R its site fuel, and Q its ordinary credits since the current block start. Define

Y=z^Q [rho if R=1, otherwise 1], with 0<z<=rho<=1.

Every statement here is conditional on the complete premark state. No independence between fuel, counts, donors, sisters, or future good events is assumed.

### 3.1. Empty fuel

Recharge has rate beta and changes Y by -z^Q(1-rho). Seeds and passive deaths preserve Y. The selected job and local fuel-consuming chemistry cannot fire with empty fuel. An incoming division can leave the selected site empty or give it fuel; either possibility preserves or decreases Y, irrespective of the donor counts or fuel. Other non-touching events preserve Y. Therefore

L_phys Y / z^Q <= -beta(1-rho).

### 3.2. Occupied fuel

The selected ordinary job contributes exactly

beta*(a/N)*z^Q*(z-rho).

Discharge plus the other two ordinary jobs have rate at most 3beta. For each active birth/death pair the total rate is alpha*N*u*(3/2-u), at most alpha*N*(9/16); all three pairs therefore contribute at most alpha*c*N*(9/16) to the positive fuel-clearing envelope. Seed/passive changes preserve Y because this potential has no count-dependent weight.

All divisions touching the selected site are included. Its own total initiating intensity is at most four. Incoming-victim intensity is at most the sum of three donor bounds 4/(M-1), hence at most four. At every such mark, regardless of both sister counts and donor/victim fuels, the new fuel weight is at most one, and Q is unchanged when only ordinary credits are counted. Its potential increase is consequently at most z^Q(1-rho). Thus all touching marks contribute at most 8*z^Q(1-rho). This includes selected triggers, unselected triggers, incoming replacement, arbitrary donor histories, and state-null marks; it deliberately drops beneficial contributions.

Hence, with

Hs=800*3*2048*(9/16)+3beta+8=14,764,808,

L_phys Y/z^Q <= beta*(a/N)*(z-rho)+Hs*(1-rho).

The count coefficient is nonpositive, so replacing a>=16 by 16 gives an upper bound. At z=3/4, rho=79967/80000, theta=1650,

beta*(1-rho)=1650,
beta*(16/2048)*(z-rho)+Hs*(1-rho)+theta*rho=-598067/10000<0.

The independent script checks the live-count envelope at all 2,033 counts and both fuels, 4,066 rows. These finite rows supplement the analytical monotonicity argument; they do not replace the full physical channel argument.

### 3.3. Killing, probability statement, and past-history conditioning

Kill when any coordinate in the current required set falls below 16, using the complete postmark state. Replacing a nonnegative postmark Y by zero only decreases the generator, so L^D Y<=-theta Y. On the finite physical state space the marked exponential tilt defines a finite-dimensional sub-Markov/Feynman-Kac operator. Equivalently, on the physical chain with its additive credit counter, bounded rates and 0<=Y<=1 give the elementary stopped nonnegative exponential-supermartingale argument. Both establish

E_x[1_{D>w}Y_w] <= exp(-theta*w)Y_0 <= exp(-theta*w).

If Q_w<500, Y_w>=rho*z^500; using exponent 500 rather than 499 is conservative. Thus

P_x(D>w, Q_w<500) <= rho^-1*z^-500*exp(-theta*w).

This is an intersection bound. It is not a bound conditional on future survival. At every actual exposed block start, multiply it by a past-measurable successful-prefix/live-start indicator and apply the tower property. No prepared512 distribution is assumed at grid boundaries.

For at most 12 required coordinate quotas and w=1/10, the exact rational degree-200 lower polynomial for exp(165) gives

(12/rho)*(4/3)^500/[(sum from k=0 to 200 of 165^k/k!)]
 <1948303823/250000000000000000<10^-8.

A separately structured factorized lower bound, [sum from k=0 to 100 of (33/2)^k/k!]^10<=exp(165), gives the still smaller outward ceiling 3882479971/500000000000000000=0.000000007764959942. The accepted candidate continues to use 10^-8 per block.

### 3.4. Why the old source theorem is not being misused

The literal source tick_service, Ysrv, and blockErr hard-code the per-credit factor 1/2 and 2^500/rho. Their variable rho is only the fuel weight. Substituting z=3/4 into those statements is invalid.

The present proof instead establishes the required local inequality for ordinary credits directly on the original marked physical law, then reconstructs its fixed-grid use. The coefficient is beta, not beta+1: the extra division-coupled credit is not used. The source's separate z=6 division-deficit tilt is unchanged and must not be confused with the new service-credit tilt z=3/4.

## 4. Full branching input: independently checked at beta4m

The accepted family is a new W_beta, not the old beta8m W0 copied to another model. Let

h(a)=1/[(a+1)(a+2)(a+3)(a+4)(a+5)],
C=1860480*h(12)/(3/4)^12,
A(a)=C*(3/4)^a for a<=12; A(a)=1860480*h(a) for a>=13,
g(0)=-A(0)/2; g(a)=A(a)*min(6a,70) for a>=1,
W_beta(a,true)=A(a), W_beta(a,false)=A(a)+g(a)/beta.

The accepted reciprocal-family interpolation yields

siteOp+(1/2)W_beta <=8/10^7+(1/4)(131/10^8-8/10^7)
                         =371/400000000<b0=13/10^7.

Here Hf=beta*Uf+v with 0<=Uf<=2 and 0<=v<=1,843,200. The literal operator is affine in Uf and v, so four corners suffice for each count and fuel.

The new independent checker separately assembles the literal complete operator at beta4m for every a=0,...,2048, both fuels, and all four load corners: all 16,392 rows pass. Its maximum is at a=951, fueled, Uf=2, v=1,843,200, and is at most 0.000000899728592860. The binomial daughter moments are computed from the exact beta-integral identity plus finite prefix corrections, then cross-checked against complete direct binomial sums at 13 counts including zero, both joins, floor endpoints, 511/512, 2048, and the actual maximizing count. No recovery killing, artificial floor boundary, or independent-sister approximation appears in this branching check.

The all-natural obligations are analytical, rather than inferred from checking through 2048. A has successive ratio 3/4 before the join and (a+1)/(a+6) from a=12 onward. The false weight decreases at the finite exceptional counts 0,...,12; from 12 onward its multiplier 1+70/beta is constant. The negative gap at a=0 is retained explicitly. Consequently all natural weights are nonnegative, their maximum is C<80, all weights below 16 are at least A(15)=1, and all weights at or above 512 are at most W_beta(512,false)<=6/10^8. These give exactly the required SiteCert and prepared-founder input.

## 5. Explicit reconstruction of complete G60

G60 retains all the following simultaneously:

1. Both old species remain at least16 at all four sites throughout [0,30], and each old job earns at least500 credits at its own site in each of the 300 fixed 0.1 blocks.
2. At time30 the candidate is at least16 at every site.
3. All three species remain at least16 throughout [30,60], with 500 credits at every required site/species in every one of the 300 post30 blocks.
4. Every spatial site initiates at least five actual divisions during [30,60].

Initially only the eight old coordinates must be prepared at 512; candidate counts and all fuels may be arbitrary. There are 2,400 pre30 and 3,600 post30 coordinate-block quotas, each of size500. No quota pooling or moving boundary is used.

### 5.1. Matching the source's conservative block accounting

The source's prephase error has old-species guard 2*(4b0)*0.1 plus candidate auxiliary 4b0*0.1. Its postphase guard is 3*(4b0)*0.1, with zero candidate auxiliary term. Both are (6/5)b0. The directly proved service intersection bound replaces the one fixed-half-tilt local service estimate; all the other error terms depend on SiteCert and the unchanged physical marked law.

The candidate decay exponent remains (1/2)*30=15. The division-deficit exponent with its separate source tilt 6 remains (1-1/6)*30=25, and its prefactor is 4*6^4=5184. Prepared initialization is eight times 6/10^8. Rational lower exponential polynomials verify exp(15)>2,900,000 and exp(25)>10^10. Therefore the candidate's complete conservative allocation is

P(G60^c)
 <=48/10^8+320/2900000+600*((6/5)b0+10^-8)+5184/10^10
 =9545923/9062500000<1/500.

This is a reconstructed analytical inequality. It is not an application of the unchanged Lean mission_lower statement with an unsupported new service-credit parameter.

### 5.2. Independent direct potential proof, avoiding reliance on an unshown modified induction

For completeness, a separate short route proves an even smaller bound and thereby certifies the submitted conservative allocation without requiring any new formal block-induction theorem.

For species j define Phi_j=sum_i W_beta(a_ij,R_i). The physical generator satisfies

L Phi_j <= -(1/2)Phi_j+4b0.

To verify the division part from the literal physical model: summing basal initiator gains gives expected two-daughter weights minus parent weight, and summing the uniform victim loss over all basal initiators subtracts one further copy of each site's weight. This is exactly the basal -2W term in siteOp. For triggers, drop the nonpositive victim-weight loss; the remaining parent contribution is (u+Uf)*(2 binE(W_false)-W_true). Complementary sisters have the correct identical marginal binomial expectations; independence of the two daughters is unnecessary. All chemical terms are exactly the other siteOp terms. Thus summing the complete SiteCert rows proves the displayed aggregate drift for arbitrary physical states.

For both old species together, stop at their first floor violation through 60. The below 16 barrier and nonnegativity give the floor-failure bound

48/10^8+8b0*60=48/10^8+480b0.

For the candidate, the global drift and arbitrary initial Phi<=320 give

E Phi_candidate(30)<=320 exp(-15)+8b0(1-exp(-15)).

Stop from time30 at the candidate's first floor violation, including a violation already present at 30. Another 30 units of drift at most 4b0 pay at most 120b0. Hence acquisition plus post30 candidate floor failure is at most 320 exp(-15)+128b0. This uses complete terminal marks and the all-count SiteCert; it requires no prepared candidate law.

Together, all floors/acquisition are bounded by 48/10^8+320 exp(-15)+608b0. On the floor-good event, every service block has a live start and whole-block floor survival, so the directly proved conditional intersection bound and a union bound pay at most 600*10^-8. Independently of floors, each spatial site's basal initiation clock has rate one. Its actual initiating-division count is at least its basal count. The exponential mark bound therefore pays at most 6^4 exp(-25) per site for fewer than five initiations, or 5184 exp(-25) total. No independence with the service event is needed.

Since 608b0<720b0, this proves the submitted source-conservative G60 bound directly. The independent comparison is 8226423/9062500000, strictly below the submitted 9545923/9062500000 by 112b0. It is recorded as a cross-check; the advertised complete mission bound in this review deliberately retains the candidate's conservative G60 allowance rather than silently substituting this extra refinement.

## 6. Uniform recovery and exposed-history composition

The accepted reciprocal recovery theorem applies to every finite beta>=1m, including4m, uniformly over all twelve counts in16..2048 and arbitrary fuel. Its event is surviving nonreturn at the original first simultaneous Ready512 time H and first floor-failure time D:

P(H>1/2,D>1/2)<=8622092430140/10^18<1/100000.

It is not an unconditional recovery-failure bound. Its literal chemical comparison, unchanged positive reset operator, terminal-fuel convention, and stopping-history form were already independently accepted in the lower-rate mission audit. This review does not re-prove every recovery-profile row or the historical reset coefficient. It does independently recompute the final exact low-word, Poisson-tail, clock-tail, reset-transfer scalar, and beta4m clock identities from those accepted constants. The recomputed once-rounded q is exactly the submitted value.

At each finite exposed physical stopping time, the pointwise restart estimate applies to the completed physical state. Each selected actual division is finished before defining the next local recovery. A Ready start returns immediately. A below 16 state is excluded by G60 and is never used as an admissible input. Neither service ledgers nor stocks are replenished.

There are eleven recoveries and ten first-actual-division waits. The four basal clocks stay active with aggregate rate four, including null marked divisions, so each wait of length2 has conditional tail at most exp(-8). Multiply each local bound by its exposed preceding-success indicator and average. G60 is used only for the event inclusion that protects the selected recovery intervals from floor failure; the future physical law is never conditioned on G60 itself.

Successful-prefix deadlines satisfy

30+11*(1/2)+10*2=55.5<60.

Every paid recovery interval is therefore within the source floor-protection horizon. The service grid still ends at60. Counting credits gives300*4*2*500+300*4*3*500=3,000,000.

The complete failure allowance is

G60_allowance+11/100000+10 exp(-8)+3 exp(-20).

Independent exact lower exponential polynomials, followed by one outward ceiling at denominator 10^18, give exactly 0.004517975690072193. Retaining G60<=1/500 instead gives exactly the displayed conservative ceiling 0.005464632462485986. The smaller G60 number alone must never be labelled the complete mission failure probability.

## 7. No independence or event substitutions

The accepted proof does not assume independent sisters, fuel/job clocks after conditioning, independent accepted-event resource counts, independent division episodes, stationary fuel occupancy, or monotonicity of the physical mission probability in beta. It uses physical rate bounds, nonnegative potentials, genuine marked stopping histories, and union bounds.

The recurring Ready512 returns do not replace fixed-grid service. The candidate's establishment at 16 at time30 is not asserted to be Ready512 at time30. The initial prepared condition applies only to the two old species. Floors and all terminal updates are retained literally; the recovery-only stopped chain is not incorrectly restarted after an earlier absorption.

## 8. Accepted feed, every gross ceiling, and finite stocks

At a fueled site the exact combined consuming envelope is the source

h_i=beta+sum_j[alpha*N*(3u_ij/2-u_ij^2)+(beta+1)u_ij].

Because beta+1>=alpha*N/2=819200, the quadratic's maximum on[0,1] is at the admissible endpoint u=1. Thus

Cstar=beta+3*(819200+beta+1)=18,457,603.

The +1 inside beta+1 is the division-coupled consumption and cannot be dropped. Basal victim-fuel loss has separate intensity F; triggered victim-fuel loss is bounded by3F. The literal source SR3 estimate consequently has

kappa=max{beta*(exp(t-s)-1),(Cstar+1+3 exp(s))*(exp(s)-1)},
P(A_60>B)<=exp[s*(4-F0)+240*kappa-t*B].

Choose t=1/10000, s=400/22457607, B=800000000. These satisfy 0<s<t<1. Since exp(x)<=1/(1-x) for 0<=x<1 and all multiplied factors are nonnegative,

kappa<=max{k1,k2},
k1=beta*(t-s)/(1-t+s)=73830428000000/224557612393,
k2=(Cstar+1+3/(1-s))*s/(1-s).

Exact arithmetic verifies k1>=k2. Arbitrary initial fuel is paid by s*(4-F0)<=4s, giving

4s+240k1-800000000*t
=-5508991479342664251200/5043026607980323551
<-1092<-20.

Hence the accepted-feed tail is less than exp(-20). This is an occupancy-sensitive accepted-event bound, not the raw recharge-proposal mean and not an assertion that accepted recharges are Poisson.

The unchanged seed intensity ceiling 72 gives mean-envelope 4320; t=1/10 and exp(t)<10/9 prove the 5000-seed tail less than exp(-20). The unchanged actual marked-division intensity ceiling 16 gives mean-envelope 960; an independent exact Taylor upper bound verifies exp(1/5)-1<31/140, yielding exponent -192/7<-20 at 1200 divisions.

On the common resource-good event, the source gross identities at every prefix, including complete terminal jumps, imply:

| Cumulative quantity | Ceiling |
|---|---:|
| Accepted feed/recharges A | 800,000,000 |
| Initially occupied fuel | 4 |
| Consumed fuel B+H+Q+U | 800,000,004 |
| Accepted seed entries E | 5,000 |
| Catalytic birth plus seed entries B+E | 800,005,004 |
| Actual marked divisions D | 1,200 |
| Discarded/restored catalyst slots W_S<=3ND | 7,372,800 |
| Discarded victim fuel W_R<=D | 1,200, already paid within gross supply |

A triggered split loses 1+R_v fuel, not merely 1. Its consumption is charged before the complementary split, and the victim loss is separately recorded. The conservation identity F0+A=F+C+W_R proves C<=A+4; adding 1200 again to the gross supply would double-count victim losses. These are cumulative entry/consumption ceilings, separate from the source's prepared initial catalyst inventories.

The finite-stock process uses identical clock, channel, victim, and complementary-split marks until the first attempted declared-resource excess. Before that mark the paths agree. On the original-law resource-good event there is no such excess through 60. Apply this to the entire physical mission event, subtract the three global tails once, and retain the same stocks through all service and recovery boundaries. All displayed resource caps therefore belong to the same complete mission statement.

## 9. beta1m architectural obstruction: accepted with its stated restriction

For this count-independent fuel-weight service architecture, write r=beta*K/N, delta=1-rho, H=Hs. Any positive admissible theta satisfies

theta*(1-delta)+(H+r)*delta<=r*(1-z), delta>=theta/beta.

The first inequality implies theta<=r; otherwise its left side exceeds r+H*delta, already greater than r*(1-z). Thus H+r-theta>=H, and substitution yields

theta<= [beta*r/(beta+H)]*(1-z).

At beta1m,K16,H=5,764,808 the bracket is 976562500/845601<1155. Since log(z)<=-(1-z), for z<1,

theta*0.1+500log(z)<0.

The resulting single-coordinate upper boundrho^-1*z^-500*exp(-theta*0.1) is therefore greater than one. Including the source's selected division-coupled+1 changes r only by factor 1+10^-6; the independent check confirms it cannot bridge the gap to 5000. At z=1 no positive decay is feasible.

This rejects only the proposition that optimizing the credit tilt closes beta1m with this worst-floor, count-independent certificate. It does not reject beta1m physical service, a count-dependent potential, a successful-prefix distribution-sensitive estimate, or a future occupation lower-tail proof. Those remain distinct open research questions.

## 10. Reproduction, preservation, and stopping boundary

Run:

`python independent_general_tilt_check.py > independent_general_tilt_stdout.txt`

The checker uses Python's standard library and exact fractions/integers only. It independently verifies candidate hashes, all new arithmetic, 4,066 service-envelope rows, 16,392 literal full-branching rows, 13 direct daughter-sum cross-checks, all rate/deadline/resource identities, and the accepted recovery theorem's final numerical composition. It writes only this review directory.

`SHA256SUMS.txt` pins the review, independent checker, result JSON, stdout, and source-dependency manifest. `SOURCE_DEPENDENCIES_SHA256.json` records exact read-only inputs. No simulation, floating-point inequality, parameter sweep, solver, compiler, Git operation, desktop access, publication, security change, or P079/P098 work was used.

The requested independent review is complete. Canonical adoption is a separate decision and was not requested or performed. The accepted beta4.5m canonical packet and every producer artifact remain unchanged.
