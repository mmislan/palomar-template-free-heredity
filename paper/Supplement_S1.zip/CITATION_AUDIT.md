# Citation and publication-status audit — 20 October 2026

All eight literature entries describe published articles. Their author lists, exact titles, years, journal coordinates and DOI identifiers were checked against the primary/index records below during this editorial revision. The manuscript uses narrow claims supported by those records; it makes no priority or acceptance claim for its private development sources. An unusual word in the 2010 title, “constraints”, is the indexed title and is retained.

| Entry | Published identifier and coordinates | Verification source | Claim used |
|---|---|---|---|
| 1, Segré, Ben-Eli and Lancet (2000) | PNAS 97(8), 4112–4117; 10.1073/pnas.97.8.4112 | https://pubmed.ncbi.nlm.nih.gov/10760281/ | Compositional-genome information transfer through growth and splitting |
| 2, Vasas, Szathmáry and Santos (2010) | PNAS 107(4), 1470–1475; 10.1073/pnas.0912628107 | https://pubmed.ncbi.nlm.nih.gov/20080693/ | Evolvability limitations in the GARD dynamics studied |
| 3, Vasas, Fernando, Santos, Kauffman and Szathmáry (2012) | Biology Direct 7, article 1; 10.1186/1745-6150-7-1 | https://link.springer.com/article/10.1186/1745-6150-7-1 | Qualified adaptation through acquisition of viable autocatalytic cores |
| 4, Markovitch and Lancet (2012) | Artificial Life 18(3), 243–266; 10.1162/artl_a_00064 | https://pubmed.ncbi.nlm.nih.gov/22662913/ ; https://weizmann.elsevierpure.com/en/publications/excess-mutual-catalysis-is-required-for-effective-evolvability/ | Selection under suitable mutual-catalysis interactions |
| 5, Gross, Fouxon, Lancet and Markovitch (2014) | BMC Evolutionary Biology 14, article 265; 10.1186/s12862-014-0265-1 | https://link.springer.com/article/10.1186/s12862-014-0265-1 | Compositional quasispecies and error thresholds |
| 6, Bunin and Rivoire (2025) | PNAS 122(31), e2425753122; 10.1073/pnas.2425753122 | https://pubmed.ncbi.nlm.nih.gov/40737326/ | Hereditary states, competition and adaptation in the declared physical model |
| 7, Rivoire and Bunin (2026) | PNAS 123(35), e2605428123; 10.1073/pnas.2605428123 | https://pubmed.ncbi.nlm.nih.gov/42636364/ | Adaptation to time-dependent environments in reaction–diffusion systems |
| 8, Sokolskyi and Baum (2026) | Langmuir 42(25), 17787–17795; 10.1021/acs.langmuir.6c00275 | https://pubmed.ncbi.nlm.nih.gov/42287249/ | Vesicle-population response to imposed selection for turbidity |

Publisher DOI links in the article identify those same records; no DOI is assigned to an unpublished companion. Entries 9 and 10 retain their citation identifiers and explicitly identify this article's own complete Supplement S1 records S1.1 and S1.2. Their exact source bytes and edition history are recorded in S1. They are not presented as external prior literature.

Entry 11 identifies the public formalization repository. Its fixed snapshot was read at https://raw.githubusercontent.com/mmislan/palomar-template-free-heredity/eb72f72f2c27da1e351e51ae2bdad4604c34cf3c/README.md and is pinned in S1. This is a source-availability claim, not a registry registration, DOI, peer-review or priority claim. The exact full finite-stock statement is distinguished from the complete conventional restoration proof.

All 11 bibliography entries are cited; all citation keys resolve. Literal “DOI.” and “Full article.” placeholders and preprint-version comparison notes have been removed. The bibliography contains no anonymous private manuscript cited as external literature.
