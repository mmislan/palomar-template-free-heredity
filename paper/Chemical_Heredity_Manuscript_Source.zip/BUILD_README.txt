Chemical heredity without genetic templates: acquisition, reproduction and retained function

Format edition of the reviewed canonical v2.2 manuscript, 19 October 2026.
Source: main.tex. Build with a current TeX installation that already supplies the listed standard packages:

  pdflatex --disable-installer -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
  pdflatex --disable-installer -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex

The accompanying PDF contains the abstract, manuscript and essential analytical Appendices A-D. The blank printed byline is intentional; repository contributor metadata is separate. Prose/data: CC-BY-4.0. Original proof/code in the separately supplied Supplement S1: Apache-2.0, subject to its per-file and third-party notices.

Supplement S1 is essential and must be archived with the work or cited at an actual fixed public archive identifier. This format edition uses named Supplement S1 references. It requires the actual stable companion citation before a Hexagon deposit. No DOI or prior publication status is asserted. The source archive contains manuscript TeX only and no Lean/Python proof code.
