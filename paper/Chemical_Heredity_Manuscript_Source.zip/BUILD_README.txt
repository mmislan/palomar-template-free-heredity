Chemical heredity without genetic templates
Michael Mislan — editorial edition, 20 October 2026

main.tex is the complete editable manuscript, with complete conventional Appendices A–D. The protocol figure is native LaTeX; no external figure file is needed. Compile twice with pdfLaTeX, shell escape disabled. The build uses standard article, amsmath, amssymb, amsthm, booktabs, longtable, array, graphicx, geometry, url and hyperref packages. No bibliography service, Lean compiler or private predecessor directory is needed to typeset this source. This preparation used the installed MiKTeX environment, with automatic package installation disabled.

The separate Supplement S1 ZIP contains the literal rational data, portable exact-arithmetic verifier, retained complete mathematical source records, operating-comparison support, provenance and third-party notices. It is required supporting material for the article's finite certificates. A separate publication of the earlier P161 or P118 manuscript is not required. The public formalization is linked in the article and pinned in S1. Its proof sources/accepted receipts were not edited for this manuscript.

The source ZIP intentionally contains manuscript TeX and its documentation/licence only. Supplement S1 includes proof/checking code and must be handled as a separate research supplement, rather than included in a TeX-only manuscript upload. This folder also holds local typesetting intermediates; they are not part of the source ZIP.

Original prose is CC-BY-4.0; supporting code/proofs and embedded third-party terms are specified in S1. This is a privately prepared editorial package. No deposit, publication or new submission is authorized or performed by its creation.
